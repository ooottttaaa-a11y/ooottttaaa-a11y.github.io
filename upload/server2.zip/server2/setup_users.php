<?php
require_once 'db_connect.php';

try {
    // 1. Create Table
    $sql = file_get_contents('create_users_table.sql');
    $mysqli->query($sql);
    echo "Table 'users' created or already exists.<br>";

    // 2. Check if admin exists
    $stmt = $mysqli->prepare("SELECT COUNT(*) as count FROM users WHERE username = 'admin'");
    $stmt->execute();
    $result = mysqli_fetch_all_assoc($stmt);
    $count = $result[0]['count'];

    if ($count == 0) {
        // 3. Create default admin
        $password = 'admin123';
        $hashed_password = legacy_password_hash($password);
        
        $insert = $mysqli->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
        $insert->bind_param("sss", $username_arg, $hashed_password, $role_arg);
        $username_arg = 'admin';
        $role_arg = 'admin';
        $insert->execute();
        
        echo "Default admin user created (admin / admin123).<br>";
    } else {
        echo "Admin user already exists.<br>";
    }

} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}
?>
