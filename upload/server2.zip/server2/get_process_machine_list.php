<?php
// get_process_machine_list.php - API to fetch machine stats for a specific process

// Database configuration
require_once 'db_connect.php';

// Parameters
$process = isset($_GET['process']) ? $_GET['process'] : '';
$startDate = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-d');
$endDate = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');

if (empty($process)) {
    header('HTTP/1.1 400 Bad Request');
    echo json_encode(array('status' => 'error', 'message' => 'Process name is required'));
    exit;
}

$startDateTime = $startDate . ' 00:00:00';
$endDateTime = $endDate . ' 23:59:59';

try {
    // Fetch data for specific process
    $stmt = $mysqli->prepare("SELECT machine, sec, mouse, keyboard FROM activity_records WHERE process = ? AND uptime >= ? AND uptime <= ?");
    $stmt->bind_param("sss", $process, $startDateTime, $endDateTime);
    $stmt->execute();
    $rows = mysqli_fetch_all_assoc($stmt);

    $machineStats = array();

    foreach ($rows as $row) {
        $mach = $row['machine'];
        $sec = (int)$row['sec'];
        $mouse = (int)$row['mouse'];
        $keyboard = (int)$row['keyboard'];

        if (!isset($machineStats[$mach])) {
            $machineStats[$mach] = array(
                'total' => 0,
                'view' => 0,
                'edit' => 0
            );
        }

        $machineStats[$mach]['total'] += $sec;

        if ($keyboard > 0) {
            $machineStats[$mach]['edit'] += $sec;
        } elseif ($mouse > 0) {
            $machineStats[$mach]['view'] += $sec;
        }
    }

    $result = array();
    foreach ($machineStats as $mach => $stats) {
        $result[] = array(
            'machine' => $mach,
            'total_time' => $stats['total'],
            'total_fmt' => floor($stats['total'] / 3600) . gmdate(':i', $stats['total'] % 3600),
            'view_time' => $stats['view'],
            'view_fmt' => floor($stats['view'] / 3600) . gmdate(':i', $stats['view'] % 3600),
            'edit_time' => $stats['edit'],
            'edit_fmt' => floor($stats['edit'] / 3600) . gmdate(':i', $stats['edit'] % 3600)
        );
    }

    // Sort by Total Time desc
    usort($result, create_function('$a, $b', 'return $b["total_time"] - $a["total_time"];'));

    header('Content-Type: application/json');
    echo json_encode(array('status' => 'success', 'data' => $result));

} catch (Exception $e) {
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(array('status' => 'error', 'message' => $e->getMessage()));
}
?>
