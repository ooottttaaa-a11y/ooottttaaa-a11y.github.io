<?php
require_once 'auth_session.php';
require_once 'db_connect.php';

// Ensure only admin can access
check_admin();

$error = '';
$success = '';

// Handle Add User
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == 'add') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $role = $_POST['role'];

    if (empty($username) || empty($password)) {
        $error = "ユーザ名とパスワードを入力してください。";
    } else {
        // Check if username exists
        $stmt = $mysqli->prepare("SELECT COUNT(*) as count FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $res = mysqli_fetch_all_assoc($stmt);
        if ($res[0]['count'] > 0) {
            $error = "このユーザ名は既に使用されています。";
        } else {
            $hashed_password = legacy_password_hash($password);
            $stmt = $mysqli->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $username, $hashed_password, $role);
            if ($stmt->execute()) {
                $success = "ユーザを追加しました。";
            } else {
                $error = "ユーザ追加に失敗しました。";
            }
        }
    }
}

// Handle Edit User
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == 'edit') {
    $id = $_POST['id'];
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $role = $_POST['role'];

    if (empty($username)) {
        $error = "ユーザ名を入力してください。";
    } else {
        // Check if username exists (other than self)
        $stmt = $mysqli->prepare("SELECT COUNT(*) as count FROM users WHERE username = ? AND id != ?");
        $stmt->bind_param("si", $username, $id);
        $stmt->execute();
        $res = mysqli_fetch_all_assoc($stmt);
        if ($res[0]['count'] > 0) {
            $error = "このユーザ名は既に使用されています。";
        } else {
            if (!empty($password)) {
                $hashed_password = legacy_password_hash($password);
                $stmt = $mysqli->prepare("UPDATE users SET username = ?, password = ?, role = ? WHERE id = ?");
                $stmt->bind_param("sssi", $username, $hashed_password, $role, $id);
            } else {
                $stmt = $mysqli->prepare("UPDATE users SET username = ?, role = ? WHERE id = ?");
                $stmt->bind_param("ssi", $username, $role, $id);
            }
            
            if ($stmt->execute()) {
                $success = "ユーザ情報を更新しました。";
            } else {
                $error = "ユーザ更新に失敗しました。";
            }
        }
    }
}

// Handle Delete User
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    // Prevent deleting self (simple check)
    if ($id == $_SESSION['user_id']) {
        $error = "自分自身を削除することはできません。";
    } else {
        $stmt = $mysqli->prepare("DELETE FROM users WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $success = "ユーザを削除しました。";
    }
}

// Fetch all users
$result = $mysqli->query("SELECT * FROM users ORDER BY created_at DESC");
$users = array();
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
}
$current_user = current_user();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset='UTF-8'>
    <title>ActivityMonitor - ユーザ管理</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome for icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Segoe UI', Meiryo, sans-serif; background: #f5f5f5; }
        .header-area { background: #fff; padding: 20px; border-bottom: 2px solid #4CAF50; margin-bottom: 20px; }
        .card { border: none; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php">ActivityMonitor</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link" href="index.php">生産性・集中度スコア</a></li>
        <li class="nav-item"><a class="nav-link" href="attendance.php">勤怠</a></li>
        <li class="nav-item"><a class="nav-link" href="process_analysis.php">プロセス分析</a></li>
        <?php if ($current_user['role'] === 'admin'): ?>
            <li class="nav-item"><a class="nav-link active" href="users.php">ユーザ管理</a></li>
        <?php endif; ?>
      </ul>
      <span class="navbar-text text-light me-3">
        <i class="fas fa-user"></i> <?php echo htmlspecialchars($current_user['username']); ?>
      </span>
      <a href="logout.php" class="btn btn-outline-light btn-sm">ログアウト</a>
    </div>
  </div>
</nav>

<div class="container mt-4">
    <div class="row">
        <!-- User List -->
        <div class="col-md-12">
            <div class="card p-3">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="m-0">登録済みユーザ</h5>
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addUserModal">
                        <i class="fas fa-user-plus"></i> 新規ユーザ追加
                    </button>
                </div>
                
                <?php if ($error): ?>
                    <div class="alert alert-danger alert-dismissible fade show btn-sm p-2 mb-3">
                        <?php echo htmlspecialchars($error); ?>
                        <button type="button" class="btn-close p-2" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <?php if ($success): ?>
                    <div class="alert alert-success alert-dismissible fade show btn-sm p-2 mb-3">
                        <?php echo htmlspecialchars($success); ?>
                        <button type="button" class="btn-close p-2" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>ユーザ名</th>
                            <th>権限</th>
                            <th>作成日</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $u): ?>
                        <tr>
                            <td><?php echo $u['id']; ?></td>
                            <td><?php echo htmlspecialchars($u['username']); ?></td>
                            <td>
                                <?php if ($u['role'] === 'admin'): ?>
                                    <span class="badge bg-danger">Admin</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">User</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo $u['created_at']; ?></td>
                            <td>
                                <button type="button" class="btn btn-warning btn-sm edit-btn" 
                                        data-id="<?php echo $u['id']; ?>" 
                                        data-username="<?php echo htmlspecialchars($u['username']); ?>" 
                                        data-role="<?php echo $u['role']; ?>">
                                    編集
                                </button>
                                <?php if ($u['id'] != $_SESSION['user_id']): ?>
                                    <a href="users.php?delete=<?php echo $u['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('本当に削除しますか？');">削除</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Add User Modal -->
<div class="modal fade" id="addUserModal" tabindex="-1" aria-labelledby="addUserModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="post" action="">
        <div class="modal-header">
          <h5 class="modal-title" id="addUserModalLabel">新規ユーザ追加</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <input type="hidden" name="action" value="add">
            <div class="mb-3">
                <label class="form-label">ユーザ名</label>
                <input type="text" class="form-control" name="username" required>
            </div>
            <div class="mb-3">
                <label class="form-label">パスワード</label>
                <input type="password" class="form-control" name="password" required>
            </div>
            <div class="mb-3">
                <label class="form-label">権限</label>
                <select class="form-select" name="role">
                    <option value="user">一般ユーザ</option>
                    <option value="admin">管理者 (Admin)</option>
                </select>
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">キャンセル</button>
          <button type="submit" class="btn btn-primary">追加</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Edit User Modal -->
<div class="modal fade" id="editUserModal" tabindex="-1" aria-labelledby="editUserModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="post" action="">
        <div class="modal-header">
          <h5 class="modal-title" id="editUserModalLabel">ユーザ情報編集</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="id" id="editUserId">
            <div class="mb-3">
                <label class="form-label">ユーザ名</label>
                <input type="text" class="form-control" name="username" id="editUsername" required>
            </div>
            <div class="mb-3">
                <label class="form-label">パスワード (変更する場合のみ入力)</label>
                <input type="password" class="form-control" name="password">
            </div>
            <div class="mb-3">
                <label class="form-label">権限</label>
                <select class="form-select" name="role" id="editUserRole">
                    <option value="user">一般ユーザ</option>
                    <option value="admin">管理者 (Admin)</option>
                </select>
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">キャンセル</button>
          <button type="submit" class="btn btn-primary">更新</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
$(document).ready(function() {
    $('.edit-btn').on('click', function() {
        const id = $(this).data('id');
        const username = $(this).data('username');
        const role = $(this).data('role');
        
        $('#editUserId').val(id);
        $('#editUsername').val(username);
        $('#editUserRole').val(role);
        
        $('#editUserModal').modal('show');
    });
});
</script>
</body>
</html>
