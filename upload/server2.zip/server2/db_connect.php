<?php
// db_connect.php - Centralized database connection

$configPath = dirname(__FILE__) . '/db_config.ini';

if (!file_exists($configPath)) {
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(array('status' => 'error', 'message' => 'Configuration file not found'));
    exit;
}

$config = parse_ini_file($configPath);

if (!$config) {
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(array('status' => 'error', 'message' => 'Failed to parse configuration file'));
    exit;
}

$host = $config['host'];
$db   = $config['dbname'];
$user = $config['user'];
$pass = $config['password'];
$charset = $config['charset'];

// mysqli connection
$mysqli = new mysqli($host, $user, $pass, $db);

if ($mysqli->connect_error) {
    header('HTTP/1.1 500 Internal Server Error');
    error_log('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
    echo json_encode(array('status' => 'error', 'message' => 'Database connection failed'));
    exit;
}

$mysqli->set_charset($charset);

/**
 * Helper to fetch all rows from a statement (mysqli fallback for get_result)
 */
function mysqli_fetch_all_assoc($stmt) {
    $stmt->store_result();
    $meta = $stmt->result_metadata();
    $fields = array();
    while ($field = $meta->fetch_field()) {
        $fields[] = &$row[$field->name];
    }
    call_user_func_array(array($stmt, 'bind_result'), $fields);
    $results = array();
    while ($stmt->fetch()) {
        $copy = array();
        foreach ($row as $key => $val) {
            $copy[$key] = $val;
        }
        $results[] = $copy;
    }
    return $results;
}

/**
 * Helper for password hashing (PHP 5.2 compatible)
 */
function legacy_password_hash($password) {
    $salt = 'activity_monitor_salt_123'; // Static salt for simplicity in migration
    return sha1($salt . $password);
}

function legacy_password_verify($password, $hash) {
    return legacy_password_hash($password) === $hash;
}
?>
