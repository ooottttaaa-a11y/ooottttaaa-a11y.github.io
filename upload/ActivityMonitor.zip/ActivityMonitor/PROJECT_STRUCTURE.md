# ActivityMonitor プロジェクト構成

このプロジェクトは、Windows作業履歴を記録するクライアントアプリ(C#)と、データを集約・閲覧するサーバサイド(PHP/MySQL)で構成されています。

## ルートディレクトリ (`c:\xampp\htdocs\ActivityMonitor\`)

| ファイル名 | 説明 |
| :--- | :--- |
| **ActivityMonitor.cs** | **[クライアント]** アプリケーションのメインソースコード。アクティビティログ記録、ローカルDB操作、サーバ同期ロジックを含む。 |
| **ActivityMonitor.csproj** | C#プロジェクトファイル。.NET Framework 4.8 ターゲット。 |
| **ActivityMonitor.exe** | **[クライアント]** コンパイル済みの実行ファイル。これを配布・実行する。 |
| **ActivityViewer.cs** | (旧) ローカル専用のSQLiteビューアのソースコード。現在はHTMLレポートやサーバサイドビューアが主流。 |
| **ActivityViewer.exe** | (旧) コンパイル済みのビューア実行ファイル。 |
| **icon.ico** | アプリケーションアイコン。 |
| *System.Data.SQLite.dll* | SQLite操作用ライブラリ (exeに埋め込み済みだが、開発用に配置)。 |
| *SQLite.Interop.dll* | SQLiteネイティブライブラリ (exeに埋め込み済みだが、開発用に配置)。 |

## サーバサイド (`server\`)

Webサーバ (Apache/PHP) 上に配置し、クライアントからのデータ受信とブラウザでの閲覧機能を提供します。

| ファイル名 | 説明 |
| :--- | :--- |
| **index.php** | **[閲覧画面]** ブラウザでアクセスするトップページ。チャートやスコアを表示する。 |
| **api.php** | **[データ受信API]** クライアントからPOSTされたJSONデータを受け取り、MySQLに保存する。 |
| **get_data.php** | **[データ取得API]** `index.php` から呼ばれる。DBからデータを取得し、スコア計算を行ってJSONを返す。 |
| **create_table.sql** | MySQLテーブル作成用SQL (初回セットアップ用)。 |
| **init_db.sql** | データベース初期化用SQL。 |

### サーバサイド・ユーティリティ (`server\utils\`)

| ファイル名 | 説明 |
| :--- | :--- |
| **ScoreCalculator.php** | **[コアロジック]** C#側の「生産性・集中度スコア計算ロジック」をPHPに移植したクラスライブラリ。 |

## データフロー

1.  **記録**: `ActivityMonitor.exe` がPC操作を記録し、ローカルのSQLite (`ActivityMonitor.db`) に保存。
2.  **同期**: 起動時または手動で、`ActivityMonitor.exe` が `server/api.php` にデータを送信。
3.  **保存**: `api.php` がMySQLデータベース (`activity_monitor` DB) にデータを格納。
4.  **計算**: `server/get_data.php` がMySQLからデータを読み出し、`ScoreCalculator.php` を使ってスコアを計算。
5.  **閲覧**: `server/index.php` が計算済みデータを受け取り、ブラウザにグラフ・レポートを表示。
