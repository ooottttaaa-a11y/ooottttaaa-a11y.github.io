# ActivityMonitor - ローカル専用アクティビティ監視ツール

## 概要
このプログラムは、ユーザーのPC操作を監視し、ローカルにXML形式でデータを保存するツールです。
元の`cs_1690.cs`からサーバー送信機能を削除し、ローカルデータ保存のみに対応しています。

## 主な機能
- ✅ アクティブウィンドウの監視(タイトル、プロセス名)
- ✅ キーボード・マウス入力のカウント
- ✅ ローカルXMLファイルへのデータ保存
- ✅ セッション監視(ロック/アンロック)
- ✅ タスクトレイ常駐
- ✅ 設定画面(ユーザー名設定)
- ✅ 二重起動防止

## 削除された機能
- ❌ サーバー送信機能(すべてのHTTP通信)
- ❌ バージョンアップ機能
- ❌ 部門データベース連携
- ❌ CTI電話制御監視
- ❌ エラーログ送信

## ビルド方法

### Visual Studioを使用する場合
1. Visual Studioで新しいC# Windowsフォームプロジェクトを作成
2. `ActivityMonitor.cs`の内容をプロジェクトに追加
3. ビルド → ソリューションのビルド

### コマンドラインでビルドする場合
```powershell
# .NET Framework 4.x以上が必要
csc /target:winexe /out:ActivityMonitor.exe ActivityMonitor.cs
```

または

```powershell
# Developer Command Prompt for Visual Studioで実行
csc /target:winexe /win32icon:icon.ico /out:ActivityMonitor.exe ActivityMonitor.cs
```

## 使用方法

### 初回起動
1. `ActivityMonitor.exe`を実行
2. 設定画面が表示されるので、ユーザー名を入力
3. 「保存」ボタンをクリック
4. 設定画面を閉じる

### 通常使用
- プログラムはタスクトレイに常駐します
- タスクトレイアイコンをダブルクリックで設定画面を開く
- 右クリックメニューから「設定画面を開く」または「終了」を選択可能

## データ保存場所

### 監視データ
```
C:\Users\[ユーザー名]\AppData\Local\ActivityMonitor\[ユーザー名].xml
```

### 設定ファイル
```
C:\Users\[ユーザー名]\AppData\Local\ActivityMonitor\setting.xml
```

## データ形式

### 監視データ(例)
```xml
<?xml version="1.0" encoding="utf-8"?>
<user>
  <record>
    <uptime>2025-12-11 04:30:00</uptime>
    <username>zelif</username>
    <machine>DESKTOP-PC</machine>
    <task>Google Chrome - 検索結果</task>
    <process>chrome</process>
    <sec>120</sec>
    <mouse>45</mouse>
    <keyboard>230</keyboard>
    <session>SessionUnlock</session>
    <memory>52428800</memory>
  </record>
</user>
```

### 設定ファイル(例)
```xml
<?xml version="1.0" encoding="utf-8"?>
<settings>
  <setting>
    <username>zelif</username>
    <machine>DESKTOP-PC</machine>
    <domain>WORKGROUP</domain>
    <user>zelif</user>
    <created>2025-12-11 04:30:00</created>
  </setting>
</settings>
```

## 動作環境
- Windows 7以降
- .NET Framework 4.0以降

## バージョン情報
- **バージョン**: 2.0.0.0
- **リリース日**: 2025/12/11
- **元のバージョン**: cs_1690.cs (ver.1.6.9.0)

## 注意事項
- このプログラムはローカル専用です
- サーバーへのデータ送信機能は完全に削除されています
- XMLファイルが破損した場合、自動的にバックアップを作成して復旧します
- 二重起動は防止されています

## トラブルシューティング

### XMLファイルが破損した場合
プログラムが自動的に以下の処理を行います:
1. 破損したファイルを`[ファイル名]_[タイムスタンプ].error`としてバックアップ
2. 新しいXMLファイルを作成
3. 監視を継続

### 設定が保存されない場合
1. `C:\Users\[ユーザー名]\AppData\Local\ActivityMonitor\`フォルダの書き込み権限を確認
2. プログラムを管理者権限で実行してみる

## ライセンス
元のcs_1690.csから派生したローカル専用版
