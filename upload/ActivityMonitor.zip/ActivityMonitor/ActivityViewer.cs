using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

// ****************************************************************************
// ActivityViewer - SQLite Data Browser & Report Viewer
// ****************************************************************************
class ActivityViewer : Form
{
    // UI Controls
    private TabControl tabControl;
    private TabPage tabReport;
    private TabPage tabData;
    
    // Data Grid (Legacy)
    private DataGridView dataGridView;
    private TextBox pathBox;
    private ToolStripStatusLabel statusLabel;

    // WebView2 (New)
    private WebView2 webView;
    private string currentDbPath = "";

    [STAThread]
    static void Main()
    {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new ActivityViewer());
    }

    public ActivityViewer()
    {
        this.Text = "Activity Viewer - SQLite Data Browser";
        this.Size = new Size(1200, 800);
        this.StartPosition = FormStartPosition.CenterScreen;
        
        if (File.Exists("icon.ico"))
        {
            this.Icon = new Icon("icon.ico");
        }

        InitializeComponents();
        LoadDefaultDatabase();
    }

    private void InitializeComponents()
    {
        // Top Panel
        Panel topPanel = new Panel();
        topPanel.Dock = DockStyle.Top;
        topPanel.Height = 40;
        topPanel.Padding = new Padding(5);
        this.Controls.Add(topPanel);

        Button openButton = new Button { Text = "DBを開く...", Width = 80, Dock = DockStyle.Left };
        openButton.Click += OpenButton_Click;
        topPanel.Controls.Add(openButton);

        Button refreshButton = new Button { Text = "更新", Width = 60, Dock = DockStyle.Left };
        refreshButton.Click += RefreshButton_Click;
        topPanel.Controls.Add(refreshButton);

        Button importButton = new Button { Text = "XMLインポート", Width = 100, Dock = DockStyle.Left };
        importButton.Click += ImportXmlButton_Click;
        topPanel.Controls.Add(importButton);

        pathBox = new TextBox { ReadOnly = true, Dock = DockStyle.Fill, BackColor = Color.White };
        topPanel.Controls.Add(pathBox);
        pathBox.BringToFront();

        // Status Strip
        StatusStrip statusStrip = new StatusStrip();
        this.Controls.Add(statusStrip);
        statusLabel = new ToolStripStatusLabel { Text = "Ready" };
        statusStrip.Items.Add(statusLabel);

        // Tab Control
        tabControl = new TabControl { Dock = DockStyle.Fill };
        this.Controls.Add(tabControl);
        tabControl.BringToFront();

        // Tab 1: Report (WebView2)
        tabReport = new TabPage("レポート (WebView2)");
        tabControl.TabPages.Add(tabReport);
        
        // Initialize WebView2
        InitializeWebView();

        // Tab 2: Raw Data (Grid)
        tabData = new TabPage("詳細データ (Grid)");
        tabControl.TabPages.Add(tabData);

        dataGridView = new DataGridView();
        dataGridView.Dock = DockStyle.Fill;
        dataGridView.ReadOnly = true;
        dataGridView.AllowUserToAddRows = false;
        dataGridView.AllowUserToDeleteRows = false;
        dataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
        dataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        tabData.Controls.Add(dataGridView);
    }

    private async void InitializeWebView()
    {
        try
        {
            webView = new WebView2();
            webView.Dock = DockStyle.Fill;
            tabReport.Controls.Add(webView);

            // Wait for CoreWebView2 initialization
            await webView.EnsureCoreWebView2Async(null);

            // Add Bridge Object
            webView.CoreWebView2.AddHostObjectToScript("bridge", new Bridge(this));

            // Load Initial HTML
            LoadHtmlTemplate();
        }
        catch (Exception ex)
        {
            Label errorLabel = new Label
            {
                Text = "WebView2の初期化に失敗しました。\nランタイムがインストールされているか確認してください。\n" + ex.Message,
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = Color.Red
            };
            tabReport.Controls.Remove(webView);
            tabReport.Controls.Add(errorLabel);
        }
    }

    private void LoadHtmlTemplate()
    {
        if (webView != null && webView.CoreWebView2 != null)
        {
            webView.NavigateToString(HtmlTemplate.Content);
        }
    }

    // ****************************************************************************
    // Data Loading Logic
    // ****************************************************************************
    private void LoadDefaultDatabase()
    {
        try
        {
            string folder = System.Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string user = Environment.UserName;
            string defaultPath = string.Format(@"{0}\ActivityMonitor\{1}.db", folder, user);

            if (File.Exists(defaultPath))
            {
                LoadDatabase(defaultPath);
            }
            else
            {
                statusLabel.Text = "デフォルトDBが見つかりません: " + defaultPath;
            }
        }
        catch (Exception ex)
        {
            statusLabel.Text = "初期ロードエラー: " + ex.Message;
        }
    }

    private void LoadDatabase(string path)
    {
        try
        {
            if (!File.Exists(path))
            {
                MessageBox.Show("ファイルが見つかりません:\n" + path, "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            currentDbPath = path;
            pathBox.Text = path;

            // Load Grid Data (Recent 1000)
            string connectionString = string.Format("Data Source={0};Version=3;Read Only=True;", path);
            using (SQLiteConnection conn = new SQLiteConnection(connectionString))
            {
                conn.Open();
                string sql = "SELECT * FROM activity_records ORDER BY uptime DESC LIMIT 1000";
                using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(sql, conn))
                {
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dataGridView.DataSource = dt;
                    statusLabel.Text = string.Format("読み込み完了: {0} 件 (Grid)", dt.Rows.Count);
                }
            }

            // Reload HTML if WebView is ready
            if (webView != null && webView.CoreWebView2 != null)
            {
                webView.Reload();
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("DB読み込みエラー:\n" + ex.Message);
        }
    }

    private void OpenButton_Click(object sender, EventArgs e)
    {
        OpenFileDialog ofd = new OpenFileDialog();
        ofd.Filter = "SQLite Database (*.db)|*.db|All Files (*.*)|*.*";
        string folder = System.Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        string defaultDir = folder + @"\ActivityMonitor";
        if (Directory.Exists(defaultDir)) ofd.InitialDirectory = defaultDir;

        if (ofd.ShowDialog() == DialogResult.OK)
        {
            LoadDatabase(ofd.FileName);
        }
    }

    private void RefreshButton_Click(object sender, EventArgs e)
    {
        if (!string.IsNullOrEmpty(currentDbPath)) LoadDatabase(currentDbPath);
    }
    
    private void ImportXmlButton_Click(object sender, EventArgs e)
    {
        MessageBox.Show("XMLインポート機能は現在Gridモードでのみ確認できます。", "Info");
        // 実装は省略（既存コード参照のこと）か、必要なら残す
    }

    // ****************************************************************************
    // Bridge Class (JS -> C#)
    // ****************************************************************************
    [ClassInterface(ClassInterfaceType.AutoDual)]
    [ComVisible(true)]
    public class Bridge
    {
        private ActivityViewer _parent;
        public Bridge(ActivityViewer parent)
        {
            _parent = parent;
        }

        public string GetDailyData(string dateStr)
        {
            return _parent.GenerateDailyReportJson(dateStr);
        }
    }

    // ****************************************************************************
    // Report Generation Logic (Returning JSON)
    // ****************************************************************************
    public string GenerateDailyReportJson(string targetDate) // targetDate: "YYYY-MM-DD"
    {
        if (string.IsNullOrEmpty(currentDbPath) || !File.Exists(currentDbPath)) return "{}";

        try
        {
            var logs = new List<WorkLog>();
            
            // Query DB for specific date
            string connectionString = string.Format("Data Source={0};Version=3;Read Only=True;", currentDbPath);
            using (SQLiteConnection conn = new SQLiteConnection(connectionString))
            {
                conn.Open();
                // uptime is "YYYY-MM-DD HH:MM:SS"
                string sql = "SELECT * FROM activity_records WHERE uptime LIKE @date ORDER BY uptime ASC";
                using (SQLiteCommand cmd = new SQLiteCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@date", targetDate + "%");
                    using (SQLiteDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var log = new WorkLog
                            {
                                DateTime = DateTime.Parse(reader["uptime"].ToString()),
                                Process = reader["process"].ToString(),
                                DurationSec = Convert.ToInt32(reader["sec"]),
                                MouseCount = Convert.ToInt32(reader["mouse"]),
                                KeyboardCount = Convert.ToInt32(reader["keyboard"]),
                                SessionState = reader["session"].ToString(),
                            };
                            
                            // Optional columns
                             try { log.SwitchCount = Convert.ToInt32(reader["switch_count"]); } catch { }
                             try { log.IdleSeconds = Convert.ToInt32(reader["idle_seconds"]); } catch { }
                             try { log.LockSeconds = Convert.ToInt32(reader["lock_seconds"]); } catch { }
                             // Remote check if needed
                             
                             logs.Add(log);
                        }
                    }
                }
            }

            if (!logs.Any()) return "{}";

            // Calculate Scores
            List<TimeBlockScore> blockScores = TimeBlockScoreCalculator.Calculate(logs);
            double dailyProd = ProductivityCalculator.Calculate(logs);
            double dailyFocus = FocusCalculator.Calculate(logs);

            // Build JSON Manually (to avoid dependencies)
            StringBuilder json = new StringBuilder();
            json.Append("{");
            json.AppendFormat("\"date\": \"{0}\",", targetDate);
            json.AppendFormat("\"productivity\": {0},", dailyProd);
            json.AppendFormat("\"focus\": {0},", dailyFocus);
            
            // Raw Records (for timeline/table)
            json.Append("\"records\": [");
            for (int i = 0; i < logs.Count; i++)
            {
                var l = logs[i];
                json.Append("{");
                json.AppendFormat("\"time\": \"{0}\",", l.DateTime.ToString("HH:mm:ss"));
                json.AppendFormat("\"process\": \"{0}\",", EscapeJson(l.Process));
                json.AppendFormat("\"sec\": {0},", l.DurationSec);
                json.AppendFormat("\"mouse\": {0},", l.MouseCount);
                json.AppendFormat("\"key\": {0},", l.KeyboardCount);
                json.AppendFormat("\"session\": \"{0}\"", l.SessionState);
                json.Append("}");
                if (i < logs.Count - 1) json.Append(",");
            }
            json.Append("],");

            // Block Scores
            json.Append("\"blocks\": [");
            for (int i = 0; i < blockScores.Count; i++)
            {
                var b = blockScores[i];
                json.Append("{");
                json.AppendFormat("\"time\": \"{0}\",", b.BlockStart.ToString("HH:mm"));
                json.AppendFormat("\"prod\": {0},", b.ProductivityScore);
                json.AppendFormat("\"focus\": {0},", b.FocusScore);
                json.AppendFormat("\"proc\": \"{0}\",", EscapeJson(b.DominantProcess));
                json.AppendFormat("\"comment\": \"{0}\"", EscapeJson(b.Comment));
                json.Append("}");
                if (i < blockScores.Count - 1) json.Append(",");
            }
            json.Append("]");
            
            json.Append("}");
            return json.ToString();
        }
        catch (Exception ex)
        {
            return "{\"error\": \"" + EscapeJson(ex.Message) + "\"}";
        }
    }

    private string EscapeJson(string s)
    {
        if (s == null) return "";
        return s.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\r", "").Replace("\n", "");
    }
}

// ****************************************************************************
// HTML Template
// ****************************************************************************
public static class HtmlTemplate
{
    public const string Content = @"
<!DOCTYPE html>
<html>
<head>
    <meta charset='UTF-8'>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background: #f5f7fa; margin: 0; padding: 20px; color: #333; }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        .card { background: white; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); padding: 20px; margin-bottom: 20px; }
        input[type='date'] { padding: 8px; border: 1px solid #ddd; border-radius: 4px; font-size: 16px; }
        button { padding: 8px 16px; background: #2196F3; color: white; border: none; border-radius: 4px; cursor: pointer; }
        button:hover { background: #1976D2; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 10px; border-bottom: 1px solid #eee; text-align: left; }
        th { background: #fafafa; }
        .score-box { text-align: center; }
        .score-val { font-size: 24px; font-weight: bold; color: #333; }
        .score-lbl { font-size: 12px; color: #666; }
        .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .loading { color: #666; font-style: italic; }
    </style>
    <script src='https://cdn.jsdelivr.net/npm/chart.js'></script>
</head>
<body>
    <div class='header'>
        <h1>Activity Report</h1>
        <div>
            <input type='date' id='datePicker'>
            <button onclick='loadData()'>表示</button>
        </div>
    </div>

    <!-- Scores -->
    <div class='grid-2'>
        <div class='card score-box'>
            <div class='score-lbl'>生産性スコア</div>
            <div class='score-val' id='scoreProd'>-</div>
        </div>
        <div class='card score-box'>
            <div class='score-lbl'>集中度スコア</div>
            <div class='score-val' id='scoreFocus'>-</div>
        </div>
    </div>

    <!-- Charts -->
    <div class='card'>
        <h3>タイムライン (24h)</h3>
        <div style='height: 100px;'><canvas id='chartTimeline'></canvas></div>
    </div>

    <!-- Block Table -->
    <div class='card'>
        <h3>30分単位詳細</h3>
        <table>
            <thead><tr><th>時間</th><th>生産性</th><th>集中</th><th>主プロセス</th><th>コメント</th></tr></thead>
            <tbody id='blockTable'></tbody>
        </table>
    </div>

    <script>
        let timelineChart = null;
        
        // Init Date Picker to Today
        document.getElementById('datePicker').valueAsDate = new Date();

        async function loadData() {
            const date = document.getElementById('datePicker').value;
            if (!date) return;
            
            // Call C# Bridge via WebView2
            try {
                const jsonStr = await window.chrome.webview.hostObjects.bridge.GetDailyData(date);
                const data = JSON.parse(jsonStr);
                
                if (data.error) {
                    alert('Error: ' + data.error);
                    return;
                }
                
                render(data);
            } catch (e) {
                console.error(e);
            }
        }

        function render(data) {
            // Scores
            document.getElementById('scoreProd').textContent = data.productivity ? data.productivity.toFixed(1) : '-';
            document.getElementById('scoreFocus').textContent = data.focus ? data.focus.toFixed(1) : '-';
            
            // Block Table
            const tbody = document.getElementById('blockTable');
            tbody.innerHTML = '';
            if (data.blocks) {
                data.blocks.forEach(b => {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `<td>${b.time}</td>
                                    <td>${b.prod.toFixed(1)}</td>
                                    <td>${b.focus.toFixed(1)}</td>
                                    <td>${b.proc}</td>
                                    <td style='font-size:12px; color:#555;'>${b.comment}</td>`;
                    tbody.appendChild(tr);
                });
            }

            // Timeline Chart
            const ctx = document.getElementById('chartTimeline').getContext('2d');
            if (timelineChart) timelineChart.destroy();
            
            // Simple mapping for timeline: 1440 mins
            // For simplicity, we just verify data existence
            if (!data.records || data.records.length === 0) return;

            // Simplified chart logic (just showing record density or count per hour for now to keep it short)
            // Real implementation would parse records into 1440 array like ActivityMonitor.cs
            
            // Placeholder: Just plotting records count per hour
            const hourly = new Array(24).fill(0);
            data.records.forEach(r => {
                const h = parseInt(r.time.split(':')[0]);
                if (!isNaN(h)) hourly[h]++;
            });

            timelineChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: [...Array(24).keys()].map(i => i + ':00'),
                    datasets: [{
                        label: 'Records',
                        data: hourly,
                        backgroundColor: '#2196F3'
                    }]
                },
                options: { responsive: true, maintainAspectRatio: false }
            });
        }
    </script>
</body>
</html>
    ";
}

// ****************************************************************************
// Scoring Logic Classes (Copied from ActivityMonitor.cs)
// ****************************************************************************

public class WorkLog
{
    public DateTime DateTime { get; set; }
    public string Process { get; set; }
    public int DurationSec { get; set; }
    public int MouseCount { get; set; }
    public int KeyboardCount { get; set; }
    public int SwitchCount { get; set; } 
    public int IdleSeconds { get; set; } 
    public int LockSeconds { get; set; } 
    public string SessionState { get; set; }
}

public static class ProcessWeight
{
    public static double GetProductivityWeight(string process, int keyboard)
    {
        process = process.ToLower();
        if (process.Contains("antigravity") || process.Contains("code") || process.Contains("visual studio")) return 1.0;
        if (process.Contains("excel") || process.Contains("word") || process.Contains("powerpoint")) return 0.9;
        if (process.Contains("chrome") || process.Contains("edge") || process.Contains("firefox")) return keyboard > 0 ? 0.8 : 0.6; 
        if (process.Contains("line") || process.Contains("discord") || process.Contains("slack")) return 0.4; 
        return 0.3; 
    }
}

public static class ProductivityCalculator
{
    public static double Calculate(List<WorkLog> logs)
    {
        if (!logs.Any()) return 0;
        double densitySum = 0;
        double weightSum = 0;
        double continuityScore = CalculateContinuity(logs);
        double sessionScore = logs.All(l => l.SessionState == "SessionUnlock") ? 1.0 : 0.5; 
        int totalDuration = logs.Sum(l => l.DurationSec);
        if (totalDuration == 0) return 0;
        foreach (var log in logs)
        {
            if (log.DurationSec <= 0) continue;
            double density = (double)(log.KeyboardCount + log.MouseCount * 0.5) / log.DurationSec;
            densitySum += NormalizeDensity(density);
            weightSum += ProcessWeight.GetProductivityWeight(log.Process, log.KeyboardCount);
        }
        double densityAvg = densitySum / logs.Count;
        double weightAvg = weightSum / logs.Count;
        return Math.Round(100 * densityAvg * weightAvg * continuityScore * sessionScore, 1);
    }
    private static double NormalizeDensity(double density)
    {
        if (density >= 0.15) return 1.0; 
        if (density >= 0.08) return 0.8; 
        if (density >= 0.03) return 0.5; 
        return 0.2; 
    }
    private static double CalculateContinuity(List<WorkLog> logs)
    {
        int switches = 0;
        for (int i = 1; i < logs.Count; i++) if (logs[i].Process != logs[i - 1].Process) switches++;
        if (switches <= 3) return 1.0;
        if (switches <= 6) return 0.8;
        if (switches <= 10) return 0.5;
        return 0.2;
    }
}

public static class FocusCalculator
{
    public static double Calculate(List<WorkLog> logs)
    {
        if (!logs.Any()) return 0;
        double immersion = CalculateImmersion(logs);
        double interruption = CalculateInterruption(logs);
        double stability = CalculateStability(logs);
        double baseScore = 100 * immersion * interruption * stability;
        
        int totalDuration = logs.Sum(l => l.DurationSec);
        int totalSwitches = logs.Sum(l => l.SwitchCount);
        int totalIdle = logs.Sum(l => l.IdleSeconds);
        
        double switchPenalty = 0.0;
        if (totalSwitches > 10) switchPenalty = Math.Min(1.0, (double)(totalSwitches - 10) / 40.0);
        
        double idlePenalty = 0.0;
        if (totalDuration > 0)
        {
            double idleRatio = (double)totalIdle / totalDuration;
            if (idleRatio > 0.3) idlePenalty = Math.Min(1.0, (idleRatio - 0.3) * 2.5);
        }
        double totalPenaltyFactor = 1.0 - (switchPenalty * 0.4 + idlePenalty * 0.6); 
        if (totalPenaltyFactor < 0.1) totalPenaltyFactor = 0.1;

        return Math.Round(baseScore * totalPenaltyFactor, 1);
    }
    private static double CalculateImmersion(List<WorkLog> logs)
    {
        int maxContinuous = 0;
        int current = 0;
        string currentProcess = "";
        foreach (var log in logs)
        {
            if (log.Process == currentProcess) current += log.DurationSec;
            else
            {
                maxContinuous = Math.Max(maxContinuous, current);
                current = log.DurationSec; 
                currentProcess = log.Process;
            }
        }
        maxContinuous = Math.Max(maxContinuous, current);
        if (maxContinuous >= 1500) return 1.0;   
        if (maxContinuous >= 900) return 0.8;    
        if (maxContinuous >= 300) return 0.5;    
        return 0.2;
    }
    private static double CalculateInterruption(List<WorkLog> logs)
    {
        int interruptions = logs.Count(l => l.Process.ToLower().Contains("line") || l.Process.ToLower().Contains("explorer"));
        if (interruptions == 0) return 1.0;
        if (interruptions <= 2) return 0.8;
        if (interruptions <= 5) return 0.5;
        return 0.2;
    }
    private static double CalculateStability(List<WorkLog> logs)
    {
        var durations = logs.Select(l => (double)l.DurationSec).Where(d => d > 0).ToList();
        if (durations.Count < 2) return 1.0;
        double avg = durations.Average();
        double variance = durations.Sum(d => Math.Pow(d - avg, 2)) / durations.Count;
        double stdDev = Math.Sqrt(variance);
        if (stdDev < avg * 0.3) return 1.0;
        if (stdDev < avg * 0.6) return 0.7;
        return 0.4;
    }
}

public class TimeBlockScore
{
    public DateTime BlockStart { get; set; }
    public DateTime BlockEnd { get; set; }
    public double ProductivityScore { get; set; }
    public double FocusScore { get; set; }
    public string DominantProcess { get; set; }
    public string Comment { get; set; }
}

public static class TimeBlockHelper
{
    public static DateTime GetBlockStart(DateTime time)
    {
        int minuteBlock = time.Minute < 30 ? 0 : 30;
        return new DateTime(time.Year, time.Month, time.Day, time.Hour, minuteBlock, 0);
    }
}

public static class TimeBlockScoreCalculator
{
    public static List<TimeBlockScore> Calculate(List<WorkLog> logs)
    {
        if (!logs.Any()) return new List<TimeBlockScore>();
        var grouped = logs.GroupBy(l => TimeBlockHelper.GetBlockStart(l.DateTime)).OrderBy(g => g.Key);
        var results = new List<TimeBlockScore>();
        foreach (var group in grouped)
        {
            var blockLogs = group.ToList();
            double productivity = ProductivityCalculator.Calculate(blockLogs);
            double focus = FocusCalculator.Calculate(blockLogs);
            string dominantProcess = "";
            var processGroups = blockLogs.GroupBy(l => l.Process).OrderByDescending(g => g.Sum(x => x.DurationSec));
            if (processGroups.Any()) dominantProcess = processGroups.First().Key;
            
            int maxIdle = blockLogs.Any() ? blockLogs.Max(l => l.IdleSeconds) : 0;
            int totalIdle = blockLogs.Sum(l => l.IdleSeconds);
            int totalSwitch = blockLogs.Sum(l => l.SwitchCount);
            
            var summary = new ActivitySummary
            {
                BlockSeconds = 1800, 
                LastInputSeconds = maxIdle,
                IdleSeconds = totalIdle,
                WindowSwitchCount = totalSwitch
            };
            string comment = ActivityCommentGenerator.Generate(summary);
            results.Add(new TimeBlockScore { BlockStart = group.Key, BlockEnd = group.Key.AddMinutes(30), ProductivityScore = productivity, FocusScore = focus, DominantProcess = dominantProcess, Comment = comment });
        }
        return results;
    }
}

public class ActivitySummary
{
    public int BlockSeconds { get; set; }
    public int LastInputSeconds { get; set; }
    public int IdleSeconds { get; set; }
    public int WindowSwitchCount { get; set; }
}

public static class ActivityCommentGenerator
{
    public static string Generate(ActivitySummary s)
    {
        double idleRatio = s.BlockSeconds > 0 ? (double)s.IdleSeconds / s.BlockSeconds : 0;
        bool recentInput = s.LastInputSeconds < 30;
        bool longNoInput = s.LastInputSeconds > 120;
        bool lowIdle = idleRatio < 0.15;
        bool highIdle = idleRatio > 0.35;
        bool fewSwitch = s.WindowSwitchCount <= 10;
        bool manySwitch = s.WindowSwitchCount > 30;

        if (recentInput && lowIdle && fewSwitch) return "操作が継続しており、割り込みも少ない集中状態でした。";
        if (recentInput && manySwitch) return "作業は継続していましたが、ウィンドウ切替が多く、割り込みが頻発していました。";
        if (highIdle && fewSwitch && longNoInput) return "操作は少なく、ウィンドウ切替も抑えられており、思考や検討に時間を使っていた可能性があります。";
        if (highIdle && manySwitch) return "操作が断続的で、ウィンドウ切替も多く、作業が分断されやすい状態でした。";
        if (longNoInput && highIdle) return "長時間入力がなく、離席や会議などの非操作時間が多かったと考えられます。";
        if (!highIdle && fewSwitch) return "大きな中断はなく、安定した作業が行われていました。";
        if (!highIdle && !fewSwitch) return "複数の作業を並行して進めていた可能性があります。";
        return "全体的に操作量が少なく、稼働が控えめな時間帯でした。";
    }
}
