# ActivityViewer.cs 設計・仕様ドキュメント

`ActivityViewer.cs` は、ローカルに保存されたSQLiteデータベース (`.db`) を閲覧・分析するための Windows Forms アプリケーションです。
従来の DataGridView による生データ表示に加え、**WebView2** を利用したリッチなHTMLレポート表示機能を備えている点が特徴です。

## 1. アプリケーション概要

### 主な機能
1.  **データベース読込**: ユーザーのローカルAppDataフォルダからデフォルトのDBを自動ロード、またはファイルダイアログから任意のDBを開く。
2.  **HTMLレポート表示 (WebView2)**: C#内で生成したHTML/JSをWebView2コントロールに流し込み、モダンなUIでグラフやスコアを表示する。
3.  **生データ表示 (Grid)**: `DataGridView` を用いて、直近1000件のレコードを表形式で確認できる（デバッグや生データ確認用）。
4.  **スコア計算**: クライアントアプリ (`ActivityMonitor.cs`) と同一の計算ロジックを内包し、日次の「生産性スコア」「集中度スコア」を算出する。

## 2. アーキテクチャ構成

**ハイブリッド・デスクトップアプリ** の構成をとっています。

```mermaid
graph TD
    User[ユーザー] --> WinForm[Windows Form (ActivityViewer)]
    WinForm --> TabControl
    TabControl --> Tab1[レポート (WebView2)]
    TabControl --> Tab2[詳細データ (Grid)]
    
    Tab1 --> WebView2[Microsoft Edge WebView2]
    WebView2 --> HTML[内蔵HTML/JS/CSS]
    
    HTML -- "window.chrome.webview.hostObjects.bridge" --> Bridge[C# Bridge Class]
    Bridge --> SQLite[SQLite Database]
    Bridge --> Logic[スコア計算ロジック]
    
    Tab2 --> DataGridView
    DataGridView --> SQLite
```

### クラス構成
| クラス名 | 役割 |
| :--- | :--- |
| **ActivityViewer** (Form) | メイン画面。UI管理、DB接続、WebView2初期化を行う。 |
| **Bridge** | **重要**: WebView2内のJavaScriptから呼び出されるC#クラス。`GetDailyData(date)` メソッドを公開し、JSONデータを返す。 |
| **HtmlTemplate** | `const string Content` として、レポート画面のHTML/CSS/JSソースコードを保持する静的クラス。 |
| **ScoreCalculator関連** | `ProductivityCalculator`, `FocusCalculator` など、監視アプリと共通の計算ロジッククラス群。 |

## 3. WebView2 連携の仕組み (Bridgeパターン)

Web技術 (Chart.js, HTML5) の表現力と、デスクトップアプリ (SQLiteへの直接アクセス) の利便性を両立させるため、以下の仕組みを採用しています。

1.  **初期化**: `InitializeWebView()` で WebView2 を起動し、`AddHostObjectToScript("bridge", ...)` でC#オブジェクトをJS側に公開する。
2.  **データ要求**: ユーザーがHTML上の「表示」ボタンを押すと、JSが `await bridge.GetDailyData(date)` を呼び出す。
3.  **データ処理 (C#)**:
    - 指定日のデータをSQLiteからSELECT。
    - `TimeBlockScoreCalculator` 等を使用してスコアを計算。
    - JSON形式の文字列を作成して返す。
4.  **描画 (JS)**: 受け取ったJSONをパースし、Chart.js でグラフを描画、DOM操作でテーブルを更新する。

## 4. 主なメソッド仕様

### `ActivityViewer`
- `LoadDefaultDatabase()`: `AppData/Local/ActivityMonitor/{User}.db` を探しに行く。
- `LoadDatabase(path)`: 指定パスのDBを開き、Gridにデータを流し込み、WebView2があればリロードする。

### `Bridge.GetDailyData(string dateStr)`
- 引数: "YYYY-MM-DD" 形式の日付文字列。
- 戻り値: 以下の構造のJSON文字列。
    ```json
    {
      "date": "2025-12-16",
      "productivity": 85.5,
      "focus": 90.0,
      "records": [ ... ], // 生ログ（タイムライン用）
      "blocks": [ ... ]   // 30分単位のスコア詳細
    }
    ```

## 5. 画面仕様 (HTML Template)

`HtmlTemplate` クラスにハードコーディングされています。

- **ライブラリ**: Chart.js (CDN) を使用。インターネット接続が必要。
- **デザイン**:
    - **スコアカード**: 生産性・集中度を大きく表示。
    - **タイムライン**: 24時間の活動量の棒グラフ。
    - **詳細テーブル**: 30分ごとの分析結果と自動生成コメントを表示。

## 6. 今後の拡張性
- 現在、HTMLテンプレートはC#コード内に埋め込まれていますが、外部ファイル (`template.html`) として分離することで、再コンパイルなしにデザイン変更が可能になります。
- インターネット接続がない環境（オフライン）で動作させるには、Chart.js をローカルリソースとして埋め込む必要があります。
