// ****************************************************************************
// ActivityMonitor - ローカル専用アクティビティ監視ツール
// ****************************************************************************
// 2025/12/16 ver.3.2.0.0 サーバへの送信機能
// 2025/12/16 ver.3.1.0.0 レポート期間指定・HTML出力改善
//  - カレンダーによるレポート対象期間の指定機能追加
//  - HTMLレポートファイル名への日付付与
//  - HTMLレポート出力ロジックの改善（不要なJS削除、期間内データの軽量出力）
// 2025/12/16 ver.3.0.0.0 レポート出力の視認性向上改修
//  - ウィンドウタイトル一覧の廃止（プライバシー・視認性配慮）
//  - JSONデータ駆動によるHTML描画へのリファクタリング
//  - 「総作業時間」を主要ヘッダーへ移動（Total Work Time -> 総作業時間）
//  - グラフ表示位置の最適化（スコアカード上部へ移動）
//  - 不要な統計情報（総レコード数・マウス・キーボード数）の削除
// 2025/12/15 ver.2.9.0.0 自動コメント生成機能追加・日次スコア計算ロジック修正
// 2025/12/13 ver.2.8.0.0 LastInputSecondsロジック最適化・Lock時間分離計測機能追加
// 2025/12/13 ver.2.7.0.0 Win32APIによるIdle時間計測実装・スイッチカウント精度向上
// 2025/12/12 ver.2.6.0.0 Win32イベント駆動による正確なウィンドウ切替カウント実装
// 2025/12/12 ver.2.5.0.0 30分単位スコア・コメントロジック実装
// 2025/12/10 ver.2.0.0.0 SQLite移行・ビューア分離
// 2025/12/08 ver.1.5.0.0 ウィンドウタイトル取得ロジック改善
// 2025/12/08 ver.1.0.0.0 初版作成 (XMLベース)
//
// 機能概要:
//  ユーザーのPC操作アクティビティ（アクティブウィンドウ、入力操作、アイドル時間など）を
//  記録し、生産性や集中度を可視化するローカル常駐型ツールです。
//
// 主な機能:
//  - アクティビティログの記録 (SQLiteデータベース)
//    - 操作ウィンドウタイトル、プロセス名
//    - マウス/キーボード入力有無
//    - アイドル時間、セッションロック状態
//  - レポート生成機能
//    - 1分単位のタイムラインチャート（稼働/リモート/ロック）
//    - アプリケーション別使用比率（円グラフ）
//    - 生産性・集中度スコアの自動算出
//  - システム機能
//    - タスクトレイ常駐・自動起動
//    - 単一実行ファイル（必要なDLLをリソース埋め込み）


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.IO;
using System.Linq;
using System.Xml.Linq;
using Microsoft.Win32;
using System.Reflection;
using System.Threading;
using UITimer = System.Windows.Forms.Timer;

// アセンブリ情報
[assembly: AssemblyVersion("3.2.0.0")]
[assembly: AssemblyFileVersion("3.2.0.0")]
[assembly: AssemblyInformationalVersion("3200")]
[assembly: AssemblyProduct("ActivityMonitor")]
[assembly: AssemblyCopyright("ローカル専用アクティビティ監視ツール")]

class Program
{
    // ****************************************************************************
    // Win32 API宣言
    // ****************************************************************************
    [DllImport("user32.dll")]
    static extern IntPtr GetForegroundWindow();

    [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    private static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);

    [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    private static extern int GetWindowTextLength(IntPtr hWnd);

    [DllImport("user32.dll")]
    static extern int GetWindowThreadProcessId(IntPtr hWnd, out int lpdwProcessId);

    [DllImport("user32.dll")]
    private static extern int GetAsyncKeyState(int vKey);

    [DllImport("kernel32.dll")]
    static extern bool AllocConsole();

    [DllImport("kernel32.dll")]
    static extern bool FreeConsole();

    [DllImport("kernel32.dll")]
    static extern IntPtr GetConsoleWindow();

    [DllImport("user32.dll")]
    static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

    [DllImport("kernel32.dll")]
    static extern uint WTSGetActiveConsoleSessionId();

    [DllImport("user32.dll")]
    static extern int GetSystemMetrics(int nIndex);

    [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    private static extern bool SetDllDirectory(string lpPathName);

    const int SM_REMOTESESSION = 0x1000;

    [STAThread]
    static void Main()
    {
        // ****************************************************************************
        // DLLロード処理 (埋め込みリソース & Temp展開)
        // ****************************************************************************
        // マネージドDLLの解決
        AppDomain.CurrentDomain.AssemblyResolve += (sender, args) =>
        {
            String resourceName = "ActivityMonitor." + new AssemblyName(args.Name).Name + ".dll";
            using (var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(resourceName))
            {
                if (stream == null) return null;
                Byte[] assemblyData = new Byte[stream.Length];
                stream.Read(assemblyData, 0, assemblyData.Length);
                return Assembly.Load(assemblyData);
            }
        };

        // アンマネージドDLL (SQLite.Interop.dll) のTemp展開
        string tempPath = Path.Combine(Path.GetTempPath(), "ActivityMonitor_Libs");
        Directory.CreateDirectory(tempPath);
        ExtractResourceDll("SQLite.Interop.dll", tempPath);
        
        // DLL検索パスに追加
        SetDllDirectory(tempPath);

        // ****************************************************************************
        // アセンブリ情報取得
        // ****************************************************************************
        var fileVersionInfo = FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location);
        var ProductName = fileVersionInfo.ProductName;
        string FileVersion = fileVersionInfo.FileVersion;
        string ProductVersion = fileVersionInfo.ProductVersion;

        Console.WriteLine("[アセンブリ情報]");
        Console.WriteLine("製品: {0}", ProductName);
        Console.WriteLine("ファイルバージョン: {0}", FileVersion);
        Console.WriteLine("製品バージョン: {0}", ProductVersion);

        // ****************************************************************************
        // 二重起動防止
        // ****************************************************************************
        string mutexName = "ActivityMonitor_Mutex";
        bool createdNew;
        System.Threading.Mutex mutex = new System.Threading.Mutex(true, mutexName, out createdNew);

        if (createdNew == false)
        {
            MessageBox.Show("既に起動しています", ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            mutex.Close();
            return;
        }

        try
        {
            Application.EnableVisualStyles();
            new MainForm();
            Application.Run();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message + "\r\n" + ex.StackTrace, ProductName + " エラー", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally
        {
            mutex.ReleaseMutex();
            mutex.Close();
        }
    }

    // ****************************************************************************
    // リソースからDLLを展開
    // ****************************************************************************
    static void ExtractResourceDll(string dllName, string outDir)
    {
        string path = Path.Combine(outDir, dllName);
        if (!File.Exists(path))
        {
            try 
            {
                var assembly = Assembly.GetExecutingAssembly();
                string resourceName = "ActivityMonitor." + dllName;

                using (Stream stream = assembly.GetManifestResourceStream(resourceName))
                {
                    if (stream != null)
                    {
                        using (FileStream fileStream = new FileStream(path, FileMode.Create))
                        {
                            stream.CopyTo(fileStream);
                        }
                    }
                }
            }
            catch { /* エラーは無視 */ }
        }
    }

    // ****************************************************************************
    // メインフォーム
    // ****************************************************************************
    class MainForm : Form
    {
        // ****************************************************************************
        // 変数宣言
        // ****************************************************************************
        int processId, sec, mouse, keyboard, key_count, key_flag;
        long memory;
        string processName, taskTitle, taskTitle_prev;
        string machine, user, domain;
        string dbPath, settingPath;
        string session_current, session_prev;
        string username;
        bool debugMode;
        bool isRemote;
        bool autoStart;
        string serverUrl = ""; // サーバURL

        DateTime startTime;
        IntPtr hWnd;
        UITimer timer = new UITimer();

        // ****************************************************************************
        // セッション監視
        // ****************************************************************************
        private static SessionSwitchEventHandler sessionHandler;

        // ****************************************************************************
        // 通知領域アイコン
        // ****************************************************************************
        private System.Windows.Forms.NotifyIcon notifyIcon;
        private System.Windows.Forms.ContextMenu contextMenu;
        private System.Windows.Forms.MenuItem menuItemSettings;
        private System.Windows.Forms.MenuItem menuItemExit;
        private System.ComponentModel.IContainer components;

        // ****************************************************************************
        // 設定画面コントロール
        // ****************************************************************************
        TextBox textboxUsername = new TextBox();
        Label labelMessage = new Label();
        Label labelVersion = new Label();
        Label labelUsernameTitle = new Label();
        CheckBox checkboxAutoStart = new CheckBox();
        Button saveButton;
        Button viewDataButton;
        Button closeButton;
        private MonthCalendar reportCalendar; // カレンダー追加
        
        // サーバ同期用コントロール
        Label labelServerUrl = new Label();
        TextBox textboxServerUrl = new TextBox();
        Button syncButton;
        
        // ウィンドウ切替トラッカー
        WindowSwitchTracker switchTracker;
        int lastSwitchCount = 0;
        int _currentRecordSwitches = 0; // 現在のレコード（アクティビティ）内でのスイッチ回数蓄積

        // アイドル時間トラッカー
        IdleTracker idleTracker;
        int _currentRecordIdleSeconds = 0;
        int _currentRecordLockSeconds = 0; // Lock時間

        // ****************************************************************************
        // コンストラクタ
        // ****************************************************************************
        public MainForm()
        {
            // ****************************************************************************
            // ユーザー情報取得
            // ****************************************************************************
            machine = Environment.MachineName;
            user = Environment.UserName;
            domain = Environment.UserDomainName;

            Console.WriteLine("ユーザー: " + user);
            Console.WriteLine("マシン: " + machine);
            Console.WriteLine("ドメイン: " + domain);

            // ****************************************************************************
            // バージョン情報取得
            // ****************************************************************************
            var fileVersionInfo = FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location);
            string FileVersion = fileVersionInfo.FileVersion;
            var ProductName = fileVersionInfo.ProductName;

            // ****************************************************************************
            // ローカルパス設定
            // ****************************************************************************
            try
            {
                string folder = System.Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                dbPath = string.Format(@"{0}\ActivityMonitor\{1}.db", folder, user);
                settingPath = string.Format(@"{0}\ActivityMonitor\setting.xml", folder);

                // フォルダ作成
                if (!Directory.Exists(folder + @"\ActivityMonitor"))
                {
                    DirectoryInfo dir = new DirectoryInfo(folder + @"\ActivityMonitor");
                    dir.Create();
                    Console.WriteLine("フォルダ作成: {0}", dir);
                }

                Console.WriteLine("データベースパス: {0}", dbPath);
                Console.WriteLine("設定パス: {0}", settingPath);
            }
            catch (Exception ex)
            {
                Console.WriteLine("パス設定エラー: {0}", ex.Message);
            }

            // ****************************************************************************
            // SQLiteデータベース初期化
            // ****************************************************************************
            try
            {
                InitializeDatabase();
                Console.WriteLine("データベース初期化完了");
            }
            catch (Exception ex)
            {
                Console.WriteLine("データベース初期化エラー: {0}", ex.Message);
            }

            // ****************************************************************************
            // タスクバーに非表示
            // ****************************************************************************
            this.ShowInTaskbar = false;

            // ****************************************************************************
            // コンテナ設定
            // ****************************************************************************
            this.components = new System.ComponentModel.Container();
            this.contextMenu = new System.Windows.Forms.ContextMenu();
            this.menuItemSettings = new System.Windows.Forms.MenuItem();
            this.menuItemExit = new System.Windows.Forms.MenuItem();

            // ****************************************************************************
            // 右クリックメニュー設定
            // ****************************************************************************
            this.contextMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] { this.menuItemSettings });
            this.contextMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] { this.menuItemExit });

            this.menuItemSettings.Index = 0;
            this.menuItemSettings.Text = "&設定画面を開く";
            this.menuItemSettings.Click += new System.EventHandler(this.MenuItemSettings_Click);

            this.menuItemExit.Index = 1;
            this.menuItemExit.Text = "&終了";
            this.menuItemExit.Click += new System.EventHandler(this.MenuItemExit_Click);

            // ****************************************************************************
            // 通知アイコン設定
            // ****************************************************************************
            this.notifyIcon = new System.Windows.Forms.NotifyIcon(this.components);
            
            // カスタムアイコンを読み込み
            string iconPath = System.IO.Path.Combine(System.IO.Path.GetDirectoryName(Application.ExecutablePath), "icon.ico");
            if (File.Exists(iconPath))
            {
                notifyIcon.Icon = new Icon(iconPath);
            }
            else
            {
                notifyIcon.Icon = SystemIcons.Application;
            }
            
            notifyIcon.ContextMenu = this.contextMenu;
            notifyIcon.Text = ProductName;
            notifyIcon.Visible = true;
            notifyIcon.DoubleClick += new System.EventHandler(this.NotifyIcon_DoubleClick);

            // ****************************************************************************
            // フォームクロージングイベント
            // ****************************************************************************
            this.FormClosing += new FormClosingEventHandler(MainForm_FormClosing);

            // ****************************************************************************
            // フォームを常に最前面
            // ****************************************************************************
            this.TopMost = true;

            // ****************************************************************************
            // 設定読み込み
            // ****************************************************************************
            username = "";
            debugMode = false;
            SettingRead();

            // ****************************************************************************
            // キーボードショートカット設定 (Ctrl+D でデバッグモード切り替え)
            // ****************************************************************************
            this.KeyPreview = true;
            this.KeyDown += new KeyEventHandler(MainForm_KeyDown);

            // ****************************************************************************
            // 設定が未設定の場合はフォーム表示
            // ****************************************************************************
            if (username == "")
            {
                this.Visible = true;
                this.Activate();
                labelMessage.Text = "ユーザー名を入力してください";
            }
            else
            {
                this.Visible = false;
            }

            // ****************************************************************************
            // デバッグモードが有効な場合はコンソール表示
            // ****************************************************************************
            if (debugMode)
            {
                AllocConsole();
                
                // コンソールのエンコーディングをUTF-8に設定
                Console.OutputEncoding = System.Text.Encoding.UTF8;
                
                // 標準出力をコンソールにリダイレクト
                System.IO.StreamWriter writer = new System.IO.StreamWriter(Console.OpenStandardOutput(), System.Text.Encoding.UTF8);
                writer.AutoFlush = true;
                Console.SetOut(writer);
                
                Console.WriteLine("========================================");
                Console.WriteLine("ActivityMonitor - デバッグモード");
                Console.WriteLine("========================================");
                Console.WriteLine("ユーザー: {0}", user);
                Console.WriteLine("マシン: {0}", machine);
                Console.WriteLine("データパス: {0}", dbPath);
                Console.WriteLine("========================================");
                Console.WriteLine("");
            }

            // ****************************************************************************
            // フォーム設定
            // ****************************************************************************
            // ****************************************************************************
            // フォーム設定
            // ****************************************************************************
            this.ClientSize = new System.Drawing.Size(350, 500); // サイズ拡張 (同期設定用)
            this.Text = ProductName;

            // ****************************************************************************
            // ラベル設定
            // ****************************************************************************
            labelMessage.Location = new Point(30, 10); // 上部へ移動
            labelMessage.AutoSize = true;
            this.Controls.Add(labelMessage);

            labelUsernameTitle.Text = "ユーザー名";
            labelUsernameTitle.Location = new Point(30, 35); // 配置調整
            labelUsernameTitle.AutoSize = true;
            this.Controls.Add(labelUsernameTitle);

            textboxUsername.Text = username;
            textboxUsername.Location = new Point(120, 32); // 配置調整
            textboxUsername.Size = new Size(180, 20);
            this.Controls.Add(textboxUsername);

            // ****************************************************************************
            // チェックボックス設定
            // ****************************************************************************
            checkboxAutoStart.Text = "PC起動時に自動起動";
            checkboxAutoStart.Location = new Point(30, 60); // 配置調整
            checkboxAutoStart.AutoSize = true;
            checkboxAutoStart.Checked = autoStart;
            this.Controls.Add(checkboxAutoStart);

            // ****************************************************************************
            // カレンダー設定
            // ****************************************************************************
            reportCalendar = new MonthCalendar();
            reportCalendar.Location = new Point(30, 90);
            this.Controls.Add(reportCalendar);

            // ****************************************************************************
            // ボタン設定
            // ****************************************************************************
            viewDataButton = new Button()
            {
                Text = "データ表示 (HTMLレポート)",
                Location = new Point(30, 260),
                Size = new Size(290, 30),
            };
            viewDataButton.Click += new EventHandler(ViewDataButton_Click);
            this.Controls.Add(viewDataButton);

            // ****************************************************************************
            // サーバ設定
            // ****************************************************************************
            labelServerUrl.Text = "サーバURL:";
            labelServerUrl.Location = new Point(30, 300); // カレンダーの下
            labelServerUrl.AutoSize = true;
            this.Controls.Add(labelServerUrl);

            textboxServerUrl.Text = serverUrl;
            textboxServerUrl.Location = new Point(30, 320);
            textboxServerUrl.Size = new Size(290, 20);
            this.Controls.Add(textboxServerUrl);

            syncButton = new Button()
            {
                Text = "サーバへ送信 (同期)",
                Location = new Point(30, 350),
                Size = new Size(290, 30),
            };
            syncButton.Click += new EventHandler(SyncButton_Click);
            this.Controls.Add(syncButton);

            saveButton = new Button()
            {
                Text = "設定保存",
                Location = new Point(30, 400),
                Size = new Size(130, 30),
            };
            saveButton.Click += new EventHandler(SaveButton_Click);
            this.Controls.Add(saveButton);

            closeButton = new Button()
            {
                Text = "閉じる",
                Location = new Point(190, 400),
                Size = new Size(130, 30),
            };
            closeButton.Click += new EventHandler(CloseButton_Click);
            this.Controls.Add(closeButton);
            
            labelVersion.Location = new Point(200, 450); // 最下部へ移動

            // ****************************************************************************
            // セッション監視設定
            // ****************************************************************************
            sessionHandler = new SessionSwitchEventHandler(SystemEvents_SessionSwitch);
            SystemEvents.SessionSwitch += sessionHandler;
            session_current = "SessionUnlock";

            // ****************************************************************************
            // データベース・トラッカー初期化
            // ****************************************************************************
            InitializeDatabase();
            switchTracker = new WindowSwitchTracker();
            idleTracker = new IdleTracker();
            
            // ****************************************************************************
            // 初期データ取得
            // ****************************************************************************
            WindowCapture();
            mouse = 0;
            keyboard = 0;
            key_flag = 0;
            taskTitle_prev = taskTitle;
            startTime = DateTime.Now;
            sec = 0;

            try
            {
                memory = Environment.WorkingSet;
            }
            catch (Exception ex)
            {
                Console.WriteLine("メモリ取得エラー: {0}", ex.Message);
            }

            SqliteInsert();

            // ****************************************************************************
            // タイマー開始
            // ****************************************************************************
            timer.Interval = 100; // 100ms
            timer.Tick += new EventHandler(Timer_Tick);
            timer.Start();

            // ****************************************************************************
            // 起動時自動同期 (サイレント)
            // ****************************************************************************
            SyncData(true);
        }



        // ****************************************************************************
        // タイマー処理
        // ****************************************************************************
        void Timer_Tick(object sender, EventArgs e)
        {
            // キーボード・マウスカウント
            KeyboardCount();
            key_count++;

            // 1秒ごとに処理
            if (key_count >= 10)
            {
                key_count = 0;
                
                // スイッチカウント更新
                if (switchTracker != null)
                {
                    int currentTotal = switchTracker.WindowSwitchCount;
                    int delta = currentTotal - lastSwitchCount;
                    if (delta > 0)
                    {
                       _currentRecordSwitches += delta;
                       lastSwitchCount = currentTotal;
                    }
                }

                // アイドル・ロック時間更新
                if (idleTracker != null)
                {
                    // セッション状態を渡して判定
                    idleTracker.Tick(session_current); 
                    
                    // 現在のレコード内での累積値を取得
                    _currentRecordIdleSeconds = idleTracker.TotalIdleSeconds;
                    _currentRecordLockSeconds = idleTracker.TotalLockSeconds;
                }

                WindowCapture();
                isRemote = CheckIsRemoteSession();

                DateTime now = DateTime.Now;
                try
                {
                    TimeSpan ts = now - startTime;
                    sec = (int)ts.TotalSeconds;
                }
                catch (Exception ex)
                {
                    Console.WriteLine("時間計算エラー: {0}", ex.Message);
                }

                if (sec > 0)
                {
                    // ウィンドウまたはセッションが変わった場合
                    if (taskTitle != taskTitle_prev || session_current != session_prev)
                    {
                        SqliteUpdate();

                        // 新しいレコード開始
                        mouse = 0;
                        keyboard = 0;
                        key_flag = 0;
                        taskTitle_prev = taskTitle;
                        startTime = now;
                        sec = 0;
                        session_prev = session_current;
                        
                        // トラッカー（レコード単位）リセット
                        // スイッチカウントは差分方式なのでここでクリア
                        _currentRecordSwitches = 0;
                        
                        // アイドル・ロックスイッチもリセット
                        _currentRecordIdleSeconds = 0;
                        _currentRecordLockSeconds = 0;
                        if (idleTracker != null) idleTracker.Reset();

                        try
                        {
                            memory = Environment.WorkingSet;
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine("メモリ取得エラー: {0}", ex.Message);
                        }

                        SqliteInsert();

                        // デバッグモード: データ表示
                        if (debugMode)
                        {
                            Console.WriteLine("[{0}] {1}", DateTime.Now.ToString("HH:mm:ss"), taskTitle);
                            Console.WriteLine("  プロセス: {0}", processName);
                            Console.WriteLine("  セッション: {0}", session_current);
                            Console.WriteLine("  マウス: {0} / キーボード: {1}", mouse, keyboard);
                            Console.WriteLine("  メモリ: {0:N0} bytes", memory);
                            Console.WriteLine("");
                        }
                    }
                    else if (taskTitle == taskTitle_prev)
                    {
                        // 同じウィンドウでキー入力があった場合のみ更新
                        if (key_flag == 1)
                        {
                            SqliteUpdate();
                            key_flag = 0;

                            // デバッグモード: 更新表示
                            if (debugMode)
                            {
                                Console.WriteLine("[{0}] UPDATE - {1}秒 (マウス:{2} / キーボード:{3})", 
                                    DateTime.Now.ToString("HH:mm:ss"), sec, mouse, keyboard);
                            }
                        }
                    }
                }
            }
        }

        // ****************************************************************************
        // セッション切り替え
        // ****************************************************************************
        void SystemEvents_SessionSwitch(object sender, SessionSwitchEventArgs e)
        {
            try
            {
                session_current = e.Reason.ToString();
                Console.WriteLine("セッション: {0} -> {1}", session_prev, session_current);
            }
            catch (Exception ex)
            {
                Console.WriteLine("セッション取得エラー: {0}", ex.Message);
            }
        }

        // ****************************************************************************
        // リモート接続判定
        // ****************************************************************************
        bool CheckIsRemoteSession()
        {
            try
            {
                return GetSystemMetrics(SM_REMOTESESSION) != 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine("リモート接続判定エラー: {0}", ex.Message);
                return false;
            }
        }

        // ****************************************************************************
        // データベース初期化
        // ****************************************************************************
        void InitializeDatabase()
        {
            if (!File.Exists(dbPath))
            {
                SQLiteConnection.CreateFile(dbPath);
                Console.WriteLine("データベースファイル作成: {0}", dbPath);
            }

            using (var connection = new SQLiteConnection("Data Source=" + dbPath + ";Version=3;"))
            {
                connection.Open();

                string createTableSql = @"
                    CREATE TABLE IF NOT EXISTS activity_records (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        uptime TEXT NOT NULL,
                        username TEXT,
                        machine TEXT,
                        task TEXT,
                        process TEXT,
                        sec INTEGER,
                        mouse INTEGER,
                        keyboard INTEGER,
                        session TEXT,
                        memory INTEGER,
                        isRemote INTEGER,
                        created_at TEXT DEFAULT CURRENT_TIMESTAMP
                    )";

                using (var command = new SQLiteCommand(createTableSql, connection))
                {
                    command.ExecuteNonQuery();
                }

                string createScoreTableSql = @"
                    CREATE TABLE IF NOT EXISTS daily_scores (
                        date TEXT PRIMARY KEY,
                        productivity_score REAL,
                        focus_score REAL,
                        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
                    )";

                using (var command = new SQLiteCommand(createScoreTableSql, connection))
                {
                    command.ExecuteNonQuery();
                }

                // カラム追加（マイグレーション: switch_count）
                try
                {
                    using (var command = new SQLiteCommand("ALTER TABLE activity_records ADD COLUMN switch_count INTEGER DEFAULT 0", connection))
                    {
                        command.ExecuteNonQuery();
                    }
                }
                catch { }

                // カラム追加（マイグレーション: idle_seconds）
                try
                {
                    using (var command = new SQLiteCommand("ALTER TABLE activity_records ADD COLUMN idle_seconds INTEGER DEFAULT 0", connection))
                    {
                        command.ExecuteNonQuery();
                    }
                }
                catch { }

                // カラム追加（マイグレーション: lock_seconds）
                try
                {
                    using (var command = new SQLiteCommand("ALTER TABLE activity_records ADD COLUMN lock_seconds INTEGER DEFAULT 0", connection))
                    {
                        command.ExecuteNonQuery();
                    }
                }
                catch { }

                // カラム追加（マイグレーション: synced）
                try
                {
                    using (var command = new SQLiteCommand("ALTER TABLE activity_records ADD COLUMN synced INTEGER DEFAULT 0", connection))
                    {
                        command.ExecuteNonQuery();
                    }
                }
                catch { }

                // インデックス作成
                string[] indexes = {
                    "CREATE INDEX IF NOT EXISTS idx_uptime ON activity_records(uptime)",
                    "CREATE INDEX IF NOT EXISTS idx_username ON activity_records(username)",
                    "CREATE INDEX IF NOT EXISTS idx_created_at ON activity_records(created_at)",
                    "CREATE INDEX IF NOT EXISTS idx_synced ON activity_records(synced)"
                };

                foreach (var indexSql in indexes)
                {
                    using (var command = new SQLiteCommand(indexSql, connection))
                    {
                        command.ExecuteNonQuery();
                    }
                }
            }

            // XMLからのデータ移行
            ImportFromXml();
        }

        // ****************************************************************************
        // XMLからのデータ移行
        // ****************************************************************************
        void ImportFromXml()
        {
            string folder = System.Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string xmlPath = string.Format(@"{0}\ActivityMonitor\{1}.xml", folder, user);

            if (File.Exists(xmlPath))
            {
                Console.WriteLine("既存のXMLデータを検出しました。インポートを開始します: {0}", xmlPath);
                try
                {
                    XElement xml = XElement.Load(xmlPath);
                    var records = xml.Elements("record");
                    int count = 0;

                    using (var connection = new SQLiteConnection("Data Source=" + dbPath + ";Version=3;"))
                    {
                        connection.Open();
                        using (var transaction = connection.BeginTransaction())
                        {
                            foreach (var record in records)
                            {
                                string uptime = record.Element("uptime").Value;
                                string task = record.Element("task").Value;
                                string process = record.Element("process").Value;
                                string sec = record.Element("sec").Value;
                                string mouse = record.Element("mouse").Value;
                                string keyboard = record.Element("keyboard").Value;
                                string session = record.Element("session").Value;
                                string memoryVal = record.Element("memory") != null ? record.Element("memory").Value : "0";
                                string isRemoteVal = record.Element("isRemote") != null ? record.Element("isRemote").Value : "False";
                                bool isRemoteBool = (isRemoteVal == "True");

                                string insertSql = @"
                                    INSERT INTO activity_records 
                                    (uptime, username, machine, task, process, sec, mouse, keyboard, session, memory, isRemote)
                                    VALUES 
                                    (@uptime, @username, @machine, @task, @process, @sec, @mouse, @keyboard, @session, @memory, @isRemote)";

                                using (var command = new SQLiteCommand(insertSql, connection))
                                {
                                    command.Parameters.AddWithValue("@uptime", uptime);
                                    command.Parameters.AddWithValue("@username", username);
                                    command.Parameters.AddWithValue("@machine", machine);
                                    command.Parameters.AddWithValue("@task", task);
                                    command.Parameters.AddWithValue("@process", process);
                                    command.Parameters.AddWithValue("@sec", int.Parse(sec));
                                    command.Parameters.AddWithValue("@mouse", int.Parse(mouse));
                                    command.Parameters.AddWithValue("@keyboard", int.Parse(keyboard));
                                    command.Parameters.AddWithValue("@session", session);
                                    command.Parameters.AddWithValue("@memory", long.Parse(memoryVal));
                                    command.Parameters.AddWithValue("@isRemote", isRemoteBool ? 1 : 0);
                                    
                                    command.ExecuteNonQuery();
                                }
                                count++;
                            }
                            transaction.Commit();
                        }
                    }

                    Console.WriteLine("インポート完了: {0} 件", count);
                    
                    // バックアップしてリネーム
                    string backupPath = xmlPath + ".backup";
                    if (File.Exists(backupPath)) File.Delete(backupPath);
                    File.Move(xmlPath, backupPath);
                    Console.WriteLine("XMLファイルをバックアップしました: {0}", backupPath);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("XMLインポートエラー: {0}", ex.Message);
                }
            }
        }

        // ****************************************************************************
        // データ挿入 (INSERT)
        // ****************************************************************************
        void SqliteInsert()
        {
            if (String.IsNullOrEmpty(taskTitle)) return;

            startTime = DateTime.Now;
            key_count = 0;
            key_flag = 0;
            mouse = 0;
            keyboard = 0;
            sec = 0;
            
            // 新しいレコード用変数リセット
            _currentRecordSwitches = 0;
            _currentRecordIdleSeconds = 0;
            _currentRecordLockSeconds = 0;

            try
            {
                using (var connection = new SQLiteConnection("Data Source=" + dbPath + ";Version=3;"))
                {
                    connection.Open();
                    using (var transaction = connection.BeginTransaction())
                    {
                        var sql = "INSERT INTO activity_records (uptime, username, machine, task, process, sec, mouse, keyboard, session, memory, isRemote, switch_count, idle_seconds, lock_seconds) VALUES (@uptime, @username, @machine, @task, @process, @sec, @mouse, @keyboard, @session, @memory, @isRemote, @switch_count, @idle_seconds, @lock_seconds)";
                        using (var command = new SQLiteCommand(sql, connection))
                        {
                            command.Parameters.AddWithValue("@uptime", startTime.ToString("yyyy-MM-dd HH:mm:ss"));
                            command.Parameters.AddWithValue("@username", username);
                            command.Parameters.AddWithValue("@machine", machine);
                            command.Parameters.AddWithValue("@task", taskTitle);
                            command.Parameters.AddWithValue("@process", processName);
                            command.Parameters.AddWithValue("@sec", 0);
                            command.Parameters.AddWithValue("@mouse", 0);
                            command.Parameters.AddWithValue("@keyboard", 0);
                            command.Parameters.AddWithValue("@session", session_current);
                            command.Parameters.AddWithValue("@memory", memory);
                            command.Parameters.AddWithValue("@isRemote", isRemote ? 1 : 0);
                            command.Parameters.AddWithValue("@switch_count", 0);
                            command.Parameters.AddWithValue("@idle_seconds", 0);
                            command.Parameters.AddWithValue("@lock_seconds", 0);
                            command.ExecuteNonQuery();
                        }
                        transaction.Commit();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("SQLite Insert Error: " + ex.Message);
            }
        }

        // ****************************************************************************
        // SQLiteデータ更新
        // ****************************************************************************
        void SqliteUpdate()
        {
            try
            {
                // ウィンドウ切り替えの集計（Timer_Tickで計算済み）
                
                using (var connection = new SQLiteConnection("Data Source=" + dbPath + ";Version=3;"))
                {
                    connection.Open();

                    string updateSql = @"
                        UPDATE activity_records 
                        SET sec = @sec, mouse = @mouse, keyboard = @keyboard, memory = @memory, switch_count = @switch_count, idle_seconds = @idle_seconds, lock_seconds = @lock_seconds
                        WHERE uptime = @uptime AND machine = @machine";

                    using (var command = new SQLiteCommand(updateSql, connection))
                    {
                        command.Parameters.AddWithValue("@sec", sec);
                        command.Parameters.AddWithValue("@mouse", mouse);
                        command.Parameters.AddWithValue("@keyboard", keyboard);
                        command.Parameters.AddWithValue("@memory", memory);
                        command.Parameters.AddWithValue("@switch_count", _currentRecordSwitches);
                        command.Parameters.AddWithValue("@idle_seconds", _currentRecordIdleSeconds);
                        command.Parameters.AddWithValue("@lock_seconds", _currentRecordLockSeconds);
                        command.Parameters.AddWithValue("@uptime", startTime.ToString("yyyy-MM-dd HH:mm:ss"));
                        command.Parameters.AddWithValue("@machine", machine);

                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("SQLite Update エラー: {0}", ex.Message);
            }
        }


        // ****************************************************************************
        // キーボード・マウスカウント
        // ****************************************************************************
        void KeyboardCount()
        {
            for (int i = 1; i <= 256; i++)
            {
                int rtn = GetAsyncKeyState(i);
                if ((rtn & 1) == 1)
                {
                    // マウスクリック(左・右)
                    if (i == 1 || i == 2)
                    {
                        mouse++;
                        key_flag = 1;
                    }
                    // キーボード(48以上)
                    else if (i > 47)
                    {
                        keyboard++;
                        key_flag = 1;
                    }
                }
            }
        }

        // ****************************************************************************
        // ウィンドウキャプチャ
        // ****************************************************************************
        void WindowCapture()
        {
            try
            {
                hWnd = GetForegroundWindow();
                int textLen = GetWindowTextLength(hWnd);
                StringBuilder tsb = new StringBuilder(textLen + 1);
                GetWindowText(hWnd, tsb, tsb.Capacity);
                taskTitle = tsb.ToString();
            }
            catch (Exception ex)
            {
                Console.WriteLine("ウィンドウキャプチャエラー: {0}", ex.Message);
            }

            try
            {
                GetWindowThreadProcessId(hWnd, out processId);
                processName = Process.GetProcessById(processId).ProcessName;
            }
            catch (Exception ex)
            {
                Console.WriteLine("プロセス取得エラー: {0}", ex.Message);
            }
        }



        // ****************************************************************************
        // 自動起動設定
        // ****************************************************************************
        void SetAutoStart(bool enable)
        {
            try
            {
                string appName = "ActivityMonitor";
                string appPath = Application.ExecutablePath;
                
                using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", true))
                {
                    if (enable)
                    {
                        key.SetValue(appName, appPath);
                        Console.WriteLine("自動起動を有効にしました");
                    }
                    else
                    {
                        if (key.GetValue(appName) != null)
                        {
                            key.DeleteValue(appName);
                            Console.WriteLine("自動起動を無効にしました");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("自動起動設定エラー: {0}", ex.Message);
            }
        }

        // ****************************************************************************
        // 自動起動取得
        // ****************************************************************************
        bool GetAutoStart()
        {
            try
            {
                string appName = "ActivityMonitor";
                
                using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", false))
                {
                    return key.GetValue(appName) != null;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("自動起動取得エラー: {0}", ex.Message);
                return false;
            }
        }

        // ****************************************************************************
        // 設定読み込み
        // ****************************************************************************
        void SettingRead()
        {
            if (File.Exists(settingPath))
            {
                try
                {
                    XElement xml = XElement.Load(settingPath);
                    
                    // 最新の設定を取得(最後の要素)
                    XElement latestSetting = xml.Elements("setting").LastOrDefault();
                    
                    if (latestSetting != null)
                    {
                        username = latestSetting.Element("username").Value;
                        
                        // デバッグモード設定読み込み
                        if (latestSetting.Element("debugMode") != null)
                        {
                            debugMode = bool.Parse(latestSetting.Element("debugMode").Value);
                        }
                        
                        // 自動起動設定読み込み
                        if (latestSetting.Element("autoStart") != null)
                        {
                            autoStart = bool.Parse(latestSetting.Element("autoStart").Value);
                        }

                        // サーバURL設定読み込み
                        if (latestSetting.Element("serverUrl") != null)
                        {
                            serverUrl = latestSetting.Element("serverUrl").Value;
                        }
                    }

                    Console.WriteLine("ユーザー名: {0}", username);
                    Console.WriteLine("デバッグモード: {0}", debugMode);
                    Console.WriteLine("自動起動: {0}", autoStart);
                    Console.WriteLine("サーバURL: {0}", serverUrl);
                    
                    // レジストリの状態を確認して同期
                    bool registryAutoStart = GetAutoStart();
                    if (autoStart != registryAutoStart)
                    {
                        SetAutoStart(autoStart);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("設定読み込みエラー: {0}", ex.Message);
                }
            }
            else
            {
                // レジストリから自動起動状態を取得
                autoStart = GetAutoStart();
            }
        }

        // ****************************************************************************
        // 設定書き込み
        // ****************************************************************************
        void SettingWrite()
        {
            try
            {
                if (!File.Exists(settingPath))
                {
                    StreamWriter sw = new StreamWriter(settingPath, true, Encoding.GetEncoding("utf-8"));
                    sw.Write("<?xml version=\"1.0\" encoding=\"utf-8\"?>\r\n<settings>\r\n</settings>\r\n");
                    sw.Close();
                }

                XElement xml = XElement.Load(settingPath);

                XElement newSetting = new XElement("setting",
                    new XElement("username", username),
                    new XElement("machine", machine),
                    new XElement("domain", domain),
                    new XElement("user", user),
                    new XElement("debugMode", debugMode.ToString()),
                    new XElement("autoStart", autoStart.ToString()),
                    new XElement("serverUrl", serverUrl), // Add serverUrl here
                    new XElement("created", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")));

                xml.Add(newSetting);
                xml.Save(settingPath);

                Console.WriteLine("設定保存完了");
            }
            catch (Exception ex)
            {
                Console.WriteLine("設定書き込みエラー: {0}", ex.Message);
            }
        }

        // ****************************************************************************
        // 通知アイコンダブルクリック
        // ****************************************************************************
        void NotifyIcon_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                if (this.Visible == true)
                {
                    this.Visible = false;
                }
                else
                {
                    this.Visible = true;
                    this.Activate();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("アイコンクリックエラー: {0}", ex.Message);
            }
        }

        // ****************************************************************************
        // メニュー: 設定画面を開く
        // ****************************************************************************
        void MenuItemSettings_Click(object sender, EventArgs e)
        {
            try
            {
                this.Visible = true;
                this.Activate();
            }
            catch (Exception ex)
            {
                Console.WriteLine("設定画面表示エラー: {0}", ex.Message);
            }
        }

        // ****************************************************************************
        // メニュー: 終了
        // ****************************************************************************
        void MenuItemExit_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult result = MessageBox.Show("終了しますか?", "確認", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    notifyIcon.Visible = false;
                    Environment.Exit(0);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("終了処理エラー: {0}", ex.Message);
            }
        }

        // ****************************************************************************
        // フォームクロージング
        // ****************************************************************************
        void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                this.Visible = false;
                e.Cancel = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("フォームクローズエラー: {0}", ex.Message);
            }
        }

        // ****************************************************************************
        // 保存ボタンクリック
        // ****************************************************************************
        void SaveButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (textboxUsername.Text == "")
                {
                    labelMessage.Text = "ユーザー名を入力してください";
                    labelMessage.ForeColor = Color.Red;
                    return;
                }

                username = textboxUsername.Text;
                serverUrl = textboxServerUrl.Text; // サーバURL保存
                autoStart = checkboxAutoStart.Checked;
                autoStart = checkboxAutoStart.Checked;
                
                // レジストリに自動起動設定を反映
                SetAutoStart(autoStart);
                
                SettingWrite();

                MessageBox.Show("保存しました", ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                labelMessage.Text = ""; // メッセージラベルはクリア
            }
            catch (Exception ex)
            {
                Console.WriteLine("保存ボタンエラー: {0}", ex.Message);
            }
        }

        // ****************************************************************************
        // キーボードショートカット (Ctrl+D でデバッグモード切り替え)
        // ****************************************************************************
        void MainForm_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.D)
            {
                debugMode = !debugMode;
                ToggleDebugMode();
                e.Handled = true;
            }
        }

        // ****************************************************************************
        // 閉じるボタンクリック
        // ****************************************************************************
        void CloseButton_Click(object sender, EventArgs e)
        {
            this.Visible = false;
        }

        // ****************************************************************************
        // データ表示ボタンクリック
        // ****************************************************************************
        void ViewDataButton_Click(object sender, EventArgs e)
        {
            try
            {
                // カレンダーの日付範囲を使用
                DateTime start = reportCalendar.SelectionRange.Start;
                DateTime end = reportCalendar.SelectionRange.End;
                string startStr = start.ToString("yyyy-MM-dd 00:00:00");
                string endStr = end.ToString("yyyy-MM-dd 23:59:59");

                if (!File.Exists(dbPath))
                {
                    MessageBox.Show("データベースファイルが見つかりません。", "エラー", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // SQLiteからデータを読み込み
                var allRecords = new List<Dictionary<string, string>>();
                // スコア計算用
                var workLogs = new List<WorkLog>();
                
                using (var connection = new SQLiteConnection("Data Source=" + dbPath + ";Version=3;"))
                {
                    connection.Open();
                    
                    string selectSql = "SELECT * FROM activity_records WHERE uptime >= @start AND uptime <= @end ORDER BY uptime DESC";
                    
                    using (var command = new SQLiteCommand(selectSql, connection))
                    {
                        command.Parameters.AddWithValue("@start", startStr);
                        command.Parameters.AddWithValue("@end", endStr);

                        using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var record = new Dictionary<string, string>();
                            string uptimeStr = reader["uptime"].ToString();
                            record["uptime"] = uptimeStr;
                            record["username"] = reader["username"].ToString();
                            record["machine"] = reader["machine"].ToString();
                            string task = reader["task"].ToString();
                            record["task"] = task;
                            string process = reader["process"].ToString();
                            record["process"] = process;
                            string secStr = reader["sec"].ToString();
                            record["sec"] = secStr;
                            string mouseStr = reader["mouse"].ToString();
                            record["mouse"] = mouseStr;
                            string keyboardStr = reader["keyboard"].ToString();
                            record["keyboard"] = keyboardStr;
                            string session = reader["session"].ToString();
                            record["session"] = session;
                            record["isRemote"] = reader["isRemote"] != DBNull.Value ? reader["isRemote"].ToString() : "0";
                            record["memory"] = reader["memory"].ToString();
                            
                            // アイドル時間（無い場合は0）
                            string idleStr = "0";
                            try { idleStr = reader["idle_seconds"].ToString(); } catch { }
                            record["idle_seconds"] = idleStr;

                            // ロック時間（無い場合は0）
                            string lockStr = "0";
                            try { lockStr = reader["lock_seconds"].ToString(); } catch { }
                            record["lock_seconds"] = lockStr;
                            
                            // スイッチカウント（無い場合は0）
                            string switchStr = "0";
                            try { switchStr = reader["switch_count"].ToString(); } catch { }
                            record["switch_count"] = switchStr;
                            
                            allRecords.Add(record);

                            // WorkLog変換
                            DateTime dt;
                            if (DateTime.TryParse(uptimeStr, out dt))
                            {
                                int duration = 0, mouseCnt = 0, keyCnt = 0, switchCnt = 0, idleSec = 0, lockSec = 0;
                                int.TryParse(secStr, out duration);
                                int.TryParse(mouseStr, out mouseCnt);
                                int.TryParse(keyboardStr, out keyCnt);
                                int.TryParse(switchStr, out switchCnt);
                                int.TryParse(idleStr, out idleSec);
                                int.TryParse(lockStr, out lockSec);

                                workLogs.Add(new WorkLog
                                {
                                    DateTime = dt,
                                    Process = process,
                                    DurationSec = duration,
                                    MouseCount = mouseCnt,
                                    KeyboardCount = keyCnt,
                                    SwitchCount = switchCnt,
                                    IdleSeconds = idleSec,
                                    LockSeconds = lockSec,
                                    SessionState = session
                                });
                            }
                        }
                    }
                    }
                }

                // 30分単位スコア計算
                var allBlockScores = TimeBlockScoreCalculator.Calculate(workLogs);
                var blockScoreJson = new StringBuilder();
                blockScoreJson.Append("const blockScoreData = {");
                
                var blocksByDate = allBlockScores.GroupBy(b => b.BlockStart.ToString("yyyy-MM-dd"));
                
                // スコア計算 (日ごと) - 30分ブロックの平均値を採用
                var dailyScores = new Dictionary<string, string>(); 

                foreach(var group in blocksByDate) {
                    var dateKey = group.Key;
                    var blocks = group.ToList();

                    // ブロックごとのスコアの平均を算出
                    double avgProd = blocks.Any() ? blocks.Average(b => b.ProductivityScore) : 0;
                    double avgFocus = blocks.Any() ? blocks.Average(b => b.FocusScore) : 0;
                    
                    dailyScores[dateKey] = string.Format("{{ p: {0}, f: {1} }}", avgProd, avgFocus);

                    // JSON生成
                    blockScoreJson.Append(string.Format("'{0}': [", dateKey));
                    foreach(var block in blocks) {
                        blockScoreJson.Append(string.Format("{{ t: '{0}-{1}', p: {2}, f: {3}, proc: '{4}', c: '{5}' }},",
                            block.BlockStart.ToString("HH:mm"),
                            block.BlockEnd.ToString("HH:mm"),
                            block.ProductivityScore,
                            block.FocusScore,
                            block.DominantProcess.Replace("'", ""),
                            block.Comment.Replace("'", "")
                        ));
                    }
                    blockScoreJson.Append("],");
                }
                blockScoreJson.Append("};");

                // JS用データ構築
                StringBuilder jsScoreData = new StringBuilder();
                jsScoreData.Append("const dailyScoresData = {");
                foreach (var kvp in dailyScores)
                {
                    jsScoreData.Append(string.Format("'{0}': {1},", kvp.Key, kvp.Value));
                }
                jsScoreData.Append("};");
                jsScoreData.Append(blockScoreJson.ToString());


                // 全レコードをJSONデータとして準備
                StringBuilder rawDataBuilder = new StringBuilder();
                rawDataBuilder.Append("const rawData = [");
                foreach (var record in allRecords)
                {
                    string u = record["uptime"]; // yyyy-MM-dd HH:mm:ss
                    // エスケープ処理
                    string t = record["task"].Replace("\\", "\\\\").Replace("'", "\\'").Replace("\"", "\\\""); 
                    string p = record["process"];
                    string secStr = record["sec"].Split('.')[0];
                    string m = record["mouse"];
                    string k = record["keyboard"];
                    string sess = record["session"];
                    string rem = record.ContainsKey("isRemote") ? record["isRemote"] : "0";
                    
                    rawDataBuilder.Append(string.Format("{{u:'{0}', t:'{1}', p:'{2}', s:{3}, m:{4}, k:{5}, sess:'{6}', rem:{7}}},", 
                        u, t, p, secStr, m, k, sess, rem));
                }
                // Remove trailing comma if any records were added
                if (allRecords.Any())
                {
                    rawDataBuilder.Length--; // Remove last comma
                }
                rawDataBuilder.Append("];");

                // HTMLを生成
                string appPath = System.IO.Path.GetDirectoryName(Application.ExecutablePath);
                string htmlPath = System.IO.Path.Combine(appPath, "ActivityMonitor_Data_" + start.ToString("yyyyMMdd") + ".html");
                
                StringBuilder html = new StringBuilder();
                html.AppendLine("<!DOCTYPE html>");
                html.AppendLine("<html>");
                html.AppendLine("<head>");
                html.AppendLine("<meta charset='UTF-8'>");
                html.AppendLine("<title>ActivityMonitor - データ履歴 (" + start.ToString("yyyy-MM-dd") + " ～ " + end.ToString("yyyy-MM-dd") + ")</title>");
                html.AppendLine("<script src='https://cdn.jsdelivr.net/npm/chart.js'></script>");
                html.AppendLine("<style>");
                html.AppendLine("body { font-family: 'Segoe UI', Meiryo, sans-serif; margin: 20px; background: #f5f5f5; }");
                html.AppendLine("h1 { color: #333; border-bottom: 3px solid #4CAF50; padding-bottom: 10px; }");
                html.AppendLine("h2 { color: #333; margin-top: 30px; padding-bottom: 10px; display: flex; align-items: center; justify-content: space-between; }"); // Flex for header stats
                html.AppendLine(".info { background: #e3f2fd; padding: 15px; margin-bottom: 20px; border-radius: 5px; }");
                
                // スコアカード用スタイル
                html.AppendLine(".scores { display: flex; gap: 20px; margin-bottom: 20px; }");
                html.AppendLine(".score-card { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 10px; flex: 1; box-shadow: 0 4px 6px rgba(0,0,0,0.1); text-align: center; }");
                html.AppendLine(".score-card.focus { background: linear-gradient(135deg, #ff9a9e 0%, #fecfef 99%, #fecfef 100%); color: #333; }");
                html.AppendLine(".score-title { font-size: 16px; margin-bottom: 10px; opacity: 0.9; }");
                html.AppendLine(".score-value { font-size: 42px; font-weight: bold; }");
                
                html.AppendLine(".chart-container { background: white; padding: 20px; margin-bottom: 20px; border-radius: 5px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }");
                html.AppendLine(".header-stat { font-size: 18px; font-weight: normal; color: #555; }");
                html.AppendLine(".header-stat span { font-weight: bold; color: #4CAF50; font-size: 24px; margin-left: 5px; }");
                html.AppendLine("</style>");
                html.AppendLine("</head>");
                html.AppendLine("<body>");
                html.AppendLine("<h1>📊 ActivityMonitor - データ履歴</h1>");
                
                // ユーザー情報
                html.AppendLine("<div class='info'>");
                html.AppendLine("<strong>ユーザー:</strong> " + username + " | ");
                html.AppendLine("<strong>マシン:</strong> " + machine + " | ");
                html.AppendLine("<strong>対象期間:</strong> " + start.ToString("yyyy-MM-dd") + " ～ " + end.ToString("yyyy-MM-dd"));
                html.AppendLine("</div>");
                
                // フィルタ機能は廃止（生成時点で絞り込み済み）

                // 時間帯別アクティビティグラフ
                html.AppendLine("<!-- グラフエリア -->");
                html.AppendLine("<div style='display: flex; gap: 20px; margin-bottom: 20px;'>");
                
                // 24時間アクティビティグラフ (1分単位タイムライン)
                html.AppendLine("<div style='background: white; padding: 20px; border-radius: 5px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); flex: 2;'>");
                // ヘッダーに総作業時間を追加
                html.AppendLine("<h2 style='margin-top: 0; color: #333;'>");
                html.AppendLine("  <span>🕒 24時間アクティビティ (1分単位)</span>");
                html.AppendLine("  <span class='header-stat'>総作業時間: <span id='totalTimeDisplay'>-</span></span>");
                html.AppendLine("</h2>");
                html.AppendLine("<div style='position: relative; height: 120px; width: 100%;'>");
                html.AppendLine("<canvas id='activityChart'></canvas>");
                html.AppendLine("</div>");
                html.AppendLine("<div style='text-align:center; font-size:12px; color:#666; margin-top:5px;'>");
                html.AppendLine("<span>🟢 稼働 (Active)</span> <span style='margin:0 10px;'>|</span> <span>🟡 リモート (Remote)</span> <span style='margin:0 10px;'>|</span> <span>🔘 ロック/アイドル (Locked)</span>");
                html.AppendLine("</div>");
                html.AppendLine("</div>");

                // プロセス別円グラフ
                html.AppendLine("<div style='background: white; padding: 20px; border-radius: 5px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); flex: 1;'>");
                html.AppendLine("<h2 style='margin-top: 0; color: #333;'>📊 アプリ別使用比率</h2>");
                html.AppendLine("<div style='position: relative; height: 200px; width: 100%; text-align: center;'>");
                html.AppendLine("<canvas id='processChart'></canvas>");
                html.AppendLine("</div>");
                html.AppendLine("</div>");

                html.AppendLine("</div>"); // End of flex container

                // スコア表示エリア
                html.AppendLine("<div class='scores' id='scoreArea' style='display:flex;'>"); // 常に表示
                html.AppendLine("  <div class='score-card'>");
                html.AppendLine("    <div class='score-title'>⚡ 生産性スコア (Productivity)</div>");
                html.AppendLine("    <div class='score-value' id='scoreProd'>-</div>");
                html.AppendLine("  </div>");
                html.AppendLine("  <div class='score-card focus'>");
                html.AppendLine("    <div class='score-title'>🔥 集中度スコア (Focus)</div>");
                html.AppendLine("    <div class='score-value' id='scoreFocus'>-</div>");
                html.AppendLine("  </div>");
                html.AppendLine("</div>");

                // 30分ブロック単位スコアテーブル（隠し）
                html.AppendLine("<div id='blockScoreArea' style='display:flex; flex-direction:column; background:white; padding:20px; border-radius:10px; box-shadow:0 4px 6px rgba(0,0,0,0.1); margin-bottom:20px;'>");
                html.AppendLine("  <h3 style='margin-top:0; color:#333; border-bottom: 2px solid #ddd; padding-bottom:10px;'>⏳ 30分単位スコア詳細</h3>");
                html.AppendLine("  <div style='overflow-x:auto;'>");
                html.AppendLine("  <table style='width:100%; border-collapse:collapse; text-align:left;'>");
                html.AppendLine("    <thead>");
                html.AppendLine("      <tr style='background:#f0f0f0; color:#555;'>");
                html.AppendLine("        <th style='padding:12px; border-bottom:2px solid #ddd;'>日付</th>");
                html.AppendLine("        <th style='padding:12px; border-bottom:2px solid #ddd;'>時間帯</th>");
                html.AppendLine("        <th style='padding:12px; border-bottom:2px solid #ddd;'>生産性</th>");
                html.AppendLine("        <th style='padding:12px; border-bottom:2px solid #ddd;'>集中度</th>");
                html.AppendLine("        <th style='padding:12px; border-bottom:2px solid #ddd;'>主プロセス</th>");
                html.AppendLine("        <th style='padding:12px; border-bottom:2px solid #ddd;'>状態分析</th>");
                html.AppendLine("      </tr>");
                html.AppendLine("    </thead>");
                html.AppendLine("    <tbody id='blockScoreTableBody'></tbody>");
                html.AppendLine("  </table>");
                html.AppendLine("  </div>");
                html.AppendLine("</div>");
                
                // テーブル一覧 (dataTable) は廃止

                // JavaScript
                html.AppendLine("<script src='https://cdn.jsdelivr.net/npm/chart.js'></script>");
                html.AppendLine("<script>");
                
                // データ埋め込み
                html.AppendLine(jsScoreData.ToString());
                html.AppendLine(rawDataBuilder.ToString());
                
                html.AppendLine("let myChart = null;");
                html.AppendLine("let pieChart = null;");
                html.AppendLine("let filteredData = rawData;"); // 全データをそのまま使用
                
                html.AppendLine("window.onload = function() {");
                html.AppendLine("  renderAll();");
                html.AppendLine("};");

                html.AppendLine("function renderAll() {");
                
                // スコア集計（全期間平均）
                html.AppendLine("  let totalP = 0; let totalF = 0; let count = 0;");
                html.AppendLine("  const tbody = document.getElementById('blockScoreTableBody');");
                html.AppendLine("  tbody.innerHTML = '';");
                
                html.AppendLine("  // blockScoreDataは日付ごとのオブジェクト");
                html.AppendLine("  Object.keys(blockScoreData).sort().forEach(dateKey => { // 日付順にソートして表示");
                html.AppendLine("     blockScoreData[dateKey].forEach(b => {");
                html.AppendLine("         totalP += b.p; totalF += b.f; count++;");
                html.AppendLine("         let pColor = b.p >= 60 ? '#4CAF50' : (b.p >= 40 ? '#FF9800' : '#F44336');");
                html.AppendLine("         let fColor = b.f >= 60 ? '#4CAF50' : (b.f >= 40 ? '#FF9800' : '#F44336');");
                html.AppendLine("         const row = `<tr>");
                html.AppendLine("            <td style='padding:12px; border-bottom:1px solid #eee;'>${dateKey}</td>");
                html.AppendLine("            <td style='padding:12px; border-bottom:1px solid #eee;'>${b.t}</td>");
                html.AppendLine("            <td style='padding:12px; border-bottom:1px solid #eee; color:${pColor}; font-weight:bold;'>${b.p.toFixed(1)}</td>");
                html.AppendLine("            <td style='padding:12px; border-bottom:1px solid #eee; color:${fColor}; font-weight:bold;'>${b.f.toFixed(1)}</td>");
                html.AppendLine("            <td style='padding:12px; border-bottom:1px solid #eee;'>${b.proc}</td>");
                html.AppendLine("            <td style='padding:12px; border-bottom:1px solid #eee; font-size:12px; color:#555;'>${b.c}</td>");
                html.AppendLine("         </tr>`;");
                html.AppendLine("         tbody.innerHTML += row;");
                html.AppendLine("     });");
                html.AppendLine("  });");
                
                html.AppendLine("  if (count > 0) {");
                html.AppendLine("      document.getElementById('scoreProd').textContent = (totalP / count).toFixed(1);");
                html.AppendLine("      document.getElementById('scoreFocus').textContent = (totalF / count).toFixed(1);");
                html.AppendLine("  } else {");
                html.AppendLine("      document.getElementById('scoreProd').textContent = '-';");
                html.AppendLine("      document.getElementById('scoreFocus').textContent = '-';");
                html.AppendLine("  }");

                html.AppendLine("  updateTotalTime();");
                html.AppendLine("  updateTimelineChart();");
                html.AppendLine("  updateProcessChart();");
                html.AppendLine("}");

                html.AppendLine("function updateTotalTime() {");
                html.AppendLine("  let totalSeconds = 0;");
                html.AppendLine("  filteredData.forEach(d => {");
                html.AppendLine("      totalSeconds += d.s;"); // s is number
                html.AppendLine("  });");
                html.AppendLine("  document.getElementById('totalTimeDisplay').textContent = (totalSeconds / 3600).toFixed(1) + 'h';");
                html.AppendLine("}");

                html.AppendLine("function updateTimelineChart() {");
                html.AppendLine("  const minuteStatus = new Array(1440).fill(0);");
                html.AppendLine("  const minuteLabels = new Array(1440).fill('');");
                
                // データはDB順（新しい順）だが、チャート作成のためには全データ走査が必要。
                // 複数日の場合、同一時刻のアクティビティが重なる可能性がある（平均化等は複雑）。
                // 暫定対応: 直近の日付（リストの先頭付近）または「全期間の合算」を表示するが、
                // 1分単位チャートは「1日」を前提としているため、複数日選択時は不整合が起きる可能性がある。
                // ユーザー要望は「選択した日付のデータ」。通常は1日選択を想定。
                // 複数日なら「最新の日」を表示するか、あるいは重ね合わせるか？
                // ここではシンプルに「データが存在する時刻」を上書きしていく（最新優先）
                
                html.AppendLine("  filteredData.forEach(d => {");
                // d: {u, t, p, s, m, k, sess, rem}
                html.AppendLine("    const uptimeStr = d.u;");
                html.AppendLine("    const durationSec = d.s;");
                html.AppendLine("    const session = d.sess;");
                html.AppendLine("    const isRemote = (d.rem == 1);");
                
                html.AppendLine("    let status = 1;");
                html.AppendLine("    if (isRemote) status = 2;");
                html.AppendLine("    if (session.includes('Lock') || session.includes('Logoff')) status = 3;");
                
                html.AppendLine("    const timePart = uptimeStr.split(' ')[1];");
                html.AppendLine("    const parts = timePart.split(':');");
                html.AppendLine("    const startHour = parseInt(parts[0]);");
                html.AppendLine("    const startMin = parseInt(parts[1]);");
                html.AppendLine("    const startMinuteIndex = startHour * 60 + startMin;");
                
                html.AppendLine("    const durationMin = Math.ceil(durationSec / 60);");
                
                html.AppendLine("    for (let i = 0; i < durationMin; i++) {");
                html.AppendLine("      let idx = startMinuteIndex + i;");
                html.AppendLine("      if (idx < 1440) {");
                // すでにステータスがある場合は上書きしない（またはする）
                // ここでは「データがあるなら埋める」
                html.AppendLine("        if (minuteStatus[idx] === 0) {");
                html.AppendLine("          minuteStatus[idx] = status;");
                html.AppendLine("          minuteLabels[idx] = timePart + ' (' + d.p + ')';");
                html.AppendLine("        }");
                html.AppendLine("      }");
                html.AppendLine("    }");
                html.AppendLine("  });");
                
                html.AppendLine("  const bgColors = minuteStatus.map(s => {");
                html.AppendLine("    if (s === 1) return '#4CAF50';");
                html.AppendLine("    if (s === 2) return '#FFD700';");
                html.AppendLine("    if (s === 3) return '#9E9E9E';");
                html.AppendLine("    return '#EEEEEE';");
                html.AppendLine("  });");

                html.AppendLine("  const dataValues = minuteStatus.map(s => 1);");
                
                html.AppendLine("  const labels = Array.from({length: 1440}, (_, i) => {");
                html.AppendLine("    const h = Math.floor(i / 60);");
                html.AppendLine("    const m = i % 60;");
                html.AppendLine("    return (m === 0) ? h + ':00' : '';");
                html.AppendLine("  });");

                html.AppendLine("  const ctx = document.getElementById('activityChart').getContext('2d');");
                html.AppendLine("  if (myChart) { myChart.destroy(); }");
                html.AppendLine("  myChart = new Chart(ctx, {");
                html.AppendLine("    type: 'bar',");
                html.AppendLine("    data: {");
                html.AppendLine("      labels: labels,");
                html.AppendLine("      datasets: [{");
                html.AppendLine("        data: dataValues,");
                html.AppendLine("        backgroundColor: bgColors,");
                html.AppendLine("        barPercentage: 1.0,");
                html.AppendLine("        categoryPercentage: 1.0,");
                html.AppendLine("        borderWidth: 0");
                html.AppendLine("      }]");
                html.AppendLine("    },");
                html.AppendLine("    options: {");
                html.AppendLine("      responsive: true,");
                html.AppendLine("      maintainAspectRatio: false,");
                html.AppendLine("      plugins: {");
                html.AppendLine("        legend: { display: false },");
                html.AppendLine("        tooltip: {");
                html.AppendLine("          callbacks: {");
                html.AppendLine("            label: function(context) {");
                html.AppendLine("              const idx = context.dataIndex;");
                html.AppendLine("              const h = Math.floor(idx / 60);");
                html.AppendLine("              const m = ('0' + (idx % 60)).slice(-2);");
                html.AppendLine("              const statusMap = ['Inactive', 'Active', 'Remote', 'Locked'];");
                html.AppendLine("              const s = minuteStatus[idx];");
                html.AppendLine("              let info = minuteLabels[idx] || '';");
                html.AppendLine("              if(info.length > 30) info = info.substring(0,30)+'...';");
                html.AppendLine("              return h + ':' + m + ' ' + statusMap[s] + ' ' + info;");
                html.AppendLine("            }");
                html.AppendLine("          }");
                html.AppendLine("        }");
                html.AppendLine("      },");
                html.AppendLine("      scales: {");
                html.AppendLine("        x: { grid: { display: false }, ticks: { autoSkip: false, maxRotation: 0, callback: function(val, index) { return (index % 60 === 0) ? index/60 + ':00' : null; } } },");
                html.AppendLine("        y: { display: false, min: 0, max: 1 }");
                html.AppendLine("      }");
                html.AppendLine("    }");
                html.AppendLine("  });");
                html.AppendLine("}");

                html.AppendLine("function updateProcessChart() {");
                html.AppendLine("  const processes = {};");
                html.AppendLine("  filteredData.forEach(d => {");
                html.AppendLine("    const process = d.p;");
                html.AppendLine("    const seconds = d.s;");
                html.AppendLine("    if(processes[process]) { processes[process] += seconds; } else { processes[process] = seconds; }");
                html.AppendLine("  });");
                
                html.AppendLine("  const sorted = Object.entries(processes).sort((a,b) => b[1] - a[1]).slice(0, 10);");
                html.AppendLine("  const ctx = document.getElementById('processChart').getContext('2d');");
                html.AppendLine("  if (pieChart) { pieChart.destroy(); }");
                html.AppendLine("  pieChart = new Chart(ctx, {");
                html.AppendLine("    type: 'doughnut',");
                html.AppendLine("    data: {");
                html.AppendLine("      labels: sorted.map(d => d[0]),");
                html.AppendLine("      datasets: [{");
                html.AppendLine("        data: sorted.map(d => d[1]/60),");
                html.AppendLine("        backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40', '#E7E9ED', '#76A346', '#0E7569', '#AB4E6B']");
                html.AppendLine("      }]");
                html.AppendLine("    },");
                html.AppendLine("    options: {");
                html.AppendLine("      responsive: true,");
                html.AppendLine("      maintainAspectRatio: false,");
                html.AppendLine("      plugins: {");
                html.AppendLine("        legend: { position: 'right' },");
                html.AppendLine("        tooltip: { callbacks: { label: function(c) { return c.label + ': ' + c.raw.toFixed(1) + ' 分'; } } }");
                html.AppendLine("      }");
                html.AppendLine("    }");
                html.AppendLine("  });");
                html.AppendLine("}");
                html.AppendLine("</script>");
                html.AppendLine("</body>");
                html.AppendLine("</html>");
                
                // HTMLファイルに書き込み
                File.WriteAllText(htmlPath, html.ToString(), System.Text.Encoding.UTF8);
                
                // ブラウザで開く
                System.Diagnostics.Process.Start(htmlPath);
            }
            catch (Exception ex)
            {
                MessageBox.Show("データ表示エラー: " + ex.Message, "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ****************************************************************************
        // サーバ同期ボタンクリック
        // ****************************************************************************
        // ****************************************************************************
        // サーバ同期ボタンクリック
        // ****************************************************************************
        void SyncButton_Click(object sender, EventArgs e)
        {
            SyncData(false);
        }

        // ****************************************************************************
        // データ同期処理
        // ****************************************************************************
        void SyncData(bool silent)
        {
            if (string.IsNullOrEmpty(serverUrl))
            {
                 if (!silent) MessageBox.Show("サーバURLが設定されていません。", "確認", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                 return;
            }
            
            if (!silent)
            {
                syncButton.Enabled = false;
                syncButton.Text = "送信中...";
                Application.DoEvents();
            }

            int totalSent = 0;

            try
            {
                while (true)
                {
                    var unsyncedRecords = new List<Dictionary<string, object>>();
                    var syncedIds = new List<long>();

                    using (var connection = new SQLiteConnection("Data Source=" + dbPath + ";Version=3;"))
                    {
                        connection.Open();
                        // synced = 0 のレコードを取得
                        string sql = "SELECT * FROM activity_records WHERE synced = 0 LIMIT 1000"; // 1000件ずつ送信
                        using (var command = new SQLiteCommand(sql, connection))
                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                var row = new Dictionary<string, object>();
                                row["id"] = reader["id"]; // ローカルID
                                row["uptime"] = reader["uptime"];
                                row["username"] = reader["username"];
                                row["machine"] = reader["machine"];
                                row["task"] = reader["task"];
                                row["process"] = reader["process"];
                                row["sec"] = reader["sec"];
                                row["mouse"] = reader["mouse"];
                                row["keyboard"] = reader["keyboard"];
                                row["session"] = reader["session"];
                                row["memory"] = reader["memory"];
                                row["isRemote"] = reader["isRemote"];
                                
                                try { row["switch_count"] = reader["switch_count"]; } catch { row["switch_count"] = 0; }
                                try { row["idle_seconds"] = reader["idle_seconds"]; } catch { row["idle_seconds"] = 0; }
                                try { row["lock_seconds"] = reader["lock_seconds"]; } catch { row["lock_seconds"] = 0; }
                                
                                unsyncedRecords.Add(row);
                                syncedIds.Add((long)reader["id"]);
                            }
                        }
                    }

                    if (unsyncedRecords.Count == 0)
                    {
                        break; // 未送信なし
                    }

                    // JSONシリアライズ
                    StringBuilder jsonBuilder = new StringBuilder();
                    jsonBuilder.Append("[");
                    foreach (var rec in unsyncedRecords)
                    {
                        jsonBuilder.Append("{");
                        foreach (var key in rec.Keys)
                        {
                            if (key == "id") continue; // IDは送らない

                            string val = rec[key] != DBNull.Value ? rec[key].ToString() : "";
                             // エスケープ処理
                            val = val.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\r", "").Replace("\n", "");
                            
                            jsonBuilder.AppendFormat("\"{0}\":\"{1}\",", key, val);
                        }
                        if (jsonBuilder.Length > 1 && jsonBuilder[jsonBuilder.Length - 1] == ',') jsonBuilder.Length--; // 末尾カンマ削除
                        jsonBuilder.Append("},");
                    }
                    if (jsonBuilder.Length > 1 && jsonBuilder[jsonBuilder.Length - 1] == ',') jsonBuilder.Length--; // 末尾カンマ削除
                    jsonBuilder.Append("]");
                    
                    string jsonParams = jsonBuilder.ToString();

                    // HTTP POST
                    using (var client = new System.Net.WebClient())
                    {
                        client.Headers[System.Net.HttpRequestHeader.ContentType] = "application/json";
                        client.Encoding = System.Text.Encoding.UTF8;
                        string response = client.UploadString(serverUrl, "POST", jsonParams);
                        
                        // レスポンス確認
                        if (response.Contains("\"status\":\"success\""))
                        {
                             // 同期フラグ更新
                             using (var connection = new SQLiteConnection("Data Source=" + dbPath + ";Version=3;"))
                             {
                                 connection.Open();
                                 using (var transaction = connection.BeginTransaction())
                                 {
                                     foreach(var id in syncedIds)
                                     {
                                         using(var cmd = new SQLiteCommand("UPDATE activity_records SET synced = 1 WHERE id = @id", connection))
                                         {
                                             cmd.Parameters.AddWithValue("@id", id);
                                             cmd.ExecuteNonQuery();
                                         }
                                     }
                                     transaction.Commit();
                                 }
                             }
                             totalSent += unsyncedRecords.Count;
                             
                             if (!silent)
                             {
                                 // UI更新 (同期的に行うためDoEvents)
                                 syncButton.Text = string.Format("送信中... ({0}件完了)", totalSent);
                                 Application.DoEvents();
                             }
                        }
                        else
                        {
                            if (!silent) MessageBox.Show("サーバエラー: " + response, "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            else Console.WriteLine("Auto-sync server error: " + response);
                            break; // エラー時は中断
                        }
                    }
                }
                
                if (totalSent > 0)
                {
                    if (!silent) MessageBox.Show(string.Format("すべてのデータの送信が完了しました。\n(合計: {0}件)", totalSent), "送信完了", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else Console.WriteLine("Auto-sync completed. Total: {0}", totalSent);
                }
                else
                {
                     if (!silent) MessageBox.Show("送信対象データはありません。", "通知", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                if (!silent) MessageBox.Show("送信エラー: " + ex.Message, "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else Console.WriteLine("Auto-sync error: " + ex.Message);
            }
            finally
            {
                if (!silent)
                {
                    syncButton.Text = "サーバへ送信 (同期)";
                    syncButton.Enabled = true;
                }
            }
        }

        // ****************************************************************************
        // デバッグモード切り替え
        // ****************************************************************************
        void ToggleDebugMode()
        {
            try
            {
                if (debugMode)
                {
                    // 既にコンソールが存在するか確認
                    IntPtr consoleWindow = GetConsoleWindow();
                    
                    if (consoleWindow == IntPtr.Zero)
                    {
                        // コンソールウィンドウを表示
                        AllocConsole();
                        
                        // コンソールのエンコーディングをUTF-8に設定
                        Console.OutputEncoding = System.Text.Encoding.UTF8;
                        
                        // 標準出力をコンソールにリダイレクト
                        System.IO.StreamWriter writer = new System.IO.StreamWriter(Console.OpenStandardOutput(), System.Text.Encoding.UTF8);
                        writer.AutoFlush = true;
                        Console.SetOut(writer);
                        
                        Console.WriteLine("========================================");
                        Console.WriteLine("ActivityMonitor - デバッグモード");
                        Console.WriteLine("========================================");
                        Console.WriteLine("ユーザー: {0}", user);
                        Console.WriteLine("マシン: {0}", machine);
                        Console.WriteLine("データパス: {0}", dbPath);
                        Console.WriteLine("========================================");
                        Console.WriteLine("");
                    }
                    else
                    {
                        // 既にコンソールが存在する場合は表示するだけ
                        ShowWindow(consoleWindow, 5); // SW_SHOW = 5
                    }
                }
                else
                {
                    // コンソールウィンドウを非表示
                    IntPtr consoleWindow = GetConsoleWindow();
                    if (consoleWindow != IntPtr.Zero)
                    {
                        ShowWindow(consoleWindow, 0); // SW_HIDE = 0
                    }
                }
                
                // 設定を保存
                SettingWrite();
            }
            catch (Exception ex)
            {
                MessageBox.Show("デバッグモード切り替えエラー: " + ex.Message, "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}

// ****************************************************************************
// 生産性・集中度スコア算出ロジック
// ****************************************************************************

// ① 前提（ログ1レコードのモデル）
public class WorkLog
{
    public DateTime DateTime { get; set; }
    public string Process { get; set; }
    public int DurationSec { get; set; }
    public int MouseCount { get; set; }
    public int KeyboardCount { get; set; }
    public int SwitchCount { get; set; } // 追加
    public int IdleSeconds { get; set; } // 追加
    public int LockSeconds { get; set; } // 追加
    public string SessionState { get; set; }
}

// ② プロセス係数定義（生産性用）
public static class ProcessWeight
{
    public static double GetProductivityWeight(string process, int keyboard)
    {
        process = process.ToLower();

        if (process.Contains("antigravity") || process.Contains("code") || process.Contains("visual studio"))
            return 1.0;

        if (process.Contains("excel") || process.Contains("word") || process.Contains("powerpoint"))
            return 0.9;

        if (process.Contains("chrome") || process.Contains("edge") || process.Contains("firefox"))
            return keyboard > 0 ? 0.8 : 0.6; // 入力があれば調べ物、なければ閲覧のみ

        if (process.Contains("line") || process.Contains("discord") || process.Contains("slack"))
            return 0.4; // コミュニケーション

        return 0.3; // その他
    }
}

// ③ 生産性スコア算出ロジック
public static class ProductivityCalculator
{
    public static double Calculate(List<WorkLog> logs)
    {
        if (!logs.Any()) return 0;

        double densitySum = 0;
        double weightSum = 0;
        double continuityScore = CalculateContinuity(logs);
        
        // セッション状態評価
        double sessionScore = logs.All(l => l.SessionState == "SessionUnlock") ? 1.0 : 0.5; 

        // 稼働時間の合計（分母用）
        int totalDuration = logs.Sum(l => l.DurationSec);
        if (totalDuration == 0) return 0;

        foreach (var log in logs)
        {
            if (log.DurationSec <= 0) continue;

            // 密度計算 (操作数 / 時間)
            double density = (double)(log.KeyboardCount + log.MouseCount * 0.5) / log.DurationSec;
            
            // 加重平均をとるために、時間で重み付けする
            // ユーザーロジックは単純平均(logs.Countで割る)だったが、短いログと長いログを同等に扱うと精度が落ちる可能性がある。
            // しかし、まずはユーザーロジックを尊重してそのまま実装する。
            
            densitySum += NormalizeDensity(density);
            weightSum += ProcessWeight.GetProductivityWeight(log.Process, log.KeyboardCount);
        }

        double densityAvg = densitySum / logs.Count;
        double weightAvg = weightSum / logs.Count;

        // densityAvg(0.2~1.0) * weightAvg(0.3~1.0) * continuity(0.2~1.0) * session(0.8~1.0)
        // 最大値は 1.0 * 1.0 * 1.0 * 1.0 = 1.0 -> 100点
        
        return Math.Round(
            100 * densityAvg * weightAvg * continuityScore * sessionScore,
            1
        );
    }

    private static double NormalizeDensity(double density)
    {
        if (density >= 0.15) return 1.0; // かなり活発
        if (density >= 0.08) return 0.8; // 普通
        if (density >= 0.03) return 0.5; // 控えめ
        return 0.2; // ほぼ操作なし
    }

    private static double CalculateContinuity(List<WorkLog> logs)
    {
        // プロセス切り替え回数による評価（従来の推測ロジックも維持）
        int switches = 0;
        for (int i = 1; i < logs.Count; i++)
        {
            if (logs[i].Process != logs[i - 1].Process)
                switches++;
        }

        // スイッチ回数が少ないほど集中している（生産性が高い文脈で）
        // ログ数にもよるが、ユーザーロジックに従う
        if (switches <= 3) return 1.0;
        if (switches <= 6) return 0.8;
        if (switches <= 10) return 0.5;
        return 0.2;
    }
}

// ④ 集中度スコア算出ロジック
public static class FocusCalculator
{
    public static double Calculate(List<WorkLog> logs)
    {
        if (!logs.Any()) return 0;

        double immersion = CalculateImmersion(logs);
        double interruption = CalculateInterruption(logs);
        double stability = CalculateStability(logs);

        double baseScore = 100 * immersion * interruption * stability;

        // ペナルティ計算用統計
        int totalDuration = logs.Sum(l => l.DurationSec);
        int totalSwitches = logs.Sum(l => l.SwitchCount);
        int totalIdle = logs.Sum(l => l.IdleSeconds);
        
        // 1. ウィンドウ切替ペナルティ
        double switchPenalty = 0.0;
        if (totalSwitches > 10) {
             switchPenalty = Math.Min(1.0, (double)(totalSwitches - 10) / 40.0);
        }
        
        // 2. アイドル比率ペナルティ (New)
        // idle_ratio = idle / work
        // 0.1未満 -> 0
        // 0.3超 -> 分断
        double idlePenalty = 0.0;
        if (totalDuration > 0)
        {
            double idleRatio = (double)totalIdle / totalDuration;
            if (idleRatio > 0.3)
            {
                // 0.3を超えた分に対してペナルティ
                // 例: 0.5(半分アイドル) -> (0.5 - 0.3) * 2 = 0.4
                idlePenalty = Math.Min(1.0, (idleRatio - 0.3) * 2.5);
            }
        }

        // 複合ペナルティ適用
        // 最大でもスコアが0未満にならないように
        double totalPenaltyFactor = 1.0 - (switchPenalty * 0.4 + idlePenalty * 0.6); // アイドルの方が少し重み大
        if (totalPenaltyFactor < 0.1) totalPenaltyFactor = 0.1;

        return Math.Round(baseScore * totalPenaltyFactor, 1);
    }

    // 没入度: 同じプロセスをどれだけ長く使い続けたか（最大継続時間）
    private static double CalculateImmersion(List<WorkLog> logs)
    {
        int maxContinuous = 0;
        int current = 0;
        string currentProcess = "";

        foreach (var log in logs)
        {
            if (log.Process == currentProcess)
                current += log.DurationSec;
            else
            {
                maxContinuous = Math.Max(maxContinuous, current);
                current = log.DurationSec; // 新しいプロセスの最初のログの時間
                currentProcess = log.Process;
            }
        }

        maxContinuous = Math.Max(maxContinuous, current);

        if (maxContinuous >= 1500) return 1.0;   // 25分以上
        if (maxContinuous >= 900) return 0.8;    // 15分以上
        if (maxContinuous >= 300) return 0.5;    // 5分以上
        return 0.2;
    }

    // 中断度: 気を散らすアプリの使用回数
    private static double CalculateInterruption(List<WorkLog> logs)
    {
        int interruptions = logs.Count(l =>
            l.Process.ToLower().Contains("line") ||
            l.Process.ToLower().Contains("explorer") || // エクスプローラは作業に必要な場合もあるが、切り替えが多いとノイズ
            l.Process.ToLower().Contains("searchapp") ||
            l.Process.ToLower().Contains("applicationframehost") // Windowsの設定やフォトなど
        );

        if (interruptions == 0) return 1.0;
        if (interruptions <= 2) return 0.8;
        if (interruptions <= 5) return 0.5;
        return 0.2;
    }

    // 安定性: 作業時間のばらつき（標準偏差）が適切か
    // フロー状態に入ると、一定のリズムでログが記録される（例えば1分ごと）
    // 逆に頻繁にコンテキストスイッチがあると、短いログと長いログが混在する？
    // ActivityMonitorは基本的にイベント駆動または1分周期なので、DurationSecの分散を見る意味を再考
    // ユーザーロジック: stdDev < avg * 0.3 なら安定
    private static double CalculateStability(List<WorkLog> logs)
    {
        var durations = logs.Select(l => (double)l.DurationSec).Where(d => d > 0).ToList();
        if (durations.Count < 2) return 1.0;

        double avg = durations.Average();
        double variance = durations.Sum(d => Math.Pow(d - avg, 2)) / durations.Count;
        double stdDev = Math.Sqrt(variance);

        if (stdDev < avg * 0.3) return 1.0;
        if (stdDev < avg * 0.6) return 0.7;
        return 0.4;
    }
}

// ⑤ 30分ブロック用モデル
public class TimeBlockScore
{
    public DateTime BlockStart { get; set; }
    public DateTime BlockEnd { get; set; }

    public double ProductivityScore { get; set; }
    public double FocusScore { get; set; }

    public string DominantProcess { get; set; }
    public string Comment { get; set; } // 自動生成コメント
}

// ⑥ ログを30分単位に分割するユーティリティ
public static class TimeBlockHelper
{
    public static DateTime GetBlockStart(DateTime time)
    {
        int minuteBlock = time.Minute < 30 ? 0 : 30;
        return new DateTime(
            time.Year,
            time.Month,
            time.Day,
            time.Hour,
            minuteBlock,
            0
        );
    }
}

// ⑦ 30分単位スコア算出ロジック（核心）
public static class TimeBlockScoreCalculator
{
    public static List<TimeBlockScore> Calculate(List<WorkLog> logs)
    {
        if (!logs.Any()) return new List<TimeBlockScore>();

        var grouped = logs
            .GroupBy(l => TimeBlockHelper.GetBlockStart(l.DateTime))
            .OrderBy(g => g.Key);

        var results = new List<TimeBlockScore>();

        foreach (var group in grouped)
        {
            var blockLogs = group.ToList();

            double productivity = ProductivityCalculator.Calculate(blockLogs);
            double focus = FocusCalculator.Calculate(blockLogs);

            string dominantProcess = "";
            var processGroups = blockLogs
                .GroupBy(l => l.Process)
                .OrderByDescending(g => g.Sum(x => x.DurationSec));
            
            if (processGroups.Any())
                dominantProcess = processGroups.First().Key;

            // コメント生成
            // LastInputSeconds は「ブロック内の最大連続アイドル時間」として扱う
            int maxIdle = blockLogs.Any() ? blockLogs.Max(l => l.IdleSeconds) : 0;
            int totalIdle = blockLogs.Sum(l => l.IdleSeconds);
            int totalSwitch = blockLogs.Sum(l => l.SwitchCount);
            
            var summary = new ActivitySummary
            {
                BlockSeconds = 1800, // 30分固定
                LastInputSeconds = maxIdle,
                IdleSeconds = totalIdle,
                WindowSwitchCount = totalSwitch
            };
            
            string comment = ActivityCommentGenerator.Generate(summary);

            results.Add(new TimeBlockScore
            {
                BlockStart = group.Key,
                BlockEnd = group.Key.AddMinutes(30),
                ProductivityScore = productivity,
                FocusScore = focus,
                DominantProcess = dominantProcess,
                Comment = comment
            });
        }

        return results;
    }
}

// ⑧ 自動コメント生成ロジック
public class ActivitySummary
{
    public int BlockSeconds { get; set; }       // 1800想定
    public int LastInputSeconds { get; set; }
    public int IdleSeconds { get; set; }
    public int WindowSwitchCount { get; set; }
}

public static class ActivityCommentGenerator
{
    public static string Generate(ActivitySummary s)
    {
        double idleRatio = s.BlockSeconds > 0
            ? (double)s.IdleSeconds / s.BlockSeconds
            : 0;

        bool recentInput = s.LastInputSeconds < 30;
        bool longNoInput = s.LastInputSeconds > 120;

        bool lowIdle = idleRatio < 0.15;
        bool highIdle = idleRatio > 0.35;

        bool fewSwitch = s.WindowSwitchCount <= 10;
        bool manySwitch = s.WindowSwitchCount > 30;

        // ① 深い集中
        if (recentInput && lowIdle && fewSwitch)
        {
            return "操作が継続しており、割り込みも少ない集中状態でした。";
        }

        // ② 割り込み多発
        if (recentInput && manySwitch)
        {
            return "作業は継続していましたが、ウィンドウ切替が多く、割り込みが頻発していました。";
        }

        // ③ 思考・設計
        if (highIdle && fewSwitch && longNoInput) // longNoInput? 定義だと「操作少」だが...
        {
             // ユーザー定義:
             // 操作少(高Idle) × 切替少 × LastInput長? いいえ、定義表を確認
             // 「操作少 × idle高 × 切替少」 -> 思考・設計
             // マトリクス: 「idle高 × last_input長 -> 離席」
             // マトリクスには「idle高 × last_input短」がないが、
             // ロジック: highIdle && fewSwitch && longNoInput -> "思考・設計" とあるが...
             // ユーザーコードにある "highIdle && fewSwitch && longNoInput" だと「離席」と被るのでは？
             // ユーザーの提示コード:
             // // ③ 思考・設計
             // if (highIdle && fewSwitch && longNoInput) 
             //    return "...思考や検討に時間を使っていた可能性があります。"
             // // ⑤ 離席・会議
             // if (longNoInput && highIdle) (切替不問、優先順位後？)
             //    return "...離席や会議..."
             
             // ユーザーの提示コード順序を尊重します。
             // ③が先にマッチすれば「思考」、⑤はその後。
             return "操作は少なく、ウィンドウ切替も抑えられており、思考や検討に時間を使っていた可能性があります。";
        }

        // ④ 分断・混乱
        if (highIdle && manySwitch)
        {
            return "操作が断続的で、ウィンドウ切替も多く、作業が分断されやすい状態でした。";
        }

        // ⑤ 離席・会議
        if (longNoInput && highIdle)
        {
            return "長時間入力がなく、離席や会議などの非操作時間が多かったと考えられます。";
        }

        // ⑥ 安定作業
        if (!highIdle && fewSwitch)
        {
            return "大きな中断はなく、安定した作業が行われていました。";
        }

        // ⑦ マルチタスク
        if (!highIdle && !fewSwitch)
        {
            return "複数の作業を並行して進めていた可能性があります。";
        }

        // ⑧ 低稼働
        return "全体的に操作量が少なく、稼働が控えめな時間帯でした。";
    }
}

// ⑨ Win32 API定義（イベントフック用）
internal static class Win32
{
    public const uint EVENT_SYSTEM_FOREGROUND = 0x0003;
    public const uint WINEVENT_OUTOFCONTEXT = 0x0000;

    public delegate void WinEventDelegate(
        IntPtr hWinEventHook,
        uint eventType,
        IntPtr hwnd,
        int idObject,
        int idChild,
        uint dwEventThread,
        uint dwmsEventTime
    );

    [DllImport("user32.dll")]
    public static extern IntPtr SetWinEventHook(
        uint eventMin,
        uint eventMax,
        IntPtr hmodWinEventProc,
        WinEventDelegate lpfnWinEventProc,
        uint idProcess,
        uint idThread,
        uint dwFlags
    );

    [DllImport("user32.dll")]
    public static extern bool UnhookWinEvent(IntPtr hWinEventHook);

    [DllImport("user32.dll")]
    public static extern uint GetWindowThreadProcessId(
        IntPtr hWnd,
        out uint lpdwProcessId
    );

    [StructLayout(LayoutKind.Sequential)]
    public struct LASTINPUTINFO
    {
        public uint cbSize;
        public uint dwTime;
    }

    [DllImport("user32.dll")]
    public static extern bool GetLastInputInfo(ref LASTINPUTINFO plii);
}

// ⑨ ウィンドウ切替カウンタ（OSイベント駆動）
public class WindowSwitchTracker : IDisposable
{
    private IntPtr _hook;
    private Win32.WinEventDelegate _callback;

    private uint _lastProcessId = 0;
    private DateTime _lastSwitchTime = DateTime.MinValue;
    private const int MIN_INTERVAL_MS = 300; // チャタリング防止

    public int WindowSwitchCount { get; private set; }

    public WindowSwitchTracker()
    {
        _callback = WinEventCallback;

        _hook = Win32.SetWinEventHook(
            Win32.EVENT_SYSTEM_FOREGROUND,
            Win32.EVENT_SYSTEM_FOREGROUND,
            IntPtr.Zero,
            _callback,
            0,
            0,
            Win32.WINEVENT_OUTOFCONTEXT
        );

        if (_hook == IntPtr.Zero)
        {
            Console.WriteLine("WinEventHook の登録に失敗しました。");
        }
    }

    private void WinEventCallback(
        IntPtr hWinEventHook,
        uint eventType,
        IntPtr hwnd,
        int idObject,
        int idChild,
        uint dwEventThread,
        uint dwmsEventTime)
    {
        try
        {
            // 無効ハンドル除外
            if (hwnd == IntPtr.Zero) return;

            // チャタリング対策
            var now = DateTime.UtcNow;
            if ((now - _lastSwitchTime).TotalMilliseconds < MIN_INTERVAL_MS)
                return;

            _lastSwitchTime = now;

            // プロセスID取得
            uint pid;
            Win32.GetWindowThreadProcessId(hwnd, out pid);
            if (pid == 0) return;

            // 同一プロセスへの切替は除外
            if (pid == _lastProcessId) return;

            _lastProcessId = pid;
            WindowSwitchCount++;
        }
        catch
        {
            // ログ用途のため例外は握り潰す
        }
    }

    public void Dispose()
    {
        if (_hook != IntPtr.Zero)
        {
            Win32.UnhookWinEvent(_hook);
            _hook = IntPtr.Zero;
        }
    }
}

// ⑩ Win32 API LastInputInfo 定義
internal static class Win32LastInput
{
    [StructLayout(LayoutKind.Sequential)]
    public struct LASTINPUTINFO
    {
        public uint cbSize;
        public uint dwTime;
    }

    [DllImport("user32.dll")]
    public static extern bool GetLastInputInfo(ref LASTINPUTINFO plii);
}

// ⑪ LastInputSeconds 取得ヘルパー
public static class LastInputHelper
{
    public static int GetLastInputSeconds()
    {
        var info = new Win32LastInput.LASTINPUTINFO
        {
            cbSize = (uint)Marshal.SizeOf(typeof(Win32LastInput.LASTINPUTINFO))
        };

        if (!Win32LastInput.GetLastInputInfo(ref info))
            return 0;

        // TickCount は ms
        int idleMs = Environment.TickCount - (int)info.dwTime;

        if (idleMs < 0) idleMs = 0; // オーバーフロー対策

        return idleMs / 1000;
    }
}

// ⑫ アイドル・ロック時間トラッカー
public class IdleTracker
{
    private DateTime _lastCheck = DateTime.UtcNow;
    private int _lastInputSeconds = 0;

    public int TotalIdleSeconds { get; private set; }
    public int TotalLockSeconds { get; private set; } // Lock時間

    // タイマーインクリメント時に呼ぶ
    public void Tick(string sessionState)
    {
        int currentLastInput = LastInputHelper.GetLastInputSeconds();
        var now = DateTime.UtcNow;
        int delta = (int)(now - _lastCheck).TotalSeconds;

        if (delta > 0 && delta < 100)
        {
            if (sessionState == "SessionLock")
            {
                // ロック中は LockSeconds に加算
                TotalLockSeconds += delta;
            }
            else
            {
                // アンロック時は IdleSeconds 判定
                // 前回よりもLastInput時間が増えている = 操作していない
                if (currentLastInput > _lastInputSeconds)
                {
                    TotalIdleSeconds += delta;
                }
            }
        }

        _lastInputSeconds = currentLastInput;
        _lastCheck = now;
    }

    // レコード切り替え時などにリセット
    public void Reset()
    {
        TotalIdleSeconds = 0;
        TotalLockSeconds = 0;
        _lastInputSeconds = 0;
        _lastCheck = DateTime.UtcNow;
    }
}
