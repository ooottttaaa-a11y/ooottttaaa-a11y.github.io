CREATE DATABASE IF NOT EXISTS NSC;
USE NSC;

-- 既存のテーブルを流用して作成
CREATE TABLE IF NOT EXISTS activity_records (
    id INT AUTO_INCREMENT PRIMARY KEY,
    uptime DATETIME NOT NULL,
    username VARCHAR(255),
    machine VARCHAR(255),
    task TEXT,
    process VARCHAR(255),
    sec INT,
    mouse INT,
    keyboard INT,
    session VARCHAR(255),
    memory BIGINT,
    isRemote TINYINT(1),
    switch_count INT DEFAULT 0,
    idle_seconds INT DEFAULT 0,
    lock_seconds INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_uptime (uptime),
    INDEX idx_username (username),
    INDEX idx_machine (machine)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ユーザー 'tanaka' に対して NSC データベースへの権限を付与
-- もしユーザーが存在しない場合は作成（MySQL 5.7+）
CREATE USER IF NOT EXISTS 'tanaka'@'localhost' IDENTIFIED BY 'tanaka';
GRANT ALL PRIVILEGES ON NSC.* TO 'tanaka'@'localhost';
FLUSH PRIVILEGES;
