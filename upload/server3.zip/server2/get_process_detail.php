<?php
// get_process_detail.php - API to fetch raw records for a specific process and machine

// Database configuration
require_once 'db_connect.php';

// Parameters
$machine = isset($_GET['machine']) ? $_GET['machine'] : '';
$process = isset($_GET['process']) ? $_GET['process'] : '';
$startDate = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-d');
$endDate = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');

if (empty($machine) || empty($process)) {
    header('HTTP/1.1 400 Bad Request');
    echo json_encode(array('status' => 'error', 'message' => 'Machine and Process names are required'));
    exit;
}

$startDateTime = $startDate . ' 00:00:00';
$endDateTime = $endDate . ' 23:59:59';

try {
    // Fetch raw records
    $stmt = $mysqli->prepare("SELECT uptime, task, sec, mouse, keyboard FROM activity_records WHERE machine = ? AND process = ? AND uptime >= ? AND uptime <= ? ORDER BY uptime DESC");
    $stmt->bind_param("ssss", $machine, $process, $startDateTime, $endDateTime);
    $stmt->execute();
    $rows = mysqli_fetch_all_assoc($stmt);

    $result = array();
    foreach ($rows as $row) {
        $result[] = array(
            'uptime' => $row['uptime'],
            'task' => $row['task'],
            'sec' => (int)$row['sec'],
            'mouse' => (int)$row['mouse'],
            'keyboard' => (int)$row['keyboard']
        );
    }

    header('Content-Type: application/json');
    echo json_encode(array('status' => 'success', 'data' => $result));

} catch (Exception $e) {
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(array('status' => 'error', 'message' => $e->getMessage()));
}
?>
