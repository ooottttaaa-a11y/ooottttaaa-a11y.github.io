<?php
require_once 'db_connect.php';
require_once 'auth_session.php';
require_once 'utils/ScoreCalculator.php';

check_login();

header('Content-Type: application/json');

$month = isset($_GET['month']) ? $_GET['month'] : date('Y-m');
$start_date = $month . '-01';
$end_date = date('Y-m-t', strtotime($start_date));

$response = array(
    'status' => 'success',
    'productivity_trend' => array(),
    'attendance_trend' => array(),
    'process_ranking' => array(),
    'overtime_alerts' => array()
);

try {
    $start_dt = $start_date . ' 00:00:00';
    $end_dt = $end_date . ' 23:59:59';

    // 1. Productivity & Focus Trend
    $trendSql = "
        SELECT 
            DATE(uptime) as date,
            SUM(sec) as total_sec,
            SUM(CASE WHEN mouse > 0 OR keyboard > 0 THEN sec ELSE 0 END) as active_sec,
            SUM(CASE WHEN (mouse > 0 OR keyboard > 0) AND process NOT IN ('YouTube', 'Facebook', 'Twitter', 'Netflix') THEN sec ELSE 0 END) as focus_sec
        FROM activity_records
        WHERE uptime BETWEEN ? AND ?
        GROUP BY DATE(uptime)
        ORDER BY date ASC
    ";
    
    $stmt = $mysqli->prepare($trendSql);
    $stmt->bind_param("ss", $start_dt, $end_dt);
    $stmt->execute();
    $trendData = mysqli_fetch_all_assoc($stmt);
    
    foreach ($trendData as $row) {
        $total = $row['total_sec'] > 0 ? $row['total_sec'] : 1;
        $response['productivity_trend'][] = array(
            'date' => $row['date'],
            'p_score' => round(($row['active_sec'] / $total) * 100, 1),
            'f_score' => round(($row['focus_sec'] / $total) * 100, 1)
        );
    }

    // 2. Attendance Trend
    $attSql = "
        SELECT 
            DATE(uptime) as date,
            COUNT(DISTINCT machine) as user_count,
            SUM(sec) as total_sec
        FROM activity_records
        WHERE uptime BETWEEN ? AND ?
        AND (mouse > 0 OR keyboard > 0)
        GROUP BY DATE(uptime)
        ORDER BY date ASC
    ";
    $stmt = $mysqli->prepare($attSql);
    $stmt->bind_param("ss", $start_dt, $end_dt);
    $stmt->execute();
    $attData = mysqli_fetch_all_assoc($stmt);
    
    foreach ($attData as $row) {
        $avg_sec = $row['user_count'] > 0 ? $row['total_sec'] / $row['user_count'] : 0;
        $response['attendance_trend'][] = array(
            'date' => $row['date'],
            'avg_hours' => round($avg_sec / 3600, 1),
            'total_hours' => round($row['total_sec'] / 3600, 1)
        );
    }

    // 3. Process Usage (Top 10)
    $procSql = "
        SELECT process, SUM(sec) as total_sec
        FROM activity_records
        WHERE uptime BETWEEN ? AND ?
        GROUP BY process
        ORDER BY total_sec DESC
        LIMIT 10
    ";
    $stmt = $mysqli->prepare($procSql);
    $stmt->bind_param("ss", $start_dt, $end_dt);
    $stmt->execute();
    $response['process_ranking'] = mysqli_fetch_all_assoc($stmt);

    // 4. Overtime Alerts
    $overtimeSql = "
        SELECT machine, DATE(uptime) as date, SUM(sec) as work_sec
        FROM activity_records
        WHERE uptime BETWEEN ? AND ?
        AND (mouse > 0 OR keyboard > 0) 
        GROUP BY machine, DATE(uptime)
        HAVING work_sec > 36000
        ORDER BY date DESC, work_sec DESC
    ";
    $stmt = $mysqli->prepare($overtimeSql);
    $stmt->bind_param("ss", $start_dt, $end_dt);
    $stmt->execute();
    $overtimeData = mysqli_fetch_all_assoc($stmt);
    foreach ($overtimeData as $row) {
        $response['overtime_alerts'][] = array(
            'date' => $row['date'],
            'machine' => $row['machine'],
            'work_hours' => round($row['work_sec'] / 3600, 1)
        );
    }

} catch (Exception $e) {
    $response['status'] = 'error';
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
?>
