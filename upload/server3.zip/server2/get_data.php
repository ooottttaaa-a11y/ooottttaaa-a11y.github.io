<?php
// get_data.php - API to fetch activity data and server-calculated scores

require_once 'utils/ScoreCalculator.php';

// Database configuration
require_once 'db_connect.php';

// Parameters
$startDate = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-d');
$endDate = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');

// Append times to make full datetime range
$startDateTime = $startDate . ' 00:00:00';
$endDateTime = $endDate . ' 23:59:59';

try {
    // Optional machine filter
    $machine = isset($_GET['machine']) ? $_GET['machine'] : null;

    // Fetch data
    $sql = "SELECT * FROM activity_records WHERE uptime >= ? AND uptime <= ?";
    $types = "ss";
    $params = array($startDateTime, $endDateTime);

    if ($machine) {
        $sql .= " AND machine = ?";
        $types .= "s";
        $params[] = $machine;
    }

    $sql .= " ORDER BY uptime DESC";

    $stmt = $mysqli->prepare($sql);
    
    // Dynamic binding for mysqli
    if ($machine) {
        $stmt->bind_param($types, $params[0], $params[1], $params[2]);
    } else {
        $stmt->bind_param($types, $params[0], $params[1]);
    }
    
    $stmt->execute();
    $rows = mysqli_fetch_all_assoc($stmt);

    // 1. Build rawData (for charts/timeline)
    $rawData = array();
    foreach ($rows as $row) {
        $u = $row['uptime'];
        $t = $row['task'];
        $p = $row['process'];
        $s = (int)$row['sec'];
        $m = (int)$row['mouse'];
        $k = (int)$row['keyboard'];
        $sess = $row['session'];
        $rem = isset($row['isRemote']) ? (int)$row['isRemote'] : 0;
        
        $rawData[] = array(
            'u' => $u,
            't' => $t,
            'p' => $p,
            's' => $s,
            'm' => $m,
            'k' => $k,
            'sw' => isset($row['switch_count']) ? (int)$row['switch_count'] : 0,
            'i' => isset($row['idle_seconds']) ? (int)$row['idle_seconds'] : 0,
            'sess' => $sess,
            'rem' => $rem
        );
    }

    // 2. Calculate Scores using PHP logic (ported from C#)
    $blockScores = ScoreCalculator::calculate($rows);

    $blockScoreData = array();
    
    // Also calculate daily scores for dailyScoresData
    $dailyScoreSums = array();

    foreach ($blockScores as $bs) {
        $dateKey = $bs['date'];
        
        // Prepare block entry
        $entry = array(
            't' => $bs['time_range'],
            'p' => $bs['p'],
            'f' => $bs['f'],
            'proc' => $bs['proc'],
            'c' => $bs['c']
        );

        if (!isset($blockScoreData[$dateKey])) $blockScoreData[$dateKey] = array();
        $blockScoreData[$dateKey][] = $entry;

        // Daily aggregation
        if (!isset($dailyScoreSums[$dateKey])) {
            $dailyScoreSums[$dateKey] = array('pSum' => 0, 'fSum' => 0, 'count' => 0);
        }
        $dailyScoreSums[$dateKey]['pSum'] += $bs['p'];
        $dailyScoreSums[$dateKey]['fSum'] += $bs['f'];
        $dailyScoreSums[$dateKey]['count']++;
    }

    $dailyScoresData = array();
    foreach ($dailyScoreSums as $date => $sum) {
        if ($sum['count'] > 0) {
            $dailyScoresData[$date] = array(
                'p' => round($sum['pSum'] / $sum['count'], 1),
                'f' => round($sum['fSum'] / $sum['count'], 1)
            );
        } else {
            $dailyScoresData[$date] = array('p' => 0, 'f' => 0);
        }
    }

    // Return JSON
    header('Content-Type: application/json');
    echo json_encode(array(
        'rawData' => $rawData,
        'blockScoreData' => (object)$blockScoreData, // Ensure object for empty arrays
        'dailyScoresData' => (object)$dailyScoresData
    ));

} catch (Exception $e) {
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(array('status' => 'error', 'message' => $e->getMessage()));
}
?>
