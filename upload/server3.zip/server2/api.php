<?php
// api.php - Receive ActivityMonitor data and insert into MySQL

// Database configuration and connection
require_once 'db_connect.php';

// Get JSON input
$json = file_get_contents('php://input');
$data = json_decode($json, true);

if (!is_array($data)) {
    header('HTTP/1.1 400 Bad Request');
    echo json_encode(array('status' => 'error', 'message' => 'Invalid JSON data'));
    exit;
}

// Check for duplicates based on machine and uptime
// MySQL 5.0 compatible INSERT ... SELECT ... WHERE NOT EXISTS
$sql = "INSERT INTO activity_records (uptime, username, machine, task, process, sec, mouse, keyboard, session, memory, isRemote, switch_count, idle_seconds, lock_seconds) 
        SELECT ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? 
        FROM (SELECT 1) AS dummy 
        WHERE NOT EXISTS (
            SELECT 1 FROM activity_records WHERE machine = ? AND uptime = ?
        )";

$stmt = $mysqli->prepare($sql);

if (!$stmt) {
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(array('status' => 'error', 'message' => 'Statement preparation failed: ' . $mysqli->error));
    exit;
}

$count = 0;
$errors = 0;

foreach ($data as $row) {
    try {
        $switch_count = isset($row['switch_count']) ? $row['switch_count'] : 0;
        $idle_seconds = isset($row['idle_seconds']) ? $row['idle_seconds'] : 0;
        $lock_seconds = isset($row['lock_seconds']) ? $row['lock_seconds'] : 0;
        $machine = $row['machine'];
        $uptime = $row['uptime'];
        $username = $row['username'];
        $task = $row['task'];
        $process = $row['process'];
        $sec = $row['sec'];
        $mouse = $row['mouse'];
        $keyboard = $row['keyboard'];
        $session = $row['session'];
        $memory = $row['memory'];
        $isRemote = $row['isRemote'];

        $stmt->bind_param("sssssiiiiiiiss", 
            $uptime, $username, $machine, $task, $process, $sec, $mouse, $keyboard, $session, $memory, $isRemote, $switch_count, $idle_seconds, $lock_seconds,
            $machine, $uptime
        );
        
        if ($stmt->execute()) {
            if ($mysqli->affected_rows > 0) {
                $count++;
            }
        } else {
            $errors++;
        }
    } catch (Exception $e) {
        $errors++;
        // Continue inserting other records even if one fails
    }
}

echo json_encode(array('status' => 'success', 'inserted' => $count, 'errors' => $errors));
?>
