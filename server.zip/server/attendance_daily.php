<?php
require_once 'auth_session.php';
check_login();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset='UTF-8'>
    <title>ActivityMonitor - 勤怠 - 日次詳細</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- DataTables CSS -->
    <link href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <!-- FontAwesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    
    <style>
        body { font-family: 'Segoe UI', Meiryo, sans-serif; background: #f5f5f5; }
        .header-area { background: #fff; padding: 20px; border-bottom: 2px solid #2196F3; margin-bottom: 20px; }
        .card { border: none; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    </style>
</head>
<body>

<?php include 'navbar.php'; ?>

<div class="header-area">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center">
            <h1 class="h3 m-0">🕒 勤怠 - 日次詳細: <span id="machineNameTitle"></span></h1>
            <form class="d-flex align-items-center gap-2" onsubmit="event.preventDefault(); loadData();">
                <input type="date" id="startDate" class="form-control" style="width: auto;">
                <span class="mx-2">～</span>
                <input type="date" id="endDate" class="form-control" style="width: auto;">
                <button type="submit" class="btn btn-primary text-nowrap">表示</button>
                <a href="attendance.php" class="btn btn-secondary text-nowrap">一覧に戻る</a>
            </form>
        </div>
    </div>
</div>

<div class="container-fluid">
    <!-- 日次グラフ -->
    <div class="card p-4 mb-3">
        <h5 class="mb-3">📊 日次勤務時間グラフ</h5>
        <div style="height: 400px; position: relative;">
            <canvas id="dailyWorkChart"></canvas>
        </div>
    </div>

    <div class="card p-4">
        <table id="dailyTable" class="table table-striped table-hover" style="width:100%">
            <thead>
                <tr>
                    <th>日付</th>
                    <th>始業時間</th>
                    <th>終業時間</th>
                    <th>勤務時間</th>
                    <th>実働時間</th>
                    <th>ロック時間</th>
                    <th>アイドル時間</th>
                    <th>アクション</th>
                </tr>
            </thead>
            <tbody id="dailyTableBody">
                <!-- Rows loaded via JS -->
            </tbody>
            <tfoot class="table-light fw-bold">
                <tr>
                    <th colspan="3" class="text-end">合計:</th>
                    <th id="totalWork"></th>
                    <th id="totalActualWork"></th>
                    <th id="totalLock"></th>
                    <th id="totalIdle"></th>
                    <th></th>
                </tr>
            </tfoot>
        </table>
    </div>
</div>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>

<script>
let table = null;
let dailyWorkChart = null;
const urlParams = new URLSearchParams(window.location.search);
const machine = urlParams.get('machine');
const initialStart = urlParams.get('start_date') || new Date().toISOString().split('T')[0];
const initialEnd = urlParams.get('end_date') || new Date().toISOString().split('T')[0];

document.getElementById('machineNameTitle').textContent = machine || 'Unknown';
document.getElementById('startDate').value = initialStart;
document.getElementById('endDate').value = initialEnd;

$(document).ready(function() {
    if (!machine) {
        alert('マシン名が指定されていません。');
        return;
    }

    table = $('#dailyTable').DataTable({
        language: {
            "emptyTable": "テーブルにデータがありません",
            "info": " _TOTAL_ 件中 _START_ から _END_ まで表示",
            "infoEmpty": " 0 件中 0 から 0 まで表示",
            "infoFiltered": "（全 _MAX_ 件より抽出）",
            "infoPostFix": "",
            "thousands": ",",
            "lengthMenu": "_MENU_ 件表示",
            "loadingRecords": "読み込み中...",
            "processing": "処理中...",
            "search": "検索:",
            "zeroRecords": "一致するレコードがありません",
            "paginate": {
                "first": "先頭",
                "last": "最終",
                "next": "次",
                "previous": "前"
            },
            "aria": {
                "sortAscending": ": 列を昇順に並べ替えるにはactivate",
                "sortDescending": ": 列を降順に並べ替えるにはactivate"
            }
        },
        paging: false, // ページング無効
        order: [[0, 'asc']], // 日付で昇順ソート
        columns: [
            { data: 'date' },
            { data: 'start_time' },
            { data: 'end_time' },
            { data: 'work_formatted' },
            { data: 'actual_work_formatted' },
            { data: 'lock_formatted' },
            { data: 'idle_formatted' },
            {
                data: null,
                render: function(data, type, row) {
                    return `<a href="detail.php?machine=${encodeURIComponent(machine)}&start_date=${row.date}" class="btn btn-sm btn-outline-primary">詳細</a>`;
                }
            }
        ],
        footerCallback: function (row, data, start, end, display) {
            let totalW = 0, totalA = 0, totalL = 0, totalI = 0;

            data.forEach(d => {
                totalW += d.work_seconds || 0;
                totalA += d.actual_work_seconds || 0;
                totalL += d.lock_seconds || 0;
                totalI += d.idle_seconds || 0;
            });

            const format = (sec) => {
                const h = Math.floor(sec / 3600);
                const m = Math.floor((sec % 3600) / 60);
                return `${h}:${m.toString().padStart(2, '0')}`;
            };

            $(this.api().column(3).footer()).html(format(totalW));
            $(this.api().column(4).footer()).html(format(totalA));
            $(this.api().column(5).footer()).html(format(totalL));
            $(this.api().column(6).footer()).html(format(totalI));
        }
    });
    
    // Chart.jsの初期化
    const ctx = document.getElementById('dailyWorkChart').getContext('2d');
    dailyWorkChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: [],
            datasets: [
                {
                    label: '実働時間',
                    data: [],
                    backgroundColor: 'rgba(33, 150, 243, 0.8)',
                    borderColor: 'rgba(33, 150, 243, 1)',
                    borderWidth: 1
                },
                {
                    label: 'アイドル時間',
                    data: [],
                    backgroundColor: 'rgba(255, 152, 0, 0.6)',
                    borderColor: 'rgba(255, 152, 0, 1)',
                    borderWidth: 1
                }
            ]
        },
        options: {
            indexAxis: 'y', // 横棒グラフ
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'top'
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const hours = context.parsed.x;
                            const h = Math.floor(hours);
                            const m = Math.floor((hours - h) * 60);
                            return `${context.dataset.label}: ${h}時間${m}分`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    stacked: true, // 積み上げ
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: '時間'
                    }
                },
                y: {
                    stacked: true // 積み上げ
                }
            }
        }
    });
    
    loadData();
});

function loadData() {
    const start = document.getElementById('startDate').value;
    const end = document.getElementById('endDate').value;
    
    $.ajax({
        url: `get_attendance_daily.php?machine=${encodeURIComponent(machine)}&start_date=${start}&end_date=${end}`,
        type: 'GET',
        dataType: 'json',
        success: function(response) {
            if (response.status === 'success') {
                table.clear();
                table.rows.add(response.data);
                table.draw();
                
                // グラフを更新
                updateChart(response.data);
            } else {
                alert('データ取得エラー: ' + response.message);
            }
        },
        error: function(xhr, status, error) {
            alert('通信エラー: ' + error);
        }
    });
}

function updateChart(data) {
    // データを日付の降順でソート（最新が上）
    const sortedData = data.sort((a, b) => b.date.localeCompare(a.date));
    
    const labels = sortedData.map(d => d.date);
    const actualWorkHours = sortedData.map(d => (d.actual_work_seconds || 0) / 3600); // 秒を時間に変換
    const idleHours = sortedData.map(d => (d.idle_seconds || 0) / 3600); // 秒を時間に変換
    
    dailyWorkChart.data.labels = labels;
    dailyWorkChart.data.datasets[0].data = actualWorkHours;
    dailyWorkChart.data.datasets[1].data = idleHours;
    dailyWorkChart.update();
}
</script>

</body>
</html>
