<?php
// insert_dummy_data.php - ダミーデータ挿入スクリプト
require_once 'db_connect.php';

// マシン名リスト
$machines = ['PC-DEV-01', 'PC-DEV-02', 'PC-SALES-01', 'PC-SALES-02', 'PC-ADMIN-01'];

// ユーザー名リスト
$usernames = ['yamada', 'tanaka', 'suzuki', 'sato', 'takahashi'];

// プロセス名リスト
$processes = [
    'chrome.exe', 'firefox.exe', 'msedge.exe', 
    'Code.exe', 'devenv.exe', 'notepad++.exe',
    'excel.exe', 'winword.exe', 'powerpnt.exe',
    'slack.exe', 'teams.exe', 'outlook.exe'
];

// タスク名リスト
$tasks = [
    'Google Chrome - 開発ドキュメント',
    'Visual Studio Code - プロジェクト編集',
    'Microsoft Excel - 売上レポート',
    'Microsoft Word - 仕様書作成',
    'Slack - チームチャット',
    'Microsoft Teams - 会議',
    'メモ帳 - メモ'
];

// 期間設定
$startDate = '2026-01-21';
$endDate = '2026-01-23';
$recordsPerDay = 300;

try {
    $pdo->beginTransaction();
    
    $insertCount = 0;
    
    // 日付ループ
    $currentDate = new DateTime($startDate);
    $endDateTime = new DateTime($endDate);
    $endDateTime->modify('+1 day'); // 終了日を含める
    
    while ($currentDate < $endDateTime) {
        $dateStr = $currentDate->format('Y-m-d');
        
        // 各マシンに対してレコードを生成
        foreach ($machines as $index => $machine) {
            $username = $usernames[$index];
            
            // 1日のレコード数を各マシンに分配
            $recordsForMachine = intval($recordsPerDay / count($machines));
            
            // 始業時間を8:00-9:30の間でランダムに設定
            $startHour = 8;
            $startMinute = rand(0, 90); // 0-90分
            $currentTime = new DateTime($dateStr);
            $currentTime->setTime($startHour, $startMinute, 0);
            
            for ($i = 0; $i < $recordsForMachine; $i++) {
                // 各レコードは2-5分間隔
                $intervalMinutes = rand(2, 5);
                $currentTime->modify("+{$intervalMinutes} minutes");
                
                // 18:00以降は記録しない
                if ($currentTime->format('H') >= 18) {
                    break;
                }
                
                // ランダムなプロセスとタスク
                $process = $processes[array_rand($processes)];
                $task = $tasks[array_rand($tasks)];
                
                // sec: 120-300秒 (2-5分)
                $sec = rand(120, 300);
                
                // idle_seconds: 0-60秒 (secより小さい)
                $idleSeconds = rand(0, min(60, $sec - 10));
                
                // lock_seconds: 0-30秒 (secより小さい)
                $lockSeconds = rand(0, min(30, $sec - $idleSeconds - 10));
                
                // マウス・キーボードのカウント
                $mouse = rand(10, 500);
                $keyboard = rand(5, 200);
                
                // メモリ使用量 (バイト)
                $memory = rand(500000000, 2000000000); // 500MB-2GB
                
                // リモート接続かどうか
                $isRemote = rand(0, 10) > 8 ? 1 : 0; // 20%の確率でリモート
                
                // スイッチ回数
                $switchCount = rand(0, 5);
                
                // セッション
                $session = 'Console';
                
                $stmt = $pdo->prepare("
                    INSERT INTO activity_records 
                    (uptime, username, machine, task, process, sec, mouse, keyboard, session, memory, isRemote, switch_count, idle_seconds, lock_seconds)
                    VALUES 
                    (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                
                $stmt->execute([
                    $currentTime->format('Y-m-d H:i:s'),
                    $username,
                    $machine,
                    $task,
                    $process,
                    $sec,
                    $mouse,
                    $keyboard,
                    $session,
                    $memory,
                    $isRemote,
                    $switchCount,
                    $idleSeconds,
                    $lockSeconds
                ]);
                
                $insertCount++;
            }
        }
        
        $currentDate->modify('+1 day');
    }
    
    $pdo->commit();
    
    echo "✅ ダミーデータの挿入が完了しました。\n";
    echo "挿入レコード数: {$insertCount}\n";
    echo "期間: {$startDate} ～ {$endDate}\n";
    echo "マシン数: " . count($machines) . "\n";
    
} catch (Exception $e) {
    $pdo->rollBack();
    echo "❌ エラーが発生しました: " . $e->getMessage() . "\n";
}
?>
