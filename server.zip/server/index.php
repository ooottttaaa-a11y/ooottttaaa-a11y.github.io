<?php
require_once 'auth_session.php';
check_login();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset='UTF-8'>
    <title>ActivityMonitor - ダッシュボード</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- DataTables CSS -->
    <link href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <!-- FontAwesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    
    <style>
        body { font-family: 'Segoe UI', Meiryo, sans-serif; background: #f5f5f5; }
        .header-area { background: #fff; padding: 20px; border-bottom: 2px solid #2196F3; margin-bottom: 20px; }
        .card { border: none; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-bottom: 20px; }
        .chart-container { position: relative; height: 300px; width: 100%; }
        
        /* Heatmap Grid */
        .heatmap-grid { display: grid; grid-template-columns: 40px repeat(24, 1fr); gap: 2px; }
        .heatmap-cell { height: 25px; border-radius: 2px; position: relative; }
        .heatmap-cell:hover { border: 1px solid #333; cursor: pointer; }
        .heatmap-label { font-size: 10px; text-align: right; padding-right: 5px; line-height: 25px; color: #666; }
        .heatmap-header { font-size: 10px; text-align: center; color: #666; }
        
        .loading-overlay {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(255,255,255,0.7); z-index: 9999;
            display: flex; justify-content: center; align-items: center;
        }
    </style>
</head>
<body>

<?php include 'navbar.php'; ?>

<div id="loading" class="loading-overlay" style="display:none;">
    <div class="spinner-border text-primary" role="status">
        <span class="visually-hidden">Loading...</span>
    </div>
</div>

<div class="header-area">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center">
            <h1 class="h3 m-0">📈 ダッシュボード</h1>
            <form class="d-flex align-items-center gap-2" onsubmit="event.preventDefault(); loadData();">
                <input type="date" id="startDate" class="form-control" style="width: auto;" value="<?php echo date('Y-m-01'); ?>">
                <span class="mx-2">～</span>
                <input type="date" id="endDate" class="form-control" style="width: auto;" value="<?php echo date('Y-m-t'); ?>">
                <button type="submit" class="btn btn-primary text-nowrap">表示</button>
            </form>
        </div>
    </div>
</div>

<div class="container-fluid">
    
    <!-- Top Row Charts (Daily) -->
    <div class="row">
        <!-- Daily Work Time -->
        <div class="col-lg-6">
            <div class="card p-3">
                <h5 class="card-title">📅 日付別 稼働時間 (合計)</h5>
                <div class="chart-container">
                    <canvas id="dailyWorkChart"></canvas>
                </div>
            </div>
        </div>
        
        <!-- Daily Operation Rate -->
        <div class="col-lg-6">
            <div class="card p-3">
                <h5 class="card-title">📈 日付別 稼働率 (平均)</h5>
                <div class="chart-container">
                    <canvas id="dailyRateChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- Second Row Charts (Hourly & Switch) -->
    <div class="row">
        <!-- 1. Hourly Activity -->
        <div class="col-lg-6">
            <div class="card p-3">
                <h5 class="card-title">🕒 時間帯別 実働時間 (期間合計)</h5>
                <div class="chart-container">
                    <canvas id="hourlyChart"></canvas>
                </div>
            </div>
        </div>
        
        <!-- 3. Switch Frequency -->
        <div class="col-lg-6">
            <div class="card p-3">
                <h5 class="card-title">🔄 時間帯別 アプリ切り替え頻度 (1日平均)</h5>
                <div class="chart-container">
                    <canvas id="switchChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- Third Row Charts (Input) -->
    <div class="row">
        <!-- 2. Daily Input Intensity -->
        <div class="col-lg-6">
            <div class="card p-3">
                <h5 class="card-title">⌨️🖱️ 日次 入力強度 (マウス vs キーボード)</h5>
                <div class="chart-container">
                    <canvas id="inputChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Hourly Input Intensity (NEW) -->
        <div class="col-lg-6">
            <div class="card p-3">
                <h5 class="card-title">🕒 時間帯別 入力強度 (合計)</h5>
                <div class="chart-container">
                    <canvas id="hourlyInputChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- Fourth Row (Heatmap) -->
    <div class="row">
        <div class="col-12">
            <div class="card p-3">
                <h5 class="card-title">📅 曜日別 稼働率ヒートマップ</h5>
                <!-- Custom Heatmap Grid -->
                <div style="overflow-x: auto;">
                    <div id="heatmapContainer" style="min-width: 500px;">
                        <!-- Generated by JS -->
                    </div>
                </div>
                <div class="d-flex justify-content-end mt-2">
                    <small class="text-muted d-flex align-items-center gap-2">
                        <span>Low</span>
                        <div style="width: 100px; height: 10px; background: linear-gradient(to right, #ffebee, #f44336);"></div>
                        <span>High</span>
                    </small>
                </div>
            </div>
        </div>
    </div>

    <!-- Fifth Row (Process Pie Chart) -->
    <div class="row">
        <div class="col-12">
            <div class="card p-3">
                <h5 class="card-title">🥧 プロセス別 使用割合 (Top 10)</h5>
                <div class="chart-container" style="height: 400px;">
                    <canvas id="processPieChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- Process Table (Existing Feature) -->
    <div class="card p-4">
        <h5 class="card-title border-bottom pb-2">🛠️ プロセス別使用状況</h5>
        <table id="processTable" class="table table-striped table-hover" style="width:100%">
            <thead>
                <tr>
                    <th>プロセス名</th>
                    <th>合計時間</th>
                    <th>閲覧時間</th>
                    <th>編集時間</th>
                    <th>アクション</th>
                </tr>
            </thead>
            <tbody id="processTableBody">
            </tbody>
        </table>
    </div>
</div>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>

<script>
let processTable = null;
let hourlyChartObj = null;
let switchChartObj = null;
let inputChartObj = null;
let dailyWorkChartObj = null;
let dailyRateChartObj = null;
let hourlyInputChartObj = null; // NEW
let processPieChartObj = null; // NEW

$(document).ready(function() {
    processTable = $('#processTable').DataTable({
        language: {
            "emptyTable": "テーブルにデータがありません",
            "info": " _TOTAL_ 件中 _START_ から _END_ まで表示",
            "infoEmpty": " 0 件中 0 から 0 まで表示",
            "infoFiltered": "（全 _MAX_ 件より抽出）",
            "infoPostFix": "",
            "thousands": ",",
            "lengthMenu": "_MENU_ 件表示",
            "loadingRecords": "読み込み中...",
            "processing": "処理中...",
            "search": "検索:",
            "zeroRecords": "一致するレコードがありません",
            "paginate": {
                "first": "先頭",
                "last": "最終",
                "next": "次",
                "previous": "前"
            },
            "aria": {
                "sortAscending": ": 列を昇順に並べ替えるにはactivate",
                "sortDescending": ": 列を降順に並べ替えるにはactivate"
            }
        },
        order: [[1, 'desc']],
        columns: [
            { data: 'process' },
            { 
                data: 'total_time',
                render: function(data, type, row) { return type === 'display' ? row.total_fmt : data; }
            },
            { 
                data: 'view_time',
                render: function(data, type, row) { return type === 'display' ? row.view_fmt : data; }
            },
            { 
                data: 'edit_time',
                render: function(data, type, row) { return type === 'display' ? row.edit_fmt : data; }
            },
            {
                data: null,
                render: function(data, type, row) {
                    const start = $('#startDate').val();
                    const end = $('#endDate').val();
                    return `<a href="process_machine_list.php?process=${encodeURIComponent(row.process)}&start_date=${start}&end_date=${end}" class="btn btn-sm btn-outline-primary">詳細</a>`;
                }
            }
        ]
    });
    
    loadData();
});

function loadData() {
    const start = $('#startDate').val();
    const end = $('#endDate').val();
    
    $('#loading').show();

    // Parallel fetch
    Promise.all([
        $.ajax({ url: `get_analysis_data.php?start_date=${start}&end_date=${end}`, dataType: 'json' }),
        $.ajax({ url: `get_process_list.php?start_date=${start}&end_date=${end}`, dataType: 'json' })
    ]).then(([analysisData, processData]) => {
        if (analysisData.status === 'success') {
            renderCharts(analysisData.data);
        } else {
            console.error('Analysis data error:', analysisData.message);
        }
        
        if (processData.status === 'success') {
            processTable.clear();
            processTable.rows.add(processData.data);
            processTable.draw();
        } else {
            console.error('Process data error:', processData.message);
        }
    }).catch(err => {
        alert('データ取得中にエラーが発生しました。');
        console.error(err);
    }).finally(() => {
        $('#loading').hide();
    });
}

function renderCharts(data) {
    if(data.daily) {
        renderDailyWorkChart(data.daily);
        renderDailyRateChart(data.daily);
    }
    renderHourlyChart(data.hourly);
    renderSwitchChart(data.switch);
    renderInputChart(data.input);
    if(data.hourly_input) renderHourlyInputChart(data.hourly_input);
    if(data.process_ranking) renderProcessPieChart(data.process_ranking);
    renderHeatmap(data.heatmap);
}

function renderDailyWorkChart(data) {
    const ctx = document.getElementById('dailyWorkChart').getContext('2d');
    if (dailyWorkChartObj) dailyWorkChartObj.destroy();
    
    dailyWorkChartObj = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: data.map(d => d.date),
            datasets: [{
                label: '実働時間 (時間)',
                data: data.map(d => (d.actual_work_seconds / 3600).toFixed(1)),
                backgroundColor: 'rgba(33, 150, 243, 0.7)',
                borderColor: 'rgba(33, 150, 243, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: { beginAtZero: true, title: { display: true, text: '実働時間 (h)' } }
            }
        }
    });
}

function renderDailyRateChart(data) {
    const ctx = document.getElementById('dailyRateChart').getContext('2d');
    if (dailyRateChartObj) dailyRateChartObj.destroy();
    
    const colors = data.map(d => {
        if (d.operation_rate >= 70) return '#4CAF50';
        if (d.operation_rate >= 50) return '#FF9800';
        return '#F44336';
    });

    dailyRateChartObj = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: data.map(d => d.date),
            datasets: [{
                label: '稼働率 (%)',
                data: data.map(d => d.operation_rate),
                backgroundColor: colors,
                borderColor: colors,
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: { beginAtZero: true, max: 100, title: { display: true, text: '稼働率 (%)' } }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `稼働率: ${context.parsed.y}%`;
                        }
                    }
                }
            }
        }
    });
}

function renderHourlyChart(data) {
    const ctx = document.getElementById('hourlyChart').getContext('2d');
    if (hourlyChartObj) hourlyChartObj.destroy();
    
    hourlyChartObj = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: data.map(d => d.hour + '時'),
            datasets: [{
                label: '実働時間 (時間)',
                data: data.map(d => (d.seconds / 3600).toFixed(1)), // 秒 -> 時間
                backgroundColor: 'rgba(54, 162, 235, 0.7)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: { beginAtZero: true, title: { display: true, text: '総時間 (h)' } }
            }
        }
    });
}

function renderSwitchChart(data) {
    const ctx = document.getElementById('switchChart').getContext('2d');
    if (switchChartObj) switchChartObj.destroy();
    
    switchChartObj = new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.map(d => d.hour + '時'),
            datasets: [{
                label: '平均切り替え回数',
                data: data.map(d => d.count),
                borderColor: 'rgba(255, 159, 64, 1)',
                backgroundColor: 'rgba(255, 159, 64, 0.2)',
                tension: 0.3,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: { beginAtZero: true }
            }
        }
    });
}

function renderInputChart(data) {
    const ctx = document.getElementById('inputChart').getContext('2d');
    if (inputChartObj) inputChartObj.destroy();
    
    inputChartObj = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: data.map(d => d.date),
            datasets: [
                {
                    label: 'マウス (Actions)',
                    data: data.map(d => d.mouse),
                    backgroundColor: 'rgba(75, 192, 192, 0.7)',
                    stack: 'Stack 0'
                },
                {
                    label: 'キーボード (Actions)',
                    data: data.map(d => d.keyboard),
                    backgroundColor: 'rgba(153, 102, 255, 0.7)',
                    stack: 'Stack 0'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                x: { stacked: true },
                y: { stacked: true, beginAtZero: true }
            }
        }
    });
}

function renderHourlyInputChart(data) {
    const ctx = document.getElementById('hourlyInputChart').getContext('2d');
    if (hourlyInputChartObj) hourlyInputChartObj.destroy();
    
    hourlyInputChartObj = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: data.map(d => d.hour + '時'),
            datasets: [{
                label: '入力数 (Mouse + Keyboard)',
                data: data.map(d => d.count),
                backgroundColor: 'rgba(153, 102, 255, 0.7)',
                borderColor: 'rgba(153, 102, 255, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: { beginAtZero: true }
            }
        }
    });
}

function renderProcessPieChart(data) {
    const ctx = document.getElementById('processPieChart').getContext('2d');
    if (processPieChartObj) processPieChartObj.destroy();
    
    // Generate colors
    const colors = [
        '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF',
        '#FF9F40', '#E7E9ED', '#76CC86', '#5DA5DA', '#F15854'
    ];

    processPieChartObj = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: data.map(d => d.process),
            datasets: [{
                data: data.map(d => d.seconds),
                backgroundColor: colors.slice(0, data.length),
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'right' },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const val = context.raw;
                            const total = context.chart._metasets[context.datasetIndex].total;
                            const percentage = ((val / total) * 100).toFixed(1) + '%';
                            
                            // Format seconds to HH:mm
                            const h = Math.floor(val / 3600);
                            const m = Math.floor((val % 3600) / 60);
                            const timeStr = (h > 0 ? h + 'h ' : '') + m + 'm';
                            
                            return context.label + ': ' + timeStr + ' (' + percentage + ')';
                        }
                    }
                }
            }
        }
    });
}

function renderHeatmap(data) {
    const container = document.getElementById('heatmapContainer');
    container.innerHTML = '';
    
    const days = ['日', '月', '火', '水', '木', '金', '土'];
    const grid = document.createElement('div');
    grid.className = 'heatmap-grid';
    
    // Header
    const emptyCell = document.createElement('div');
    grid.appendChild(emptyCell);
    
    for (let h = 0; h < 24; h++) {
        const header = document.createElement('div');
        header.className = 'heatmap-header';
        header.textContent = h;
        grid.appendChild(header);
    }
    
    // Rows
    for (let d = 0; d < 7; d++) {
        const label = document.createElement('div');
        label.className = 'heatmap-label';
        label.textContent = days[d];
        grid.appendChild(label);
        
        for (let h = 0; h < 24; h++) {
            const cell = document.createElement('div');
            cell.className = 'heatmap-cell';
            
            // Find data
            const item = data.find(x => x.day === d && x.hour === h);
            const rate = item ? item.rate : 0;
            
            // Color mapping: 0% -> light pink (#ffebee), 100% -> dark red (#f44336)
            // Ideally should use HSL or an interpolated color function. Simple usage:
            if (rate > 0) {
                // Opacity based on rate (0.1 to 1.0)
                const opacity = Math.max(0.1, rate / 100);
                cell.style.backgroundColor = `rgba(244, 67, 54, ${opacity})`;
                cell.title = `${days[d]}曜 ${h}時: 稼働率 ${rate}%`;
            } else {
                cell.style.backgroundColor = '#f0f0f0';
                cell.title = `${days[d]}曜 ${h}時: データなし`;
            }
            
            grid.appendChild(cell);
        }
    }
    
    container.appendChild(grid);
}
</script>

</body>
</html>
