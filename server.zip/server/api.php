<?php
// api.php - Receive ActivityMonitor data and insert into MySQL

// Database configuration and connection
require_once 'db_connect.php';

// Get JSON input
$json = file_get_contents('php://input');

// デバッグ用: 受信データをログに記録
error_log("Received JSON: " . substr($json, 0, 500)); // 最初の500文字のみ

$data = json_decode($json, true);

if (!is_array($data)) {
    $jsonError = json_last_error_msg();
    http_response_code(400);
    echo json_encode([
        'status' => 'error', 
        'message' => 'Invalid JSON data',
        'json_error' => $jsonError,
        'received_length' => strlen($json),
        'sample' => substr($json, 0, 200)
    ]);
    exit;
}

// Check for duplicates based on machine and uptime
$stmt = $pdo->prepare("
    INSERT INTO activity_records (uptime, username, machine, task, process, sec, mouse, keyboard, session, memory, isRemote, switch_count, idle_seconds, lock_seconds) 
    SELECT ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? 
    FROM DUAL 
    WHERE NOT EXISTS (
        SELECT 1 FROM activity_records WHERE machine = ? AND uptime = ?
    )
");

$count = 0;
$errors = 0;
$errorMessages = array();

foreach ($data as $row) {
    try {
        $stmt->execute([
            $row['uptime'],
            $row['username'],
            $row['machine'],
            $row['task'],
            $row['process'],
            $row['sec'],
            $row['mouse'],
            $row['keyboard'],
            $row['session'],
            $row['memory'],
            $row['isRemote'],
            $row['switch_count'] ?? 0,
            $row['idle_seconds'] ?? 0,
            $row['lock_seconds'] ?? 0,
            // Parameters for WHERE NOT EXISTS check
            $row['machine'],
            $row['uptime']
        ]);
        
        if ($stmt->rowCount() > 0) {
            $count++;
        }
    } catch (Exception $e) {
        $errors++;
        $errorMessages[] = $e->getMessage();
        // Continue inserting other records even if one fails
    }
}

$status = ($errors === 0) ? 'success' : 'error';
$response = [
    'status' => $status,
    'inserted' => $count,
    'errors' => $errors
];

if ($errors > 0) {
    $response['messages'] = array_unique($errorMessages);
}

header('Content-Type: application/json');
echo json_encode($response);
?>
