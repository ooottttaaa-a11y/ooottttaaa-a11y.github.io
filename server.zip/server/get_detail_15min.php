<?php
// get_detail_15min.php - 15分単位の詳細データ取得API
require_once 'db_connect.php';

$machine = isset($_GET['machine']) ? $_GET['machine'] : '';
$targetDate = isset($_GET['target_date']) ? $_GET['target_date'] : date('Y-m-d');

if (empty($machine)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Machine name is required']);
    exit;
}

$startDateTime = $targetDate . ' 00:00:00';
$endDateTime = $targetDate . ' 23:59:59';

try {
    // その日のデータを全て取得
    $stmt = $pdo->prepare("
        SELECT * FROM activity_records 
        WHERE machine = ? AND uptime >= ? AND uptime <= ? 
        ORDER BY uptime ASC
    ");
    $stmt->execute([$machine, $startDateTime, $endDateTime]);
    $allRows = $stmt->fetchAll();

    // 00:00から23:45まで15分単位で全てのブロックを初期化
    $blocks = [];
    for ($hour = 0; $hour < 24; $hour++) {
        for ($minute = 0; $minute < 60; $minute += 15) {
            $blockKey = sprintf('%02d:%02d', $hour, $minute);
            $blocks[$blockKey] = [
                'time_slot' => $blockKey,
                'total_sec' => 0,
                'idle_sec' => 0,
                'lock_sec' => 0,
                'mouse_count' => 0,
                'keyboard_count' => 0,
                'switch_count' => 0
            ];
        }
    }
    
    // データを各ブロックに集計
    foreach ($allRows as $row) {
        $uptime = $row['uptime']; // "YYYY-MM-DD HH:MM:SS"
        $timestamp = strtotime($uptime);
        
        // 15分単位のブロックを計算
        $hour = (int)date('H', $timestamp);
        $minute = (int)date('i', $timestamp);
        $blockMinute = floor($minute / 15) * 15;
        $blockKey = sprintf('%02d:%02d', $hour, $blockMinute);
        
        $blocks[$blockKey]['total_sec'] += (int)$row['sec'];
        $blocks[$blockKey]['idle_sec'] += isset($row['idle_seconds']) ? (int)$row['idle_seconds'] : 0;
        $blocks[$blockKey]['lock_sec'] += isset($row['lock_seconds']) ? (int)$row['lock_seconds'] : 0;
        $blocks[$blockKey]['mouse_count'] += isset($row['mouse']) ? (int)$row['mouse'] : 0;
        $blocks[$blockKey]['keyboard_count'] += isset($row['keyboard']) ? (int)$row['keyboard'] : 0;
        $blocks[$blockKey]['switch_count'] += isset($row['switch_count']) ? (int)$row['switch_count'] : 0;
    }
    
    // 実働時間を計算
    $result = [];
    foreach ($blocks as $blockKey => $block) {
        $actualWork = $block['total_sec'] - $block['idle_sec'];
        if ($actualWork < 0) $actualWork = 0;

        // 稼働率 = ((勤務時間 - アイドル時間 - ロック時間) / 勤務時間) × 100
        $workTime = $block['total_sec'];
        $idleTime = $block['idle_sec'];
        $lockTime = $block['lock_sec'];
        $operationRate = 0;

        if ($workTime > 0) {
            $realActualWork = $workTime - $idleTime - $lockTime;
            if ($realActualWork < 0) $realActualWork = 0;
            $operationRate = ($realActualWork / $workTime) * 100;
        }
        
        $result[] = [
            'time_slot' => $block['time_slot'],
            'operation_rate' => round($operationRate, 1),
            'actual_work_sec' => $actualWork,
            'actual_work_formatted' => gmdate('i:s', $actualWork),
            'idle_sec' => $block['idle_sec'],
            'idle_formatted' => gmdate('i:s', $block['idle_sec']),
            'mouse_count' => $block['mouse_count'],
            'keyboard_count' => $block['keyboard_count'],
            'switch_count' => $block['switch_count']
        ];
    }
    
    // 時間順にソート（既にソート済みだが念のため）
    usort($result, function($a, $b) {
        return strcmp($a['time_slot'], $b['time_slot']);
    });
    
    // 生データも返す（グラフ用）
    $rawData = [];
    foreach ($allRows as $row) {
        $rawData[] = [
            'u' => $row['uptime'],
            't' => $row['task'],
            'p' => $row['process'],
            's' => (int)$row['sec'],
            'm' => isset($row['mouse']) ? (int)$row['mouse'] : 0,
            'k' => isset($row['keyboard']) ? (int)$row['keyboard'] : 0,
            'sw' => isset($row['switch_count']) ? (int)$row['switch_count'] : 0,
            'i' => isset($row['idle_seconds']) ? (int)$row['idle_seconds'] : 0,
            'sess' => $row['session'],
            'rem' => isset($row['isRemote']) ? (int)$row['isRemote'] : 0
        ];
    }
    
    header('Content-Type: application/json');
    echo json_encode([
        'status' => 'success', 
        'data' => $result,
        'rawData' => $rawData
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
