<?php
// get_attendance_list.php - API to fetch aggregated attendance stats per machine

// Database configuration
require_once 'db_connect.php';

// Parameters
$startDate = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-d');
$endDate = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');

$startDateTime = $startDate . ' 00:00:00';
$endDateTime = $endDate . ' 23:59:59';

try {
    // Fetch all data in range
    $stmt = $pdo->prepare("SELECT * FROM activity_records WHERE uptime >= ? AND uptime <= ? ORDER BY uptime ASC");
    $stmt->execute([$startDateTime, $endDateTime]);
    $allRows = $stmt->fetchAll();

    // Group by Machine -> Date
    $machineDateGroups = [];
    foreach ($allRows as $row) {
        $m = $row['machine'];
        $d = substr($row['uptime'], 0, 10);
        if (!isset($machineDateGroups[$m])) {
            $machineDateGroups[$m] = [];
        }
        if (!isset($machineDateGroups[$m][$d])) {
            $machineDateGroups[$m][$d] = [];
        }
        $machineDateGroups[$m][$d][] = $row;
    }

    $result = [];

    foreach ($machineDateGroups as $machine => $dates) {
        $totalWork = 0; // 勤務時間（始業-就業の差分合計）
        $totalLock = 0;
        $totalIdle = 0;
        $totalActualWork = 0; // 実働時間（勤務時間 - アイドル時間）

        foreach ($dates as $date => $rows) {
            $startTime = null;
            $endTime = null;
            $dailyIdle = 0;
            $dailyLock = 0;

            foreach ($rows as $row) {
                $ts = strtotime($row['uptime']);
                if ($startTime === null || $ts < $startTime) $startTime = $ts;
                if ($endTime === null || $ts > $endTime) $endTime = $ts;

                $dailyIdle += isset($row['idle_seconds']) ? (int)$row['idle_seconds'] : 0;
                $dailyLock += isset($row['lock_seconds']) ? (int)$row['lock_seconds'] : 0;
            }

            // 勤務時間 = 就業時間 - 始業時間
            $dailyWork = 0;
            if ($startTime !== null && $endTime !== null) {
                $dailyWork = $endTime - $startTime;
            }

            // 実働時間 = 勤務時間 - アイドル時間
            $dailyActualWork = $dailyWork - $dailyIdle;
            if ($dailyActualWork < 0) $dailyActualWork = 0;

            $totalWork += $dailyWork;
            $totalLock += $dailyLock;
            $totalIdle += $dailyIdle;
            $totalActualWork += $dailyActualWork;
        }

        $result[] = [
            'machine' => $machine,
            'total_work' => $totalWork,
            'total_work_sec' => $totalWork,
            'total_work_fmt' => floor($totalWork / 3600) . gmdate(':i', $totalWork % 3600),
            'total_actual_work' => $totalActualWork,
            'total_actual_work_sec' => $totalActualWork,
            'total_actual_work_fmt' => floor($totalActualWork / 3600) . gmdate(':i', $totalActualWork % 3600),
            'total_lock' => $totalLock,
            'total_lock_sec' => $totalLock,
            'total_lock_fmt' => floor($totalLock / 3600) . gmdate(':i', $totalLock % 3600),
            'total_idle' => $totalIdle,
            'total_idle_sec' => $totalIdle,
            'total_idle_fmt' => floor($totalIdle / 3600) . gmdate(':i', $totalIdle % 3600)
        ];
    }

    header('Content-Type: application/json');
    echo json_encode(['status' => 'success', 'data' => $result]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
