<?php
require_once 'auth_session.php';
check_login();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset='UTF-8'>
    <title>ActivityMonitor - 詳細ビュー</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <!-- DataTables CSS -->
    <link href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <style>
        body { font-family: 'Segoe UI', Meiryo, sans-serif; background: #f5f5f5; }
        .header-area { background: #fff; padding: 20px; border-bottom: 2px solid #4CAF50; margin-bottom: 20px; }
        .chart-container { background: white; padding: 20px; margin-bottom: 20px; border-radius: 5px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .header-stat { font-size: 18px; font-weight: normal; color: #555; }
        .header-stat span { font-weight: bold; color: #4CAF50; font-size: 24px; margin-left: 5px; }
        .table { table-layout: auto; }
        .table td, .table th { 
            word-break: break-word; 
            white-space: normal !important; 
        }
    </style>
</head>
<body>

<?php include 'navbar.php'; ?>

<div class="header-area">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center">
            <h1 class="h3 m-0">📊 詳細ビュー</h1>
            <form class="d-flex align-items-center gap-2" onsubmit="event.preventDefault(); loadData();">
                <input type="date" id="targetDate" class="form-control" style="width: auto;" value="<?php echo isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-d'); ?>">
                <button type="submit" class="btn btn-primary text-nowrap">表示</button>
                <?php 
                    $machine = isset($_GET['machine']) ? htmlspecialchars($_GET['machine']) : '';
                    $start = isset($_GET['start_date']) ? htmlspecialchars($_GET['start_date']) : date('Y-m-d');
                ?>
                <a href="attendance_daily.php?machine=<?php echo $machine; ?>&start_date=<?php echo $start; ?>&end_date=<?php echo $start; ?>" class="btn btn-secondary ms-2 text-nowrap">戻る</a>
            </form>
        </div>
        <h2 class="h5 text-muted mt-2">マシン: <?php echo isset($_GET['machine']) ? htmlspecialchars($_GET['machine']) : 'All'; ?></h2>
    </div>
</div>

<div class="container-fluid">
    
    <div id="loading" class="text-center my-5" style="display:none;">
        <div class="spinner-border text-primary" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
        <p>Loading data...</p>
    </div>

    <!-- Content Area -->
    <div id="contentArea" style="display:none;">

        <div class="row">
            <!-- 24時間タイムライン -->
            <div class="col-lg-8 mb-4">
                <div class="chart-container h-100">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h2 class="h5 m-0">📊 15分単位 稼働率推移</h2>
                        <div class="header-stat">総作業時間: <span id="totalTimeDisplay">-</span></div>
                    </div>
                    <div style="position: relative; height: 300px; width: 100%;">
                        <canvas id="activityChart"></canvas>
                    </div>

                </div>
            </div>

            <!-- アプリ別円グラフ -->
            <div class="col-lg-4 mb-4">
                <div class="chart-container h-100">
                    <h2 class="h5 mb-3">📊 アプリ別使用比率</h2>
                    <div style="position: relative; height: 300px; width: 100%;">
                        <canvas id="processChart"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <!-- 15分単位詳細テーブル -->
        <div class="chart-container">
            <h3 class="h5 mb-3 border-bottom pb-2">⏳ 15分単位詳細</h3>
            <div class="table-responsive">
                <table id="detail15minTable" class="table table-striped table-hover" style="width:100%">
                    <thead class="table-light">
                        <tr>
                            <th>時間帯</th>
                            <th>稼働率</th>
                            <th>実働時間</th>
                            <th>アイドル時間</th>
                            <th>マウスクリック数</th>
                            <th>キータイプ数</th>
                            <th>切り替え数</th>
                        </tr>
                    </thead>
                    <tbody id="detail15minTableBody">
                    </tbody>
                </table>
            </div>
        </div>

    </div> <!-- End Content Area -->
</div>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>

<script>
let detail15minTable = null;
let myChart = null;
let pieChart = null;
let rawData = [];

window.onload = function() {
    loadData();
};

async function loadData() {
    const targetDate = document.getElementById('targetDate').value;
    
    document.getElementById('loading').style.display = 'block';
    document.getElementById('contentArea').style.display = 'none';

    const urlParams = new URLSearchParams(window.location.search);
    const machine = urlParams.get('machine');
    
    if (!machine) {
        alert('マシン名が指定されていません。');
        return;
    }

    let url = `get_detail_15min.php?target_date=${targetDate}&machine=${encodeURIComponent(machine)}`;

    try {
        const response = await fetch(url);
        const result = await response.json();

        if (result.status === 'error') {
            alert('Error: ' + result.message);
            return;
        }

        rawData = result.rawData || [];
        renderTable(result.data);
        updateTotalTime();
        updateTimelineChart(result.data);
        updateProcessChart();

        document.getElementById('contentArea').style.display = 'block';
    } catch (e) {
        alert('Failed to load data: ' + e);
        console.error(e);
    } finally {
        document.getElementById('loading').style.display = 'none';
    }
}

function renderTable(data) {
    if ($.fn.DataTable.isDataTable('#detail15minTable')) {
        $('#detail15minTable').DataTable().destroy();
    }

    detail15minTable = $('#detail15minTable').DataTable({
        data: data,
        language: {
            "emptyTable": "テーブルにデータがありません",
            "info": " _TOTAL_ 件中 _START_ から _END_ まで表示",
            "infoEmpty": " 0 件中 0 から 0 まで表示",
            "infoFiltered": "（全 _MAX_ 件より抽出）",
            "infoPostFix": "",
            "thousands": ",",
            "lengthMenu": "_MENU_ 件表示",
            "loadingRecords": "読み込み中...",
            "processing": "処理中...",
            "search": "検索:",
            "zeroRecords": "一致するレコードがありません",
            "paginate": {
                "first": "先頭",
                "last": "最終",
                "next": "次",
                "previous": "前"
            },
            "aria": {
                "sortAscending": ": 列を昇順に並べ替えるにはactivate",
                "sortDescending": ": 列を降順に並べ替えるにはactivate"
            }
        },
        paging: false,
        order: [[0, 'asc']],
        columns: [
            { data: 'time_slot' },
            { 
                data: 'operation_rate',
                render: function(data, type, row) {
                    let color = data >= 70 ? '#4CAF50' : (data >= 50 ? '#FF9800' : '#F44336');
                    return `<span style="color:${color}; font-weight:bold;">${data}%</span>`;
                }
            },
            { data: 'actual_work_formatted' },
            { data: 'idle_formatted' },
            { data: 'mouse_count' },
            { data: 'keyboard_count' },
            { data: 'switch_count' }
        ]
    });
}

function updateTotalTime() {
  let totalSeconds = 0;
  rawData.forEach(d => {
      totalSeconds += d.s; 
  });
  document.getElementById('totalTimeDisplay').textContent = (totalSeconds / 3600).toFixed(1) + 'h';
}


// Note: This function now expects 'data' (the 15-min blocks), not 'rawData'.
// Previously this was updateTimelineChart(). Renaming conceptually to updateOperationRateChart but will keep function name or replace content.
// Actually, let's redefine the function signature to take 'data'.

function updateTimelineChart(data) {
  // data is the array of 15-minute blocks from get_detail_15min.php
  
  const labels = data.map(d => d.time_slot);
  const rates = data.map(d => d.operation_rate);
  
  const bgColors = rates.map(rate => {
      if (rate >= 70) return '#4CAF50';
      if (rate >= 50) return '#FF9800';
      return '#F44336';
  });

  const ctx = document.getElementById('activityChart').getContext('2d');
  if (myChart) { myChart.destroy(); }
  
  myChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [{
        label: '稼働率 (%)',
        data: rates,
        backgroundColor: bgColors,
        borderWidth: 0
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: function(context) {
               return `稼働率: ${context.parsed.y}%`;
            }
          }
        }
      },
      scales: {
        x: { 
            grid: { display: false },
            ticks: { 
                autoSkip: true,
                maxTicksLimit: 24 // 1時間ごとくらいに表示
            }
        },
        y: { 
            beginAtZero: true, 
            max: 100,
            title: { display: true, text: '稼働率 (%)' }
        }
      }
    }
  });
}


function updateProcessChart() {
  const processes = {};
  rawData.forEach(d => {
    const process = d.p;
    const seconds = d.s;
    if(processes[process]) { processes[process] += seconds; } else { processes[process] = seconds; }
  });
  
  const sorted = Object.entries(processes).sort((a,b) => b[1] - a[1]).slice(0, 10);
  
  const ctx = document.getElementById('processChart').getContext('2d');
  if (pieChart) { pieChart.destroy(); }
  
  pieChart = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: sorted.map(d => d[0]),
      datasets: [{
        data: sorted.map(d => d[1]/60),
        backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40', '#E7E9ED', '#76A346', '#0E7569', '#AB4E6B']
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { position: 'right' },
        tooltip: { callbacks: { label: function(c) { return c.label + ': ' + c.raw.toFixed(1) + ' 分'; } } }
      }
    }
  });
}
</script>

</body>
</html>
