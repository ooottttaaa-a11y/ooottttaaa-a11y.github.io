<?php
// get_daily_operation_rate.php - 日次稼働率データ取得API
require_once 'db_connect.php';

$machine = isset($_GET['machine']) ? $_GET['machine'] : '';
$startDate = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-d');
$endDate = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');

if (empty($machine)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Machine name is required']);
    exit;
}

$startDateTime = $startDate . ' 00:00:00';
$endDateTime = $endDate . ' 23:59:59';

try {
    // その機械のデータを全て取得
    $stmt = $pdo->prepare("SELECT * FROM activity_records WHERE machine = ? AND uptime >= ? AND uptime <= ? ORDER BY uptime ASC");
    $stmt->execute([$machine, $startDateTime, $endDateTime]);
    $allRows = $stmt->fetchAll();

    // 日付ごとにグループ化
    $dateGroups = [];
    foreach ($allRows as $row) {
        $date = substr($row['uptime'], 0, 10);
        if (!isset($dateGroups[$date])) {
            $dateGroups[$date] = [];
        }
        $dateGroups[$date][] = $row;
    }

    $result = [];

    foreach ($dateGroups as $date => $rows) {
        $startTime = null;
        $endTime = null;
        $dailyIdle = 0;
        $dailyLock = 0;

        foreach ($rows as $row) {
            $timestamp = $row['uptime'];
            if ($startTime === null || $timestamp < $startTime) $startTime = $timestamp;
            if ($endTime === null || $timestamp > $endTime) $endTime = $timestamp;

            $dailyIdle += isset($row['idle_seconds']) ? (int)$row['idle_seconds'] : 0;
            $dailyLock += isset($row['lock_seconds']) ? (int)$row['lock_seconds'] : 0;
        }

        // 勤務時間 = 終業時間 - 始業時間
        $workTime = 0;
        if ($startTime !== null && $endTime !== null) {
            $workTime = strtotime($endTime) - strtotime($startTime);
        }

        // 稼働率 = ((勤務時間 - アイドル時間 - ロック時間) / 勤務時間) × 100
        $operationRate = 0;
        if ($workTime > 0) {
            $actualWorkTime = $workTime - $dailyIdle - $dailyLock;
            if ($actualWorkTime < 0) $actualWorkTime = 0;
            $operationRate = ($actualWorkTime / $workTime) * 100;
        }

        $result[] = [
            'date' => $date,
            'operation_rate' => round($operationRate, 1),
            'work_time' => $workTime,
            'work_time_formatted' => floor($workTime / 3600) . ':' . str_pad(floor(($workTime % 3600) / 60), 2, '0', STR_PAD_LEFT),
            'idle_time' => $dailyIdle,
            'idle_time_formatted' => floor($dailyIdle / 3600) . ':' . str_pad(floor(($dailyIdle % 3600) / 60), 2, '0', STR_PAD_LEFT),
            'lock_time' => $dailyLock,
            'lock_time_formatted' => floor($dailyLock / 3600) . ':' . str_pad(floor(($dailyLock % 3600) / 60), 2, '0', STR_PAD_LEFT)
        ];
    }

    // 日付の降順でソート
    usort($result, function($a, $b) {
        return strcmp($b['date'], $a['date']);
    });

    header('Content-Type: application/json');
    echo json_encode(['status' => 'success', 'data' => $result]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
