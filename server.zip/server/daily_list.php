<?php
require_once 'auth_session.php';
check_login();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset='UTF-8'>
    <title>ActivityMonitor - 日次稼働率</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- DataTables CSS -->
    <link href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <!-- FontAwesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    
    <style>
        body { font-family: 'Segoe UI', Meiryo, sans-serif; background: #f5f5f5; }
        .header-area { background: #fff; padding: 20px; border-bottom: 2px solid #4CAF50; margin-bottom: 20px; }
        .card { border: none; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .chart-container { background: white; padding: 20px; margin-bottom: 20px; border-radius: 5px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .table { table-layout: auto; }
        .table td, .table th { 
            word-break: break-word; 
            white-space: normal !important; 
        }
    </style>
</head>
<body>

<?php include 'navbar.php'; ?>

<div class="header-area">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center">
            <h1 class="h3 m-0">📊 日次稼働率: <span id="machineNameTitle"></span></h1>
            <form class="d-flex align-items-center gap-2" onsubmit="event.preventDefault(); loadData();">
                <input type="date" id="startDate" class="form-control" style="width: auto;">
                <span class="mx-2">～</span>
                <input type="date" id="endDate" class="form-control" style="width: auto;">
                <button type="submit" class="btn btn-primary text-nowrap">表示</button>
                <a href="scores.php" class="btn btn-secondary text-nowrap">一覧に戻る</a>
            </form>
        </div>
    </div>
</div>

<div class="container-fluid">
    <!-- 稼働率グラフ -->
    <div class="chart-container mb-3">
        <h5 class="mb-3">📊 日次稼働率グラフ</h5>
        <div style="height: 400px; position: relative;">
            <canvas id="operationRateChart"></canvas>
        </div>
    </div>

    <div class="card p-4">
        <table id="dailyTable" class="table table-striped table-hover" style="width:100%">
            <thead>
                <tr>
                    <th>日付</th>
                    <th>稼働率</th>
                    <th>勤務時間</th>
                    <th>アイドル時間</th>
                    <th>ロック時間</th>
                    <th>アクション</th>
                </tr>
            </thead>
            <tbody id="dailyTableBody">
                <!-- Rows loaded via JS -->
            </tbody>
        </table>
    </div>
</div>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>

<script>
let table = null;
let operationRateChart = null;
const urlParams = new URLSearchParams(window.location.search);
const machine = urlParams.get('machine');
const initialStart = urlParams.get('start_date') || new Date().toISOString().split('T')[0];
const initialEnd = urlParams.get('end_date') || new Date().toISOString().split('T')[0];

document.getElementById('machineNameTitle').textContent = machine || 'Unknown';
document.getElementById('startDate').value = initialStart;
document.getElementById('endDate').value = initialEnd;

$(document).ready(function() {
    if (!machine) {
        alert('マシン名が指定されていません。');
        return;
    }

    table = $('#dailyTable').DataTable({
        language: {
            "emptyTable": "テーブルにデータがありません",
            "info": " _TOTAL_ 件中 _START_ から _END_ まで表示",
            "infoEmpty": " 0 件中 0 から 0 まで表示",
            "infoFiltered": "（全 _MAX_ 件より抽出）",
            "infoPostFix": "",
            "thousands": ",",
            "lengthMenu": "_MENU_ 件表示",
            "loadingRecords": "読み込み中...",
            "processing": "処理中...",
            "search": "検索:",
            "zeroRecords": "一致するレコードがありません",
            "paginate": {
                "first": "先頭",
                "last": "最終",
                "next": "次",
                "previous": "前"
            },
            "aria": {
                "sortAscending": ": 列を昇順に並べ替えるにはactivate",
                "sortDescending": ": 列を降順に並べ替えるにはactivate"
            }
        },
        paging: false,
        order: [[0, 'asc']], // 日付の昇順
        columns: [
            { data: 'date' },
            { 
                data: 'operation_rate',
                render: function(data, type, row) {
                    let color = data >= 70 ? '#4CAF50' : (data >= 50 ? '#FF9800' : '#F44336');
                    return `<span style="color:${color}; font-weight:bold;">${data}%</span>`;
                }
            },
            { data: 'work_time_formatted' },
            { data: 'idle_time_formatted' },
            { data: 'lock_time_formatted' },
            {
                data: null,
                render: function(data, type, row) {
                    return `<a href="detail.php?machine=${encodeURIComponent(machine)}&start_date=${row.date}" class="btn btn-sm btn-outline-primary">詳細</a>`;
                }
            }
        ]
    });

    // Chart.jsの初期化
    const ctx = document.getElementById('operationRateChart').getContext('2d');
    operationRateChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: [],
            datasets: [{
                label: '稼働率 (%)',
                data: [],
                backgroundColor: function(context) {
                    const value = context.parsed ? context.parsed.x : (context.raw !== undefined ? context.raw : 0);
                    if (value >= 70) return '#4CAF50';
                    if (value >= 50) return '#FF9800';
                    return '#F44336';
                },
                borderColor: function(context) {
                    const value = context.parsed ? context.parsed.x : (context.raw !== undefined ? context.raw : 0);
                    if (value >= 70) return '#4CAF50';
                    if (value >= 50) return '#FF9800';
                    return '#F44336';
                },
                borderWidth: 1
            }]
        },
        options: {
            indexAxis: 'y', // 横棒グラフ
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'top'
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `稼働率: ${context.parsed.x}%`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    beginAtZero: true,
                    max: 100,
                    title: {
                        display: true,
                        text: '稼働率 (%)'
                    }
                }
            }
        }
    });

    loadData();
});

function loadData() {
    const start = document.getElementById('startDate').value;
    const end = document.getElementById('endDate').value;
    
    $.ajax({
        url: `get_daily_operation_rate.php?machine=${encodeURIComponent(machine)}&start_date=${start}&end_date=${end}`,
        type: 'GET',
        dataType: 'json',
        success: function(response) {
            if (response.status === 'success') {
                table.clear();
                table.rows.add(response.data);
                table.draw();
                
                // グラフを更新
                updateChart(response.data);
            } else {
                alert('データ取得エラー: ' + response.message);
            }
        },
        error: function(xhr, status, error) {
            alert('通信エラー: ' + error);
        }
    });
}

function updateChart(data) {
    // データを日付の昇順でソート
    const sortedData = data.sort((a, b) => a.date.localeCompare(b.date));
    
    const labels = sortedData.map(d => d.date);
    const rates = sortedData.map(d => d.operation_rate);
    
    operationRateChart.data.labels = labels;
    operationRateChart.data.datasets[0].data = rates;
    operationRateChart.update();
}
</script>

</body>
</html>
