<?php
// get_operation_rate.php - 稼働率データ取得API
require_once 'db_connect.php';

$startDate = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-d');
$endDate = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');

$startDateTime = $startDate . ' 00:00:00';
$endDateTime = $endDate . ' 23:59:59';

try {
    // 全データを取得
    $stmt = $pdo->prepare("SELECT * FROM activity_records WHERE uptime >= ? AND uptime <= ? ORDER BY uptime ASC");
    $stmt->execute([$startDateTime, $endDateTime]);
    $allRows = $stmt->fetchAll();

    // マシンごとにグループ化
    $machineGroups = [];
    foreach ($allRows as $row) {
        $machine = $row['machine'];
        if (!isset($machineGroups[$machine])) {
            $machineGroups[$machine] = [];
        }
        $machineGroups[$machine][] = $row;
    }

    $result = [];

    foreach ($machineGroups as $machine => $rows) {
        // 日付ごとにグループ化
        $dateGroups = [];
        foreach ($rows as $row) {
            $date = substr($row['uptime'], 0, 10);
            if (!isset($dateGroups[$date])) {
                $dateGroups[$date] = [];
            }
            $dateGroups[$date][] = $row;
        }

        $totalWorkTime = 0;
        $totalIdleTime = 0;
        $totalLockTime = 0;

        foreach ($dateGroups as $date => $dateRows) {
            $startTime = null;
            $endTime = null;
            $dailyIdle = 0;
            $dailyLock = 0;

            foreach ($dateRows as $row) {
                $timestamp = $row['uptime'];
                if ($startTime === null || $timestamp < $startTime) $startTime = $timestamp;
                if ($endTime === null || $timestamp > $endTime) $endTime = $timestamp;

                $dailyIdle += isset($row['idle_seconds']) ? (int)$row['idle_seconds'] : 0;
                $dailyLock += isset($row['lock_seconds']) ? (int)$row['lock_seconds'] : 0;
            }

            // 勤務時間 = 終業時間 - 始業時間
            if ($startTime !== null && $endTime !== null) {
                $dailyWorkTime = strtotime($endTime) - strtotime($startTime);
                $totalWorkTime += $dailyWorkTime;
            }

            $totalIdleTime += $dailyIdle;
            $totalLockTime += $dailyLock;
        }

        // 稼働率 = ((勤務時間 - アイドル時間 - ロック時間) / 勤務時間) × 100
        $operationRate = 0;
        if ($totalWorkTime > 0) {
            $actualWorkTime = $totalWorkTime - $totalIdleTime - $totalLockTime;
            if ($actualWorkTime < 0) $actualWorkTime = 0;
            $operationRate = ($actualWorkTime / $totalWorkTime) * 100;
        }

        $result[] = [
            'machine' => $machine,
            'operation_rate' => round($operationRate, 1),
            'total_work_time' => $totalWorkTime,
            'total_work_time_formatted' => floor($totalWorkTime / 3600) . ':' . str_pad(floor(($totalWorkTime % 3600) / 60), 2, '0', STR_PAD_LEFT),
            'total_idle_time' => $totalIdleTime,
            'total_idle_time_formatted' => floor($totalIdleTime / 3600) . ':' . str_pad(floor(($totalIdleTime % 3600) / 60), 2, '0', STR_PAD_LEFT),
            'total_lock_time' => $totalLockTime,
            'total_lock_time_formatted' => floor($totalLockTime / 3600) . ':' . str_pad(floor(($totalLockTime % 3600) / 60), 2, '0', STR_PAD_LEFT)
        ];
    }

    header('Content-Type: application/json');
    echo json_encode(['status' => 'success', 'data' => $result]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
