<?php
// get_analysis_data.php - API to fetch comprehensive analysis data

require_once 'db_connect.php';

$startDate = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-d');
$endDate = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');

$startDateTime = $startDate . ' 00:00:00';
$endDateTime = $endDate . ' 23:59:59';

try {
    // データ取得
    $stmt = $pdo->prepare("SELECT process, uptime, sec, mouse, keyboard, idle_seconds, lock_seconds, switch_count FROM activity_records WHERE uptime >= ? AND uptime <= ?");
    $stmt->execute([$startDateTime, $endDateTime]);
    $rows = $stmt->fetchAll();

    // 集計用配列
    $hourlyActivity = array_fill(0, 24, 0); // 0-23時の稼働時間合計
    $hourlyCount = array_fill(0, 24, 0); // 0-23時のレコード数
    $hourlyInput = array_fill(0, 24, 0); // 0-23時の入力数合計 (NEW)
    
    $inputIntensity = []; // 日付 => {mouse, keyboard}
    
    $switchFreq = array_fill(0, 24, 0); // 0-23時の切り替え回数合計
    $switchCount = array_fill(0, 24, 0); // データカウント用

    $heatmap = []; 
    // 曜日(0=Sun...6=Sat) × 時間(0-23) の稼働時間合計と総時間
    for($d=0; $d<7; $d++) {
        for($h=0; $h<24; $h++) {
            $heatmap[$d][$h] = ['total_work' => 0, 'record_count' => 0];
        }
    }
    
    $processStats = []; // process => total_sec (NEW)
    $dailyStatsAgg = []; // date => { actual_work, total_sec }

    foreach ($rows as $row) {
        $timestamp = strtotime($row['uptime']);
        $hour = intval(date('H', $timestamp));
        $wday = intval(date('w', $timestamp));
        $date = date('Y-m-d', $timestamp);
        
        $proc = $row['process'];
        $sec = (int)$row['sec'];
        $idle = isset($row['idle_seconds']) ? (int)$row['idle_seconds'] : 0;
        $lock = isset($row['lock_seconds']) ? (int)$row['lock_seconds'] : 0;
        $mouse = isset($row['mouse']) ? (int)$row['mouse'] : 0;
        $keyboard = isset($row['keyboard']) ? (int)$row['keyboard'] : 0;
        $sw = isset($row['switch_count']) ? (int)$row['switch_count'] : 0;

        // 実働時間
        $actualWork = max(0, $sec - $idle - $lock);

        // 日別集計
        if (!isset($dailyStatsAgg[$date])) {
            $dailyStatsAgg[$date] = ['actual_work' => 0, 'total_sec' => 0];
        }
        $dailyStatsAgg[$date]['actual_work'] += $actualWork;
        $dailyStatsAgg[$date]['total_sec'] += $sec;

        // 1. 時間帯別アクティビティ
        $hourlyActivity[$hour] += $actualWork;
        $hourlyCount[$hour]++;
        
        // 1+. 時間帯別 入力強度 (NEW)
        $hourlyInput[$hour] += ($mouse + $keyboard);

        // 2. 入力強度分析
        if (!isset($inputIntensity[$date])) {
            $inputIntensity[$date] = ['mouse' => 0, 'keyboard' => 0];
        }
        $inputIntensity[$date]['mouse'] += $mouse;
        $inputIntensity[$date]['keyboard'] += $keyboard;

        // 3. アプリ切り替え頻度
        $switchFreq[$hour] += $sw;
        $switchCount[$hour]++;

        // 4. 曜日別ヒートマップ
        if ($sec > 0) {
            $ratio = $actualWork / $sec;
            $heatmap[$wday][$hour]['total_work'] += $ratio; 
            $heatmap[$wday][$hour]['record_count']++;
        }
        
        // 5. プロセス統計 (NEW)
        if (!isset($processStats[$proc])) {
            $processStats[$proc] = 0;
        }
        $processStats[$proc] += $sec; // シンプルに合計時間でランキング
    }

    // 整形
    
    // ... [Daily Stats Logic] ...
    $resDaily = [];
    foreach ($dailyStatsAgg as $date => $stats) {
        $rate = 0;
        if ($stats['total_sec'] > 0) {
            $rate = ($stats['actual_work'] / $stats['total_sec']) * 100;
        }
        $resDaily[] = [
            'date' => $date,
            'actual_work_seconds' => $stats['actual_work'],
            'operation_rate' => round($rate, 1)
        ];
    }
    usort($resDaily, function($a, $b) { return strcmp($a['date'], $b['date']); });

    // 1. 時間帯別アクティビティ
    $resHourly = [];
    foreach($hourlyActivity as $h => $val) {
        $resHourly[] = ['hour' => $h, 'seconds' => $val];
    }
    
    // 1+. 時間帯別 入力強度
    $resHourlyInput = [];
    foreach($hourlyInput as $h => $val) {
        $resHourlyInput[] = ['hour' => $h, 'count' => $val];
    }

    // 2. 入力強度
    $resInput = [];
    foreach($inputIntensity as $d => $val) {
        $resInput[] = ['date' => $d, 'mouse' => $val['mouse'], 'keyboard' => $val['keyboard']];
    }
    usort($resInput, function($a, $b) { return strcmp($a['date'], $b['date']); });

    // 3. 切り替え頻度
    $resSwitch = [];
    foreach($switchFreq as $h => $val) {
        $dayCount = (strtotime($endDate) - strtotime($startDate)) / 86400 + 1;
        $avg = $val / ($dayCount > 0 ? $dayCount : 1);
        $resSwitch[] = ['hour' => $h, 'count' => round($avg, 1)];
    }

    // 4. ヒートマップ
    $resHeatmap = [];
    for($d=0; $d<7; $d++) {
        for($h=0; $h<24; $h++) {
            $avgRate = 0;
            if ($heatmap[$d][$h]['record_count'] > 0) {
                $avgRate = ($heatmap[$d][$h]['total_work'] / $heatmap[$d][$h]['record_count']) * 100;
            }
            $resHeatmap[] = ['day' => $d, 'hour' => $h, 'rate' => round($avgRate, 1)];
        }
    }
    
    // 5. プロセスランキング (Top 10)
    arsort($processStats);
    $topProcesses = array_slice($processStats, 0, 10);
    $resProcess = [];
    foreach($topProcesses as $proc => $sec) {
        $resProcess[] = ['process' => $proc, 'seconds' => $sec];
    }

    header('Content-Type: application/json');
    echo json_encode([
        'status' => 'success',
        'data' => [
            'daily' => $resDaily,
            'hourly' => $resHourly,
            'hourly_input' => $resHourlyInput, // NEW
            'input' => $resInput,
            'switch' => $resSwitch,
            'heatmap' => $resHeatmap,
            'process_ranking' => $resProcess // NEW
        ]
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
