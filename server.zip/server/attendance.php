<?php
require_once 'auth_session.php';
check_login();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset='UTF-8'>
    <title>ActivityMonitor - 勤怠 - マシン一覧</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- DataTables CSS -->
    <link href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <!-- FontAwesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    
    <style>
        body { font-family: 'Segoe UI', Meiryo, sans-serif; background: #f5f5f5; }
        .header-area { background: #fff; padding: 20px; border-bottom: 2px solid #2196F3; margin-bottom: 20px; } /* Blue for Attendance */
        .card { border: none; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    </style>
</head>
<body>

<?php include 'navbar.php'; ?>

<div class="header-area">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center">
            <h1 class="h3 m-0">🕒 勤怠 - マシン一覧</h1>
            <form class="d-flex align-items-center gap-2" onsubmit="event.preventDefault(); loadData();">
                <input type="date" id="startDate" class="form-control" style="width: auto;" value="<?php echo date('Y-m-01'); ?>">
                <span class="mx-2">～</span>
                <input type="date" id="endDate" class="form-control" style="width: auto;" value="<?php echo date('Y-m-t'); ?>">
                <button type="submit" class="btn btn-primary text-nowrap">表示</button>
            </form>
        </div>
    </div>
</div>

<div class="container-fluid">
    <!-- 実働時間グラフ -->
    <div class="card p-4 mb-3">
        <h5 class="mb-3">📊 実働時間グラフ</h5>
        <div style="height: 400px; position: relative;">
            <canvas id="actualWorkChart"></canvas>
        </div>
    </div>

    <div class="card p-4">
        <table id="attendanceTable" class="table table-striped table-hover" style="width:100%">
            <thead>
                <tr>
                    <th>マシン名</th>
                    <th>勤務時間</th>
                    <th>実働時間</th>
                    <th>ロック時間</th>
                    <th>アイドル時間</th>
                    <th>アクション</th>
                </tr>
            </thead>
            <tbody id="attendanceTableBody">
                <!-- Rows loaded via JS -->
            </tbody>
            <tfoot class="table-light fw-bold">
                <tr>
                    <th class="text-end">合計:</th>
                    <th id="totalWork"></th>
                    <th id="totalActualWork"></th>
                    <th id="totalLock"></th>
                    <th id="totalIdle"></th>
                    <th></th>
                </tr>
            </tfoot>
        </table>
    </div>
</div>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>

<script>
let table = null;
let actualWorkChart = null;

$(document).ready(function() {
    table = $('#attendanceTable').DataTable({
        language: {
            "emptyTable": "テーブルにデータがありません",
            "info": " _TOTAL_ 件中 _START_ から _END_ まで表示",
            "infoEmpty": " 0 件中 0 から 0 まで表示",
            "infoFiltered": "（全 _MAX_ 件より抽出）",
            "infoPostFix": "",
            "thousands": ",",
            "lengthMenu": "_MENU_ 件表示",
            "loadingRecords": "読み込み中...",
            "processing": "処理中...",
            "search": "検索:",
            "zeroRecords": "一致するレコードがありません",
            "paginate": {
                "first": "先頭",
                "last": "最終",
                "next": "次",
                "previous": "前"
            },
            "aria": {
                "sortAscending": ": 列を昇順に並べ替えるにはactivate",
                "sortDescending": ": 列を降順に並べ替えるにはactivate"
            }
        },
        paging: false, // ページング無効
        order: [[0, 'asc']], // マシン名で昇順ソート
        columns: [
            { data: 'machine' },
            { data: 'total_work_fmt' },
            { data: 'total_actual_work_fmt' },
            { data: 'total_lock_fmt' },
            { data: 'total_idle_fmt' },
            {
                data: null,
                render: function(data, type, row) {
                    const start = $('#startDate').val();
                    const end = $('#endDate').val();
                    return `<a href="attendance_daily.php?machine=${encodeURIComponent(row.machine)}&start_date=${start}&end_date=${end}" class="btn btn-sm btn-outline-primary">詳細</a>`;
                }
            }
        ],
        footerCallback: function (row, data, start, end, display) {
            let totalW = 0, totalA = 0, totalL = 0, totalI = 0;

            data.forEach(d => {
                totalW += d.total_work_sec || 0;
                totalA += d.total_actual_work_sec || 0;
                totalL += d.total_lock_sec || 0;
                totalI += d.total_idle_sec || 0;
            });

            const format = (sec) => {
                const h = Math.floor(sec / 3600);
                const m = Math.floor((sec % 3600) / 60);
                return `${h}:${m.toString().padStart(2, '0')}`;
            };

            $(this.api().column(1).footer()).html(format(totalW));
            $(this.api().column(2).footer()).html(format(totalA));
            $(this.api().column(3).footer()).html(format(totalL));
            $(this.api().column(4).footer()).html(format(totalI));
        }
    });
    
    // Chart.jsの初期化
    const ctx = document.getElementById('actualWorkChart').getContext('2d');
    actualWorkChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: [],
            datasets: [
                {
                    label: '実働時間',
                    data: [],
                    backgroundColor: 'rgba(33, 150, 243, 0.8)',
                    borderColor: 'rgba(33, 150, 243, 1)',
                    borderWidth: 1
                },
                {
                    label: 'アイドル時間',
                    data: [],
                    backgroundColor: 'rgba(255, 152, 0, 0.6)',
                    borderColor: 'rgba(255, 152, 0, 1)',
                    borderWidth: 1
                }
            ]
        },
        options: {
            indexAxis: 'y', // 横棒グラフ
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'top'
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const hours = context.parsed.x;
                            const h = Math.floor(hours);
                            const m = Math.floor((hours - h) * 60);
                            return `${context.dataset.label}: ${h}時間${m}分`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    stacked: true, // 積み上げ
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: '時間'
                    }
                },
                y: {
                    stacked: true // 積み上げ
                }
            }
        }
    });
    
    loadData();
});

function loadData() {
    const start = document.getElementById('startDate').value;
    const end = document.getElementById('endDate').value;
    
    $.ajax({
        url: `get_attendance_list.php?start_date=${start}&end_date=${end}`,
        type: 'GET',
        dataType: 'json',
        success: function(response) {
            if (response.status === 'success') {
                table.clear();
                table.rows.add(response.data);
                table.draw();
                
                // グラフを更新
                updateChart(response.data);
            } else {
                alert('データ取得エラー: ' + response.message);
            }
        },
        error: function(xhr, status, error) {
            alert('通信エラー: ' + error);
        }
    });
}

function updateChart(data) {
    // データを実働時間の降順でソート
    const sortedData = data.sort((a, b) => (b.total_actual_work_sec || 0) - (a.total_actual_work_sec || 0));
    
    const labels = sortedData.map(d => d.machine);
    const actualWorkHours = sortedData.map(d => (d.total_actual_work_sec || 0) / 3600); // 秒を時間に変換
    const idleHours = sortedData.map(d => (d.total_idle_sec || 0) / 3600); // 秒を時間に変換
    
    actualWorkChart.data.labels = labels;
    actualWorkChart.data.datasets[0].data = actualWorkHours;
    actualWorkChart.data.datasets[1].data = idleHours;
    actualWorkChart.update();
}
</script>

</body>
</html>
